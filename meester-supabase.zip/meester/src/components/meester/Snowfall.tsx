"use client";

// ============================================================
// SNOWFALL — Christmas Edition background (canvas particles)
// ------------------------------------------------------------
// A single fixed <canvas> behind the whole app. ~70 flakes with
// individual size, speed and horizontal drift (sinus wobble).
// Rendered with requestAnimationFrame; pauses when the tab is
// hidden (visibilitychange) to save battery on phones.
// The glass cards above it (backdrop-filter: blur) create the
// classy "snow behind frosted glass" iOS effect.
// ============================================================

import { useEffect, useRef } from "react";

interface Flake {
  x: number;
  y: number;
  r: number; // radius
  speed: number;
  drift: number; // horizontal wobble amplitude
  phase: number;
  opacity: number;
}

export default function Snowfall() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let flakes: Flake[] = [];
    let raf = 0;
    let running = true;

    const spawn = (initial: boolean): Flake => ({
      x: Math.random() * width,
      y: initial ? Math.random() * height : -10,
      r: 0.8 + Math.random() * 2.4,
      speed: 0.25 + Math.random() * 0.9,
      drift: 10 + Math.random() * 28,
      phase: Math.random() * Math.PI * 2,
      opacity: 0.25 + Math.random() * 0.55,
    });

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const target = Math.min(90, Math.floor(width / 16));
      flakes = Array.from({ length: target }, () => spawn(true));
    };

    let t = 0;
    const tick = () => {
      if (!running) return;
      t += 0.008;
      ctx.clearRect(0, 0, width, height);
      for (const f of flakes) {
        f.y += f.speed;
        if (f.y > height + 12) Object.assign(f, spawn(false));
        const x = f.x + Math.sin(t * 2 + f.phase) * f.drift * 0.14;
        ctx.beginPath();
        ctx.arc(x, f.y, f.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(235, 242, 255, ${f.opacity})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };

    const onVisibility = () => {
      running = document.visibilityState === "visible";
      if (running) raf = requestAnimationFrame(tick);
    };

    resize();
    raf = requestAnimationFrame(tick);
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
