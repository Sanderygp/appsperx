"use client";

// ============================================================
// NAV — iOS-style navigation: bottom tab bar (mobile) + sidebar
// (desktop). Five tabs; Feynman & puzzles live inside "Breingym".
// ============================================================

import { useMeester, type View } from "@/lib/store";
import { cn } from "@/lib/utils";
import {
  Flame,
  Brain,
  Repeat,
  User,
  LayoutGrid,
} from "lucide-react";

const TABS: { name: View["name"]; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { name: "dashboard", label: "Start", icon: Flame },
  { name: "subjects", label: "Vakken", icon: LayoutGrid },
  { name: "flashcards", label: "Herhaling", icon: Repeat },
  { name: "gym", label: "Breingym", icon: Brain },
  { name: "profile", label: "Profiel", icon: User },
];

export default function Nav() {
  const { view, setView } = useMeester();

  const activeRoot = (() => {
    const n = view.name;
    if (n === "dashboard") return "dashboard";
    if (n === "subjects" || n === "subject" || n === "lesson" || n === "test") return "subjects";
    if (n === "flashcards") return "flashcards";
    if (n === "gym" || n === "nback" || n === "logic" || n === "feynman") return "gym";
    if (n === "profile") return "profile";
    return "dashboard";
  })();

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-white/10 bg-[oklch(0.19_0.05_268/0.85)] p-4 backdrop-blur-xl md:flex">
        <div className="mb-8 flex items-center gap-3 px-2 pt-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#f5c96b] to-[#a92638]">
            <Flame className="h-6 w-6 text-[#0a1128]" aria-hidden="true" />
          </div>
          <div>
            <p className="gold-text text-xl font-extrabold tracking-tight">MEESTER</p>
            <p className="text-[10px] uppercase tracking-widest text-white/40">Kerst-editie</p>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1" aria-label="Hoofdnavigatie">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = activeRoot === t.name;
            return (
              <button
                key={t.name}
                onClick={() => setView({ name: t.name } as View)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition",
                  active
                    ? "bg-gradient-to-r from-[#f5c96b]/20 to-transparent text-[#f5c96b]"
                    : "text-white/60 hover:bg-white/5 hover:text-white"
                )}
              >
                <Icon className="h-5 w-5" aria-hidden="true" />
                {t.label}
              </button>
            );
          })}
        </nav>
        <p className="px-2 text-[11px] leading-relaxed text-white/25">
          &ldquo;IJzeren vuist, slimme methode, altijd winnen.&rdquo;
        </p>
      </aside>

      {/* Mobile bottom tab bar */}
      <nav
        aria-label="Hoofdnavigatie"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-white/10 bg-[oklch(0.19_0.05_268/0.88)] pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden"
      >
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = activeRoot === t.name;
            return (
              <button
                key={t.name}
                onClick={() => setView({ name: t.name } as View)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex min-h-[56px] flex-col items-center justify-center gap-0.5 py-2 text-[10px] font-semibold transition",
                  active ? "text-[#f5c96b]" : "text-white/45"
                )}
              >
                <Icon className="h-5 w-5" aria-hidden="true" />
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
