"use client";

// ============================================================
// MEESTER APP — shell: auth gate + view router + snowfall
// Single-page app: all navigation is client-side state (the
// sandbox exposes only the "/" route), backed by the Zustand
// store whose actions sync every change to the server instantly.
// ============================================================

import { useEffect } from "react";
import { useMeester } from "@/lib/store";
import Snowfall from "./Snowfall";
import Celebration from "./Celebration";
import AuthScreen from "./AuthScreen";
import Nav from "./Nav";
import Dashboard from "./Dashboard";
import SubjectsOverview from "./SubjectsOverview";
import SubjectView from "./SubjectView";
import LessonView from "./LessonView";
import FlashcardsView from "./FlashcardsView";
import TestView from "./TestView";
import GymView from "./GymView";
import NBackView from "./NBackView";
import LogicGridView from "./LogicGridView";
import FeynmanView from "./FeynmanView";
import ProfileView from "./ProfileView";
import { Flame, Loader2 } from "lucide-react";

export default function MeesterApp() {
  const { status, view, celebration, setCelebration, boot, heartbeat } = useMeester();

  useEffect(() => {
    boot();
  }, []);

  // Keep the streak alive while the app is open (10 min interval)
  useEffect(() => {
    if (status !== "ready") return;
    const t = setInterval(() => heartbeat(), 10 * 60 * 1000);
    return () => clearInterval(t);
  }, [status]);

  return (
    <div className="relative min-h-screen">
      <Snowfall />

      {status === "loading" && (
        <main className="relative z-10 flex min-h-screen flex-col items-center justify-center gap-4">
          <div className="festive-ring flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-[#f5c96b] to-[#a92638]">
            <Flame className="h-10 w-10 text-[#0a1128]" aria-hidden="true" />
          </div>
          <Loader2 className="h-6 w-6 animate-spin text-[#f5c96b]" aria-hidden="true" />
        </main>
      )}

      {status === "guest" && <AuthScreen />}

      {status === "ready" && (
        <>
          <Nav />
          <main className="relative z-10 mx-auto w-full max-w-4xl px-4 pb-24 pt-6 md:pl-72 md:pr-6 lg:max-w-5xl">
            <div key={JSON.stringify(view)}>
              {view.name === "dashboard" && <Dashboard />}
              {view.name === "subjects" && <SubjectsOverview />}
              {view.name === "subject" && <SubjectView subjectId={view.subjectId} />}
              {view.name === "lesson" && (
                <LessonView subjectId={view.subjectId} lessonId={view.lessonId} />
              )}
              {view.name === "flashcards" && (
                <FlashcardsView subjectId={"subjectId" in view ? view.subjectId : undefined} />
              )}
              {view.name === "test" && <TestView subjectId={view.subjectId} testId={view.testId} />}
              {view.name === "gym" && <GymView />}
              {view.name === "nback" && <NBackView />}
              {view.name === "logic" && <LogicGridView />}
              {view.name === "feynman" && <FeynmanView />}
              {view.name === "profile" && <ProfileView />}
            </div>
          </main>
          <Celebration open={celebration.open} onClose={() => setCelebration(false)} />
        </>
      )}
    </div>
  );
}
