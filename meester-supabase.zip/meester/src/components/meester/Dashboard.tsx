"use client";

// ============================================================
// DASHBOARD — progress, subjects, current streak, rank, SRS
// ------------------------------------------------------------
// - Streak "Daily Discipline" with a Christmas-tree progress
//   ornament (the tree fills as the day's mission completes).
// - Rank ladder (Recluut → … → Meester) driven by XP.
// - SRS card: exact number of flashcards the Iron Fist demands
//   today (Ebbinghaus due dates, see src/lib/srs.ts).
// - Subject grid with per-subject completion ring.
// ============================================================

import { useMemo } from "react";
import { useMeester } from "@/lib/store";
import { SUBJECTS, subjectProgress } from "@/lib/curriculum";
import { rankForXp } from "@/lib/ranks";
import { allFlashcards } from "@/lib/curriculum";
import { isDue } from "@/lib/srs";
import { cn } from "@/lib/utils";
import {
  Flame,
  ChevronRight,
  TrendingUp,
  Crown,
  Sparkles,
  Snowflake,
  TreePine,
  CalendarCheck,
  Swords,
  BookOpenCheck,
} from "lucide-react";
import { SubjectIcon } from "./subjectIcons";

function dayKey(d: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Amsterdam",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

export default function Dashboard() {
  const { progress, user, setView } = useMeester();
  const xp = progress.streak.xp;
  const rank = rankForXp(xp);

  const cards = useMemo(() => allFlashcards(), []);
  const dueCount = useMemo(
    () => cards.filter((c) => progress.srs[c.card.id] && isDue(progress.srs[c.card.id])).length,
    [cards, progress.srs]
  );
  const newCount = useMemo(
    () => cards.filter((c) => !progress.srs[c.card.id]).length,
    [cards, progress.srs]
  );

  // Daily mission checklist
  const mission = useMemo(() => {
    const today = dayKey(new Date());
    const reviewsToday = (progress.streak.reviews ?? 0) > 0 && progress.streak.lastActiveDay === today;
    const lessonDoneToday = Object.keys(progress.lessons).length > 0 && progress.streak.lastActiveDay === today;
    return { reviewsToday, lessonDoneToday, activeToday: progress.streak.lastActiveDay === today };
  }, [progress]);

  // Weekly discipline strip (last 7 days)
  const week = useMemo(() => {
    const days: { key: string; label: string; active: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      days.push({
        key: dayKey(d),
        label: ["zo", "ma", "di", "wo", "do", "vr", "za"][d.getDay()],
        active: progress.activity.includes(dayKey(d)),
      });
    }
    return days;
  }, [progress.activity]);

  const lessonsDone = Object.keys(progress.lessons).length;
  const testsPassed = Object.values(progress.tests).filter((t) => t.passed).length;
  const perfectTests = Object.values(progress.tests).filter((t) => t.passed && t.score === t.total).length;

  return (
    <div className="space-y-5">
      {/* Greeting + rank */}
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm text-white/50">
            {new Intl.DateTimeFormat("nl-NL", { weekday: "long", day: "numeric", month: "long" }).format(new Date())}
          </p>
          <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight">
            Welkom, <span className="gold-text">{user?.name ?? "Recluut"}</span>
          </h1>
        </div>
        <button
          onClick={() => setView({ name: "profile" })}
          className="glass flex items-center gap-2 px-3 py-2 text-xs font-semibold text-white/80 transition hover:bg-white/10"
          aria-label="Naar profiel"
        >
          <Crown className="h-4 w-4 text-[#f5c96b]" aria-hidden="true" />
          {rank.current.name}
        </button>
      </header>

      {/* Hero: streak + rank progress + tree */}
      <section className="glass relative overflow-hidden p-5" aria-label="Discipline">
        <div className="absolute -right-6 -top-8 opacity-[0.07]">
          <TreePine className="h-44 w-44 text-white" aria-hidden="true" />
        </div>
        <div className="relative flex flex-wrap items-center gap-5">
          <div className="flex items-center gap-3">
            <div className="flex h-16 w-16 flex-col items-center justify-center rounded-3xl bg-gradient-to-br from-[#e04355] to-[#a92638] text-white shadow-lg">
              <Flame className="h-6 w-6" aria-hidden="true" />
              <span className="text-xl font-extrabold leading-none">{progress.streak.current}</span>
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-white/50">Dagelijkse discipline</p>
              <p className="text-lg font-bold">
                {progress.streak.current} da{progress.streak.current === 1 ? "g" : "gen"} streak
              </p>
              <p className="text-xs text-white/50">Langste: {progress.streak.longest} dag{progress.streak.longest === 1 ? "" : "en"}</p>
            </div>
          </div>

          <div className="ml-auto text-right">
            <p className="flex items-center justify-end gap-1 text-xs uppercase tracking-widest text-white/50">
              <Sparkles className="h-3.5 w-3.5 text-[#f5c96b]" aria-hidden="true" /> XP
            </p>
            <p className="gold-text text-2xl font-extrabold">{xp}</p>
          </div>
        </div>

        {/* Rank progress bar */}
        <div className="relative mt-5">
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="font-semibold text-[#f5c96b]">{rank.current.name}</span>
            {rank.next ? (
              <span className="text-white/50">
                {rank.xpToNext} XP naar {rank.next.name}
              </span>
            ) : (
              <span className="font-semibold text-[#f5c96b]">Hoogste rang bereikt</span>
            )}
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuenow={Math.round(rank.progress * 100)} aria-valuemin={0} aria-valuemax={100}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#f5c96b] via-[#f8dd9a] to-[#d9a441] transition-all duration-700"
              style={{ width: `${Math.max(4, rank.progress * 100)}%` }}
            />
          </div>
        </div>

        {/* Weekly discipline strip */}
        <div className="mt-5 flex items-center justify-between gap-1.5" aria-label="Laatste 7 dagen">
          {week.map((d) => (
            <div key={d.key} className="flex flex-1 flex-col items-center gap-1">
              <div
                className={cn(
                  "flex h-9 w-full items-center justify-center rounded-xl text-xs font-bold transition",
                  d.active
                    ? "bg-gradient-to-b from-[#3baf75] to-[#1f7a4d] text-white shadow-[0_0_14px_rgba(59,175,117,0.35)]"
                    : "bg-white/5 text-white/30"
                )}
              >
                {d.active ? <CalendarCheck className="h-4 w-4" aria-hidden="true" /> : d.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Iron Fist SRS card */}
      <section className="glass flex flex-wrap items-center gap-4 p-5" aria-label="Herhaling vandaag">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#3baf75] to-[#1f7a4d]">
          <TrendingUp className="h-7 w-7 text-white" aria-hidden="true" />
        </div>
        <div className="min-w-40 flex-1">
          <p className="text-xs uppercase tracking-widest text-white/50">IJzeren Vuist · vandaag herhalen</p>
          <p className="text-lg font-bold">
            {dueCount > 0 ? (
              <>
                <span className="text-[#3baf75]">{dueCount}</span> kaart{dueCount === 1 ? "" : "en"} wachten
              </>
            ) : (
              "Alles op schema. IJzeren."
            )}
          </p>
          <p className="text-xs text-white/50">{newCount} nieuwe kaarten beschikbaar</p>
        </div>
        <button
          onClick={() => setView({ name: "flashcards" })}
          className="rounded-full bg-gradient-to-r from-[#3baf75] to-[#1f7a4d] px-5 py-2.5 text-sm font-bold text-white transition hover:brightness-110 active:scale-95"
        >
          Herhalen
        </button>
      </section>

      {/* Daily mission */}
      <section className="glass p-5" aria-label="Dagopdracht">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-widest text-white/60">Dagopdracht</h2>
          <Snowflake className="twinkle h-4 w-4 text-[#f5c96b]" aria-hidden="true" />
        </div>
        <div className="grid gap-2 sm:grid-cols-3">
          <div className={cn("flex items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-sm", mission.active ? "border-[#3baf75]/40 bg-[#3baf75]/10" : "border-white/10 bg-white/5")}>
            <Flame className={cn("h-4 w-4", mission.active ? "text-[#3baf75]" : "text-white/30")} aria-hidden="true" />
            <span className={mission.active ? "text-white" : "text-white/50"}>Streak levend houden</span>
          </div>
          <div className={cn("flex items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-sm", mission.lessonDoneToday ? "border-[#3baf75]/40 bg-[#3baf75]/10" : "border-white/10 bg-white/5")}>
            <BookOpenCheck className={cn("h-4 w-4", mission.lessonDoneToday ? "text-[#3baf75]" : "text-white/30")} aria-hidden="true" />
            <span className={mission.lessonDoneToday ? "text-white" : "text-white/50"}>1 les voltooien</span>
          </div>
          <div className={cn("flex items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-sm", mission.reviewsToday ? "border-[#3baf75]/40 bg-[#3baf75]/10" : "border-white/10 bg-white/5")}>
            <TrendingUp className={cn("h-4 w-4", mission.reviewsToday ? "text-[#3baf75]" : "text-white/30")} aria-hidden="true" />
            <span className={mission.reviewsToday ? "text-white" : "text-white/50"}>10 flashcards herhalen</span>
          </div>
        </div>
      </section>

      {/* Cognitive gym shortcut */}
      <button
        onClick={() => setView({ name: "gym" })}
        className="glass flex w-full items-center gap-4 p-5 text-left transition hover:bg-white/10"
        aria-label="Naar de breingym"
      >
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#f5c96b] to-[#a92638]">
          <Swords className="h-7 w-7 text-[#0a1128]" aria-hidden="true" />
        </div>
        <div className="flex-1">
          <p className="text-xs uppercase tracking-widest text-white/50">Hoger IQ & slimmer</p>
          <p className="text-lg font-bold">Breingym: Dual N-Back · Logica · Feynman</p>
          <p className="text-xs text-white/50">Train werkgeheugen en vloeibare intelligentie — de Chinese methode.</p>
        </div>
        <ChevronRight className="h-5 w-5 text-white/40" aria-hidden="true" />
      </button>

      {/* Subject grid */}
      <section aria-label="Vakken">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-widest text-white/60">Vakken · {lessonsDone} lessen · {testsPassed} toetsen behaald</h2>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {SUBJECTS.map((s) => {
            const p = subjectProgress(s, progress.lessons, progress.tests);
            return (
              <button
                key={s.id}
                onClick={() => setView({ name: "subject", subjectId: s.id })}
                className="glass group flex flex-col items-start gap-3 p-4 text-left transition hover:bg-white/10 active:scale-[0.98]"
              >
                <div className={cn("flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br", s.gradient)}>
                  <SubjectIcon name={s.icon} className="h-6 w-6 text-white" />
                </div>
                <div className="w-full">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold leading-tight">{s.name}</h3>
                    <span className={cn("text-xs font-bold", p.pct === 100 ? "text-[#3baf75]" : "text-white/50")}>{p.pct}%</span>
                  </div>
                  <p className="mt-0.5 line-clamp-2 min-h-8 text-xs text-white/50">{s.tagline}</p>
                  <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        p.testPassed ? "bg-gradient-to-r from-[#3baf75] to-[#1f7a4d]" : "bg-gradient-to-r from-[#f5c96b] to-[#d9a441]"
                      )}
                      style={{ width: `${Math.max(3, p.pct)}%` }}
                    />
                  </div>
                  <p className="mt-2 text-[11px] text-white/40">
                    {p.lessonsDone}/{p.lessonsTotal} lessen · {p.testPassed ? "toets behaald ✓" : "toets 10/10 vereist"}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {perfectTests > 0 && (
        <p className="pb-2 text-center text-xs text-white/40">
          <span className="gold-text font-bold">{perfectTests}×</span> Gouden Draak behaald — elke 10/10 is een bewijs dat discipline wint.
        </p>
      )}
    </div>
  );
}
