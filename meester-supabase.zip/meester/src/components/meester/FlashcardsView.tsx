"use client";

// ============================================================
// FLASHCARDS — "De IJzeren Vuist" SRS sessie
// ------------------------------------------------------------
// Due cards first (Ebbinghaus schedule from src/lib/srs.ts),
// then new cards. Four grade buttons map to SM-2 quality:
//   Weer vergeten (again) · Moeilijk (hard) · Goed (good) · Makkelijk (easy)
// The next-interval preview shows the student EXACTLY when the
// card will return — the schedule is non-negotiable.
// ============================================================

import { useMemo, useState } from "react";
import { useMeester } from "@/lib/store";
import { allFlashcards } from "@/lib/curriculum";
import { isDue, previewIntervals, formatInterval, type SrsGrade } from "@/lib/srs";
import { cn } from "@/lib/utils";
import { ArrowLeft, Eye, Flame, Snowflake, Timer, Sparkles } from "lucide-react";

const SESSION_LIMIT = 20;

export default function FlashcardsView({ subjectId }: { subjectId?: string }) {
  const { progress, reviewCard, setView } = useMeester();
  const cards = useMemo(() => allFlashcards(), []);
  const [revealed, setRevealed] = useState(false);
  const [done, setDone] = useState(0);

  // Build the session queue: due first, then new, filtered by subject.
  // Recomputed on every render (cheap: ~120 cards) so a reviewed card
  // drops out of the queue the moment its SRS state updates.
  const pool = subjectId ? cards.filter((c) => c.subject.id === subjectId) : cards;
  const due = pool
    .filter((c) => progress.srs[c.card.id] && isDue(progress.srs[c.card.id]))
    .map((c) => ({ ...c, isNew: false }));
  const fresh = pool
    .filter((c) => !progress.srs[c.card.id])
    .map((c) => ({ ...c, isNew: true }));
  const queue = [...due, ...fresh].slice(0, SESSION_LIMIT);

  const current = queue[0];
  const cardState = current ? progress.srs[current.card.id] : undefined;
  const previews = cardState ? previewIntervals(cardState) : null;

  const grade = async (g: SrsGrade) => {
    if (!current) return;
    setRevealed(false);
    setDone((d) => d + 1);
    await reviewCard(current.card.id, current.subject.id, g);
  };

  const subjectLabel = subjectId
    ? cards.find((c) => c.subject.id === subjectId)?.subject.name
    : "Alle vakken";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setView(subjectId ? { name: "subject", subjectId } : { name: "dashboard" })}
          className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Terug
        </button>
        <p className="text-xs font-semibold text-white/50">{subjectLabel} · {done} herhaald</p>
      </div>

      {!current ? (
        <div className="glass flex flex-col items-center gap-4 p-10 text-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#3baf75] to-[#1f7a4d]">
            <Snowflake className="h-10 w-10 text-white" aria-hidden="true" />
          </div>
          <h1 className="text-2xl font-extrabold">IJzeren vuist: alles herhaald.</h1>
          <p className="max-w-sm text-sm text-white/60">
            Geen kaarten vandaag. Dit is wat discipline oplevert: je brein is klaar.
            Kom morgen terug — de Ebbinghaus-curve bepaalt de rest.
          </p>
        </div>
      ) : (
        <>
          {/* Progress dots */}
          <div className="flex items-center gap-1.5" aria-label={`Kaart 1 van ${queue.length}`}>
            {queue.map((_, i) => (
              <div key={i} className={cn("h-1.5 flex-1 rounded-full", i === 0 ? "bg-[#f5c96b]" : "bg-white/10")} />
            ))}
          </div>

          {/* Card */}
          <div className="glass-strong relative min-h-72 p-6 sm:p-8" aria-live="polite">
            <div className="mb-4 flex items-center justify-between text-[11px] uppercase tracking-widest text-white/45">
              <span className="font-bold">{current.isNew ? "Nieuwe kaart" : "Herhaling"}</span>
              <span>{current.subject.name}</span>
            </div>

            <p className="text-center text-xl font-bold leading-relaxed sm:text-2xl">
              {current.card.front}
            </p>

            {revealed ? (
              <div className="mt-6 border-t border-white/10 pt-6">
                <p className="text-center text-lg leading-relaxed text-[#3baf75] sm:text-xl">
                  {current.card.back}
                </p>
              </div>
            ) : (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => setRevealed(true)}
                  className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold transition hover:bg-white/10 active:scale-95"
                >
                  <Eye className="h-4 w-4" aria-hidden="true" /> Toon antwoord
                </button>
              </div>
            )}

            {cardState && (
              <div className="mt-5 flex items-center justify-center gap-4 text-[11px] text-white/40">
                <span className="flex items-center gap-1">
                  <Timer className="h-3 w-3" aria-hidden="true" /> interval: {formatInterval(cardState.intervalDays)}
                </span>
                <span className="flex items-center gap-1">
                  <Sparkles className="h-3 w-3" aria-hidden="true" /> EF {cardState.easeFactor.toFixed(2)}
                </span>
                <span className="flex items-center gap-1">
                  <Flame className="h-3 w-3" aria-hidden="true" /> reeks {cardState.repetitions}
                </span>
              </div>
            )}
          </div>

          {/* Grade buttons with next-interval preview */}
          {revealed && (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {(
                [
                  { g: "again" as SrsGrade, label: "Weer vergeten", cls: "from-[#e04355] to-[#a92638]" },
                  { g: "hard" as SrsGrade, label: "Moeilijk", cls: "from-orange-500 to-amber-600" },
                  { g: "good" as SrsGrade, label: "Goed", cls: "from-[#3baf75] to-[#1f7a4d]" },
                  { g: "easy" as SrsGrade, label: "Makkelijk", cls: "from-[#f5c96b] to-[#d9a441]" },
                ] as const
              ).map(({ g, label, cls }) => (
                <button
                  key={g}
                  onClick={() => grade(g)}
                  className={cn(
                    "flex flex-col items-center gap-0.5 rounded-2xl bg-gradient-to-br py-3.5 font-bold text-white transition hover:brightness-110 active:scale-95",
                    cls
                  )}
                >
                  <span className="text-sm">{label}</span>
                  <span className="flex items-center gap-1 text-[11px] font-semibold opacity-85">
                    <Timer className="h-3 w-3" aria-hidden="true" />
                    {previews ? previews[g] : ""}
                  </span>
                </button>
              ))}
            </div>
          )}

          <p className="text-center text-xs text-white/35">
            De IJzeren Vuist: beoordeel jezelf eerlijk — de curve bepaalt wanneer deze kaart terugkomt.
          </p>
        </>
      )}
    </div>
  );
}
