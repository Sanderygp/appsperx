"use client";

// ============================================================
// AUTH SCREEN — Meester login/registratie (Kerst-editie)
// Glassmorphism card over the snowfall. Email + wachtwoord.
// Google OAuth is supported in production via Supabase Auth
// (see README) — the button below documents that hook.
// ============================================================

import { useState } from "react";
import { useMeester } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flame, Loader2, Snowflake } from "lucide-react";

export default function AuthScreen() {
  const { login, register } = useMeester();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "login") await login(email, password);
      else await register(name, email, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Er ging iets mis.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="relative z-10 flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="festive-ring mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-[#f5c96b] via-[#d9a441] to-[#a92638]">
            <Flame className="h-10 w-10 text-[#0a1128]" aria-hidden="true" />
          </div>
          <h1 className="gold-text text-4xl font-extrabold tracking-tight">MEESTER</h1>
          <p className="mt-2 text-sm font-medium text-white/70">
            Handhaving · Toezicht · Veiligheid — MBO 3, KW1C
          </p>
          <p className="mt-1 flex items-center justify-center gap-2 text-xs text-white/40">
            <Snowflake className="h-3 w-3" aria-hidden="true" /> Kerst-editie · Discipline overwint
            <Snowflake className="h-3 w-3" aria-hidden="true" />
          </p>
        </div>

        <div className="glass-strong p-6 sm:p-8">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-full bg-white/5 p-1" role="tablist">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                role="tab"
                aria-selected={mode === m}
                onClick={() => {
                  setMode(m);
                  setError(null);
                }}
                className={`rounded-full py-2 text-sm font-semibold transition ${
                  mode === m ? "bg-gradient-to-r from-[#f5c96b] to-[#d9a441] text-[#0a1128]" : "text-white/60 hover:text-white"
                }`}
              >
                {m === "login" ? "Inloggen" : "Account maken"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <div className="space-y-2">
                <Label htmlFor="name">Naam</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Bijv. Youri"
                  autoComplete="name"
                  required
                />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jij@voorbeeld.nl"
                autoComplete="email"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Wachtwoord</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="min. 6 tekens"
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                required
              />
            </div>

            {error && (
              <p className="rounded-xl border border-[#e04355]/30 bg-[#e04355]/10 px-3 py-2 text-sm text-[#ff9aa5]" role="alert">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={busy}
              className="h-12 w-full rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] text-base font-bold text-[#0a1128] hover:brightness-110"
            >
              {busy ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" /> : mode === "login" ? "Binnen. Geen excuses." : "Begin je discipline"}
            </Button>
          </form>

          <div className="mt-6 border-t border-white/10 pt-4 text-center text-xs leading-relaxed text-white/40">
            Voortgang wordt direct in de cloud gesynchroniseerd — telefoon, tablet en
            laptop blijven altijd gelijk. Google-login is beschikbaar in de
            productie-omgeving via Supabase Auth (zie README).
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-white/30">
          &ldquo;De vlam vraagt niet of het koud is. Jij vraagt niet of het makkelijk is.&rdquo;
        </p>
      </div>
    </main>
  );
}
