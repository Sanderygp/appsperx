"use client";

// ============================================================
// LESSON VIEW — reader with key points + complete button (+50 XP)
// ============================================================

import { useMeester } from "@/lib/store";
import { SUBJECT_BY_ID } from "@/lib/curriculum";
import { ArrowLeft, CheckCircle2, Circle, KeyRound, Loader2 } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function LessonView({ subjectId, lessonId }: { subjectId: string; lessonId: string }) {
  const { progress, completeLesson, setView } = useMeester();
  const subject = SUBJECT_BY_ID.get(subjectId);
  const lesson = subject?.lessons.find((l) => l.id === lessonId);
  const [busy, setBusy] = useState(false);
  if (!subject || !lesson) return null;

  const done = Boolean(progress.lessons[lessonId]);

  const toggle = async () => {
    setBusy(true);
    try {
      await completeLesson(subjectId, lessonId, !done);
    } finally {
      setBusy(false);
    }
  };

  return (
    <article className="space-y-5">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setView({ name: "subject", subjectId })}
          className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> {subject.name}
        </button>
        {done && (
          <span className="flex items-center gap-1 text-xs font-bold text-[#3baf75]">
            <CheckCircle2 className="h-4 w-4" aria-hidden="true" /> Voltooid
          </span>
        )}
      </div>

      <header className="glass p-6">
        <p className="text-xs uppercase tracking-widest text-white/45">{subject.name}</p>
        <h1 className="mt-1 text-2xl font-extrabold leading-snug tracking-tight">{lesson.title}</h1>
        <p className="mt-3 text-sm leading-relaxed text-white/70">{lesson.intro}</p>
      </header>

      {lesson.sections.map((sec) => (
        <section key={sec.heading} className="glass p-6">
          <h2 className="mb-2 text-lg font-bold text-[#f5c96b]">{sec.heading}</h2>
          <p className="text-sm leading-relaxed text-white/80">{sec.body}</p>
          {sec.bullets && (
            <ul className="mt-3 space-y-1.5">
              {sec.bullets.map((b) => (
                <li key={b} className="flex items-start gap-2 text-sm text-white/70">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#f5c96b]" aria-hidden="true" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}

      <section className="glass p-6" aria-label="Kernpunten">
        <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-[#f5c96b]">
          <KeyRound className="h-5 w-5" aria-hidden="true" /> Kernpunten — onthoud deze
        </h2>
        <ul className="space-y-2">
          {lesson.keyPoints.map((kp) => (
            <li key={kp} className="flex items-start gap-2.5 rounded-xl bg-white/5 px-3.5 py-2.5 text-sm text-white/85">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#3baf75]" aria-hidden="true" />
              <span>{kp}</span>
            </li>
          ))}
        </ul>
      </section>

      <button
        onClick={toggle}
        disabled={busy}
        className={cn(
          "flex h-14 w-full items-center justify-center gap-2 rounded-full text-base font-bold transition active:scale-[0.98]",
          done
            ? "border border-white/15 bg-white/5 text-white/70 hover:bg-white/10"
            : "bg-gradient-to-r from-[#3baf75] to-[#1f7a4d] text-white hover:brightness-110"
        )}
      >
        {busy ? (
          <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
        ) : done ? (
          <>
            <CheckCircle2 className="h-5 w-5" aria-hidden="true" /> Voltooid — klik om te heropenen
          </>
        ) : (
          <>
            <Circle className="h-5 w-5" aria-hidden="true" /> Markeer als voltooid (+50 XP)
          </>
        )}
      </button>
      <div className="pb-2" />
    </article>
  );
}
