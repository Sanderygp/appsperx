"use client";

// ============================================================
// GYM HUB — "Hoger IQ & slimmer" (de Chinese methodiek)
// Dual N-Back · Logic Grids · Feynman — met scores en uitleg
// waarom elk instrument je brein traint.
// ============================================================

import { useMeester } from "@/lib/store";
import { cn } from "@/lib/utils";
import { ArrowRight, Brain, Lightbulb, Mic2, Trophy } from "lucide-react";

export default function GymView() {
  const { progress, setView } = useMeester();
  const nback = progress.puzzles["nback-dual"];
  const logicSolved = Object.entries(progress.puzzles).filter(
    ([k, v]) => k.startsWith("logic-") && v.solved
  ).length;

  const cards = [
    {
      key: "nback",
      icon: Brain,
      title: "Dual N-Back",
      desc: "Train je werkgeheugen met twee gelijktijdige streams. Bewezen methode om vloeibare intelligentie te prikkelen.",
      stat: nback ? `Beste: ${nback.bestScore}% · niveau ${nback.bestLevel}` : "Nog niet gespeeld",
      onClick: () => setView({ name: "nback" }),
      gradient: "from-[#f5c96b] to-[#a92638]",
    },
    {
      key: "logic",
      icon: Lightbulb,
      title: "Logic Grid Puzzels",
      desc: "Deductie-oefeningen: uit beperkte aanwijzingen de unieke oplossing afleiden. Dit is politiewerk in puurste vorm.",
      stat: `${logicSolved}/3 opgelost`,
      onClick: () => setView({ name: "logic" }),
      gradient: "from-[#3baf75] to-[#1f7a4d]",
    },
    {
      key: "feynman",
      icon: Mic2,
      title: "Feynman-techniek",
      desc: "Leg een begrip uit aan een 12-jarige. Waar je vastloopt, ligt je hiaat. Vier stappen, opgeslagen in de cloud.",
      stat: `${Object.values(progress.feynman).filter((f) => f.completed).length} begrippen beheerst`,
      onClick: () => setView({ name: "feynman" }),
      gradient: "from-[#e04355] to-[#a92638]",
    },
  ];

  return (
    <div className="space-y-4">
      <header className="glass p-5">
        <h1 className="text-2xl font-extrabold tracking-tight">Breingym</h1>
        <p className="mt-1 text-sm leading-relaxed text-white/60">
          Slim is geen gave, het is trainingsresultaat. IJzeren vuist voor je schema,
          slimme methode voor je brein, altijd winnen als norm.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <button
              key={c.key}
              onClick={c.onClick}
              className="glass group flex flex-col gap-3 p-5 text-left transition hover:bg-white/10 active:scale-[0.98]"
            >
              <div className={cn("flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br", c.gradient)}>
                <Icon className="h-6 w-6 text-white" aria-hidden="true" />
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <h2 className="font-bold">{c.title}</h2>
                  <ArrowRight className="h-4 w-4 text-white/30 transition group-hover:translate-x-0.5 group-hover:text-white/60" aria-hidden="true" />
                </div>
                <p className="mt-1 text-xs leading-relaxed text-white/55">{c.desc}</p>
              </div>
              <p className="mt-auto flex items-center gap-1 text-[11px] font-semibold text-[#f5c96b]">
                <Trophy className="h-3 w-3" aria-hidden="true" />
                {c.stat}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
