"use client";

// Shared icon component for subjects (single import site, reused by
// Dashboard / SubjectsOverview / SubjectView).
// A real <SubjectIcon /> component instead of a function call keeps
// the React Compiler happy (no components created during render).

import {
  Calculator,
  Scale,
  ShieldCheck,
  Swords,
  Languages,
  BookOpenText,
  Users,
  GraduationCap,
  Landmark,
  BookOpenCheck,
} from "lucide-react";

const MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Calculator,
  Scale,
  ShieldCheck,
  Swords,
  Languages,
  BookOpenText,
  Users,
  GraduationCap,
  Landmark,
};

export function SubjectIcon({ name, className }: { name: string; className?: string }) {
  const Cmp = MAP[name] ?? BookOpenCheck;
  return <Cmp className={className} aria-hidden="true" />;
}
