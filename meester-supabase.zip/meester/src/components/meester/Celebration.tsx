"use client";

// ============================================================
// CELEBRATION — "Golden Dragon / Fireworks" for a perfect 10/10
// ------------------------------------------------------------
// Fullscreen overlay with a custom canvas firework particle
// system (gold / christmas-red / pine-green) + a golden dragon
// emblem + the motto: "Doel bereikt. Discipline overwint."
// ============================================================

import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

const COLORS = ["#f5c96b", "#f8dd9a", "#e04355", "#3baf75", "#ffffff"];

function DragonEmblem() {
  // Stylised golden dragon silhouette inside a festive ring
  return (
    <svg viewBox="0 0 120 120" className="h-28 w-28 drop-shadow-[0_0_24px_rgba(245,201,107,0.55)]">
      <defs>
        <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f8dd9a" />
          <stop offset="55%" stopColor="#f5c96b" />
          <stop offset="100%" stopColor="#d9a441" />
        </linearGradient>
      </defs>
      <circle cx="60" cy="60" r="54" fill="none" stroke="url(#goldGrad)" strokeWidth="2.5" opacity="0.9" />
      <circle cx="60" cy="60" r="47" fill="none" stroke="url(#goldGrad)" strokeWidth="0.8" opacity="0.5" />
      {/* dragon: serpentine body + head */}
      <path
        d="M22 74 C 30 58, 40 66, 47 58 C 54 50, 50 42, 58 38 C 66 34, 74 38, 78 32 C 82 27, 88 28, 90 33 C 92 38, 88 42, 84 43 C 86 47, 84 52, 79 52 C 72 52, 70 58, 62 62 C 54 66, 48 78, 38 80 C 32 81, 26 80, 22 74 Z"
        fill="url(#goldGrad)"
      />
      <circle cx="86" cy="34" r="1.8" fill="#0a1128" />
      {/* flame tail */}
      <path d="M22 74 C 16 76, 12 80, 10 86 C 16 84, 20 82, 24 78 Z" fill="url(#goldGrad)" opacity="0.85" />
      <text x="60" y="104" textAnchor="middle" fontSize="13" fontWeight="700" fill="url(#goldGrad)">
        10/10
      </text>
    </svg>
  );
}

export default function Celebration({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Firework particle system — three bursts, then gentle rain
  useEffect(() => {
    if (!open) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const W = window.innerWidth;
    const H = window.innerHeight;
    const particles: Particle[] = [];

    const burst = (cx: number, cy: number) => {
      const count = 90 + Math.floor(Math.random() * 40);
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.2;
        const speed = 2 + Math.random() * 4.5;
        particles.push({
          x: cx,
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 0,
          maxLife: 60 + Math.random() * 50,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
          size: 1.4 + Math.random() * 2,
        });
      }
    };

    burst(W * 0.3, H * 0.32);
    const t1 = setTimeout(() => burst(W * 0.7, H * 0.28), 350);
    const t2 = setTimeout(() => burst(W * 0.5, H * 0.22), 750);

    let raf = 0;
    let running = true;
    const tick = () => {
      if (!running) return;
      ctx.clearRect(0, 0, W, H);
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.05; // gravity
        p.vx *= 0.985;
        p.vy *= 0.985;
        const alpha = Math.max(0, 1 - p.life / p.maxLife);
        if (alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-[oklch(0.1_0.04_268/0.82)] backdrop-blur-md"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label="Doel bereikt"
        >
          <canvas ref={canvasRef} className="absolute inset-0" aria-hidden="true" />
          <motion.div
            initial={{ scale: 0.6, y: 40 }}
            animate={{ scale: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 220, damping: 16 }}
            className="relative z-10 flex flex-col items-center gap-4 px-6 text-center"
          >
            <DragonEmblem />
            <h2 className="gold-text text-3xl font-extrabold tracking-tight sm:text-4xl">
              Doel bereikt.
            </h2>
            <p className="text-xl font-semibold text-white/90 sm:text-2xl">
              Discipline overwint.
            </p>
            <p className="max-w-sm text-sm text-white/60">
              Gouden Draak behaald — perfecte score. Zoals de vlam niet vraagt of het
              koud is, vraagt jij niet of het makkelijk was.
            </p>
            <button
              onClick={onClose}
              className="mt-2 rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] px-8 py-3 text-sm font-bold text-[#0a1128] transition hover:brightness-110 active:scale-95"
            >
              Verder met discipline
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
