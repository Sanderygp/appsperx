"use client";

// ============================================================
// DUAL N-BACK — working-memory trainer ("Hoger IQ" gym)
// ------------------------------------------------------------
// HOW IT TRAINS YOUR BRAIN:
// A 3×3 grid; every ~2.5s a square lights up AND a letter is
// spoken (Web Speech API, Dutch voices when available). You must
// answer: does the POSITION match N trials back? does the LETTER?
// Holding two streams against a moving window is exactly the
// "dual" load proven to tax working memory (Jaeggi et al.).
//
// Score = accuracy against the objective matches:
//   hits / (hits + misses + false alarms), per stream.
// ============================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { useMeester } from "@/lib/store";
import { cn } from "@/lib/utils";
import { ArrowLeft, Brain, Play, Square, Volume2, Trophy } from "lucide-react";

const LETTERS = ["B", "F", "H", "K", "M", "Q", "R", "T"];
const TRIAL_MS = 2500;

interface Trial {
  pos: number; // 0..8
  letter: string;
}

type Stream = "pos" | "letter";

export default function NBackView() {
  const { progress, submitPuzzle, setView } = useMeester();
  const [phase, setPhase] = useState<"setup" | "run" | "done">("setup");
  const [n, setN] = useState(2);
  const [totalTrials, setTotalTrials] = useState(24); // incl. n warm-up trials
  const [active, setActive] = useState<number | null>(null);
  const [letter, setLetter] = useState<string>("");
  const [pressed, setPressed] = useState<{ pos: boolean; letter: boolean }>({ pos: false, letter: false });

  const seq = useRef<Trial[]>([]);
  const idx = useRef(-1);
  const pressRef = useRef({ pos: false, letter: false });
  const stats = useRef({ posHit: 0, posMiss: 0, posFA: 0, letHit: 0, letMiss: 0, letFA: 0 });
  const [trialNum, setTrialNum] = useState(0); // rendered counter (1-based)
  const [finalScore, setFinalScore] = useState<number | null>(null);

  const speak = useCallback((l: string) => {
    try {
      const synth = window.speechSynthesis;
      if (!synth) return;
      const u = new SpeechSynthesisUtterance(l);
      const nl = synth.getVoices().find((v) => v.lang?.toLowerCase().startsWith("nl"));
      u.lang = nl ? nl.lang : "nl-NL";
      u.rate = 1.1;
      synth.speak(u);
    } catch {
      /* speech unsupported: the letter still shows visually */
    }
  }, []);

  const finish = useCallback(async () => {
    const s = stats.current;
    const posAcc = s.posHit + s.posMiss + s.posFA === 0 ? 0 : s.posHit / (s.posHit + s.posMiss + s.posFA);
    const letAcc = s.letHit + s.letMiss + s.letFA === 0 ? 0 : s.letHit / (s.letHit + s.letMiss + s.letFA);
    const score = Math.round(((posAcc + letAcc) / 2) * 100);
    setFinalScore(score);
    setPhase("done");
    await submitPuzzle("nback-dual", "nback", score, n, score >= 80);
  }, [n, submitPuzzle]);

  const start = () => {
    seq.current = [];
    for (let i = 0; i < totalTrials; i++) {
      seq.current.push({
        pos: Math.floor(Math.random() * 9),
        letter: LETTERS[Math.floor(Math.random() * LETTERS.length)],
      });
    }
    idx.current = -1;
    stats.current = { posHit: 0, posMiss: 0, posFA: 0, letHit: 0, letMiss: 0, letFA: 0 };
    pressRef.current = { pos: false, letter: false };
    setPressed({ pos: false, letter: false });
    setFinalScore(null);
    setTrialNum(0);
    setPhase("run");
  };

  // Trial loop
  useEffect(() => {
    if (phase !== "run") return;
    const t = setInterval(() => {
      // evaluate previous trial first
      if (idx.current >= n) {
        const cur = seq.current[idx.current];
        const back = seq.current[idx.current - n];
        const s = stats.current;
        const pr = pressRef.current;
        const posMatch = cur.pos === back.pos;
        const letMatch = cur.letter === back.letter;
        if (posMatch && pr.pos) s.posHit++;
        else if (posMatch && !pr.pos) s.posMiss++;
        else if (!posMatch && pr.pos) s.posFA++;
        if (letMatch && pr.letter) s.letHit++;
        else if (letMatch && !pr.letter) s.letMiss++;
        else if (!letMatch && pr.letter) s.letFA++;
      }
      idx.current++;
      if (idx.current >= seq.current.length) {
        clearInterval(t);
        finish();
        return;
      }
      setTrialNum(idx.current + 1);
      // evaluate press validity of the JUST-finished window is handled above;
      // reset presses for the new trial
      pressRef.current = { pos: false, letter: false };
      setPressed({ pos: false, letter: false });
      setActive(seq.current[idx.current].pos);
      setLetter(seq.current[idx.current].letter);
      speak(seq.current[idx.current].letter);
      setTimeout(() => setActive(null), Math.min(900, TRIAL_MS - 400));
    }, TRIAL_MS);
    return () => clearInterval(t);
  }, [phase, n, finish, speak]);

  const press = useCallback((stream: Stream) => {
    if (pressRef.current[stream]) return;
    pressRef.current[stream] = true;
    setPressed((p) => ({ ...p, [stream]: true }));
  }, []);

  // Keyboard: A = position, L = letter
  useEffect(() => {
    if (phase !== "run") return;
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "a") press("pos");
      if (k === "l") press("letter");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, press]);

  const best = progress.puzzles["nback-dual"];

  // ---------- SETUP / DONE ----------
  if (phase !== "run") {
    const score = finalScore ?? 0;

    return (
      <div className="space-y-5">
        <button
          onClick={() => setView({ name: "gym" })}
          className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Breingym
        </button>

        <div className="glass-strong p-8 text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-[#f5c96b] to-[#a92638]">
            <Brain className="h-10 w-10 text-[#0a1128]" aria-hidden="true" />
          </div>
          <h1 className="text-2xl font-extrabold">Dual {n}-Back</h1>
          {phase === "setup" ? (
            <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-white/60">
              Een vierkant licht op én je hoort een letter. Druk op <b>Positie</b> (toets A) als de
              positie gelijk is aan {n} stappen terug, en op <b>Letter</b> (toets L) als de letter
              gelijk is aan {n} stappen terug. Beide? Druk beide. Dit traint je werkgeheugen.
            </p>
          ) : (
            <div className="mt-3">
              <p className="gold-text text-5xl font-extrabold">{score}%</p>
              <p className="mt-1 text-sm text-white/60">
                {score >= 80
                  ? "Uitstekend. Verhoog naar een hogere N voor meer groei."
                  : "Herhaal dagelijks — werkgeheugen groeit met discipline."}
              </p>
              {best && (
                <p className="mt-2 flex items-center justify-center gap-1 text-xs text-white/40">
                  <Trophy className="h-3.5 w-3.5 text-[#f5c96b]" aria-hidden="true" />
                  Beste score: {best.bestScore}% · niveau {best.bestLevel}
                </p>
              )}
            </div>
          )}

          {phase === "setup" && (
            <div className="mt-5 flex items-center justify-center gap-2" role="group" aria-label="Kies N-niveau">
              {[1, 2, 3].map((v) => (
                <button
                  key={v}
                  onClick={() => setN(v)}
                  className={cn(
                    "rounded-2xl border px-5 py-2.5 text-sm font-bold transition",
                    n === v ? "border-[#f5c96b] bg-[#f5c96b]/15 text-[#f5c96b]" : "border-white/10 bg-white/5 text-white/60 hover:bg-white/10"
                  )}
                >
                  N = {v}
                </button>
              ))}
            </div>
          )}

          <button
            onClick={start}
            className="mt-6 flex items-center gap-2 rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] px-8 py-3.5 text-base font-bold text-[#0a1128] transition hover:brightness-110 active:scale-95"
          >
            <Play className="h-5 w-5" aria-hidden="true" />
            {phase === "setup" ? "Start training" : "Nog een ronde"}
          </button>
        </div>
      </div>
    );
  }

  // ---------- RUN ----------
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setPhase("setup")}
          className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        >
          <Square className="h-4 w-4" aria-hidden="true" /> Stoppen
        </button>
        <p className="text-xs font-semibold text-white/50">
          Trial {trialNum}/{totalTrials} · Dual {n}-Back
        </p>
      </div>

      {/* Grid */}
      <div className="glass-strong mx-auto grid w-full max-w-xs grid-cols-3 gap-2 p-3" aria-label="N-back grid" aria-live="polite">
        {Array.from({ length: 9 }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "aspect-square rounded-2xl transition-all duration-200",
              active === i
                ? "scale-105 bg-gradient-to-br from-[#f5c96b] to-[#d9a441] shadow-[0_0_30px_rgba(245,201,107,0.5)]"
                : "bg-white/6 bg-white/5"
            )}
          />
        ))}
      </div>

      {/* Letter display (visual fallback next to speech) */}
      <div className="text-center">
        <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-2xl font-extrabold text-[#f5c96b]">
          {letter || <Volume2 className="h-5 w-5 text-white/30" aria-hidden="true" />}
        </span>
      </div>

      {/* Response buttons */}
      <div className="mx-auto grid w-full max-w-md grid-cols-2 gap-3">
        <button
          onMouseDown={() => press("pos")}
          onTouchStart={() => press("pos")}
          className={cn(
            "rounded-3xl border-2 py-5 text-base font-extrabold transition active:scale-95",
            pressed.pos ? "border-[#3baf75] bg-[#3baf75]/25 text-[#3baf75]" : "border-white/15 bg-white/5 text-white/85 hover:bg-white/10"
          )}
        >
          Positie
          <span className="mt-0.5 block text-[10px] font-semibold text-white/40">toets A</span>
        </button>
        <button
          onMouseDown={() => press("letter")}
          onTouchStart={() => press("letter")}
          className={cn(
            "rounded-3xl border-2 py-5 text-base font-extrabold transition active:scale-95",
            pressed.letter ? "border-[#f5c96b] bg-[#f5c96b]/25 text-[#f5c96b]" : "border-white/15 bg-white/5 text-white/85 hover:bg-white/10"
          )}
        >
          Letter
          <span className="mt-0.5 block text-[10px] font-semibold text-white/40">toets L</span>
        </button>
      </div>
      <p className="text-center text-xs text-white/35">
        Elke ronde duurt ~{Math.round((totalTrials * TRIAL_MS) / 1000)} seconden. Volhouden is de oefening.
      </p>
    </div>
  );
}
