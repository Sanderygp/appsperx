"use client";

// ============================================================
// LOGIC GRID VIEW — deduction puzzles (fluid intelligence)
// Fill every cell; each value used exactly once per category.
// Score = % correct cells on first submission of the session.
// ============================================================

import { useMemo, useState } from "react";
import { useMeester } from "@/lib/store";
import { LOGIC_PUZZLES } from "@/lib/logicPuzzles";
import { cn } from "@/lib/utils";
import { ArrowLeft, CheckCircle2, Lightbulb, RotateCcw, Trophy } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function LogicGridView() {
  const { progress, submitPuzzle } = useMeester();
  const [puzzleIdx, setPuzzleIdx] = useState(0);
  const puzzle = LOGIC_PUZZLES[puzzleIdx];
  const [selections, setSelections] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState(false);
  const [scoreSaved, setScoreSaved] = useState<Record<string, number>>({});

  const key = (entity: string, cat: string) => `${puzzle.id}:${entity}:${cat}`;

  const isComplete = puzzle.entities.every((e) =>
    puzzle.categories.every((c) => selections[key(e, c.key)])
  );

  const results = checked
    ? (() => {
        let correct = 0;
        const total = puzzle.entities.length * puzzle.categories.length;
        const cells: Record<string, boolean> = {};
        for (const e of puzzle.entities) {
          for (const c of puzzle.categories) {
            const ok = selections[key(e, c.key)] === puzzle.solution[e]?.[c.key];
            cells[key(e, c.key)] = ok;
            if (ok) correct++;
          }
        }
        return { correct, total, cells, pct: Math.round((correct / total) * 100) };
      })()
    : null;

  const check = async () => {
    setChecked(true);
    if (results) {
      const pct = Math.round((results.correct / results.total) * 100);
      const solved = pct === 100;
      setScoreSaved((s) => ({ ...s, [puzzle.id]: pct }));
      await submitPuzzle(puzzle.id, "logic", pct, puzzle.difficulty, solved);
    }
  };

  const reset = () => {
    setSelections({});
    setChecked(false);
  };

  const best = progress.puzzles[puzzle.id];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={() => {
            setPuzzleIdx((i) => Math.max(0, i - 1));
            reset();
          }}
          disabled={puzzleIdx === 0}
          className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold disabled:opacity-30"
        >
          Vorige
        </button>
        <p className="text-xs font-semibold text-white/50">
          Puzzel {puzzleIdx + 1}/{LOGIC_PUZZLES.length} · moeilijkheid {puzzle.difficulty}/3
        </p>
        <button
          onClick={() => {
            setPuzzleIdx((i) => Math.min(LOGIC_PUZZLES.length - 1, i + 1));
            reset();
          }}
          disabled={puzzleIdx === LOGIC_PUZZLES.length - 1}
          className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-bold disabled:opacity-30"
        >
          Volgende
        </button>
      </div>

      <div className="glass-strong p-6">
        <div className="mb-1 flex items-center justify-between">
          <h1 className="text-xl font-extrabold">{puzzle.title}</h1>
          {best && (
            <span className="flex items-center gap-1 text-xs text-white/40">
              <Trophy className="h-3.5 w-3.5 text-[#f5c96b]" aria-hidden="true" />
              beste: {best.bestScore}%
            </span>
          )}
        </div>
        <p className="text-sm leading-relaxed text-white/60">{puzzle.intro}</p>

        <div className="mt-4 rounded-2xl border border-[#f5c96b]/20 bg-[#f5c96b]/8 p-4">
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-[#f5c96b]">
            <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" /> Aanwijzingen
          </p>
          <ol className="space-y-1.5">
            {puzzle.clues.map((c, i) => (
              <li key={i} className="flex gap-2 text-sm text-white/75">
                <span className="font-bold text-white/40">{i + 1}.</span>
                {c}
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* Matrix */}
      <div className="glass overflow-x-auto p-4">
        <table className="w-full min-w-96 border-collapse">
          <thead>
            <tr>
              <th className="p-2 text-left text-xs font-bold uppercase tracking-widest text-white/45">Persoon</th>
              {puzzle.categories.map((c) => (
                <th key={c.key} className="p-2 text-left text-xs font-bold uppercase tracking-widest text-white/45">
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {puzzle.entities.map((entity) => (
              <tr key={entity} className="border-t border-white/8">
                <td className="p-2 text-sm font-bold">{entity}</td>
                {puzzle.categories.map((c) => {
                  const cellOk = results?.cells[key(entity, c.key)];
                  return (
                    <td key={c.key} className="p-2">
                      <Select
                        value={selections[key(entity, c.key)] ?? ""}
                        onValueChange={(v) => {
                          if (checked) setChecked(false);
                          setSelections((s) => ({ ...s, [key(entity, c.key)]: v }));
                        }}
                      >
                        <SelectTrigger
                          className={cn(
                            "w-full rounded-xl border-white/10 bg-white/5 text-sm",
                            checked && (cellOk ? "border-[#3baf75]/60 text-[#3baf75]" : "border-[#e04355]/60 text-[#ff9aa5]")
                          )}
                        >
                          <SelectValue placeholder="Kies…" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#111a38] border-white/10">
                          {c.values.map((v) => (
                            <SelectItem key={v} value={v} className="text-sm focus:bg-white/10">
                              {v}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-2 text-[11px] text-white/35">
          Elke waarde komt precies één keer voor per kolom.
        </p>
      </div>

      {checked && results && (
        <div
          className={cn(
            "glass flex items-center gap-3 p-4",
            results.pct === 100 ? "border-[#3baf75]/40" : "border-[#e04355]/30"
          )}
          role="status"
        >
          {results.pct === 100 ? (
            <CheckCircle2 className="h-6 w-6 shrink-0 text-[#3baf75]" aria-hidden="true" />
          ) : (
            <RotateCcw className="h-6 w-6 shrink-0 text-[#e04355]" aria-hidden="true" />
          )}
          <p className="text-sm">
            {results.pct === 100 ? (
              <>
                <b className="text-[#3baf75]">Logica-meester.</b> Alle {results.total} cellen correct — vloeibare
                intelligentie in actie.
              </>
            ) : (
              <>
                <b className="text-[#ff9aa5]">{results.correct}/{results.total} cellen correct.</b> Lees de
                aanwijzingen opnieuw en kies één schakel die nog open is.
              </>
            )}
          </p>
        </div>
      )}

      <div className="flex gap-2">
        <button
          onClick={check}
          disabled={!isComplete}
          className={cn(
            "h-13 flex-1 rounded-full py-3.5 text-base font-bold transition active:scale-[0.98]",
            isComplete
              ? "bg-gradient-to-r from-[#f5c96b] to-[#d9a441] text-[#0a1128] hover:brightness-110"
              : "cursor-not-allowed bg-white/5 text-white/30"
          )}
        >
          Controleer oplossing
        </button>
        <button
          onClick={reset}
          className="rounded-full border border-white/15 bg-white/5 px-5 font-bold transition hover:bg-white/10"
          aria-label="Puzzel leegmaken"
        >
          <RotateCcw className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
