"use client";

// ============================================================
// SUBJECTS OVERVIEW — grid of all 9 vakken
// ============================================================

import { useMeester } from "@/lib/store";
import { SUBJECTS, subjectProgress } from "@/lib/curriculum";
import { cn } from "@/lib/utils";
import { SubjectIcon } from "./subjectIcons";

export default function SubjectsOverview() {
  const { progress, setView } = useMeester();

  return (
    <div className="space-y-4">
      <header>
        <h1 className="text-2xl font-extrabold tracking-tight">Vakken</h1>
        <p className="mt-1 text-sm text-white/55">
          Negen vakken, één norm: alles of niets. Elke oefentoets vraagt een perfecte 10/10.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {SUBJECTS.map((s) => {
          const p = subjectProgress(s, progress.lessons, progress.tests);
          return (
            <button
              key={s.id}
              onClick={() => setView({ name: "subject", subjectId: s.id })}
              className="glass group flex flex-col gap-3 p-5 text-left transition hover:bg-white/10 active:scale-[0.98]"
            >
              <div className={cn("flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br", s.gradient)}>
                <SubjectIcon name={s.icon} className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-bold leading-tight">{s.name}</h2>
                  <span className={cn("text-xs font-bold", p.pct === 100 ? "text-[#3baf75]" : "text-white/50")}>
                    {p.pct}%
                  </span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-white/50">{s.description}</p>
              </div>
              <div className="mt-auto">
                <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-700",
                      p.testPassed ? "bg-gradient-to-r from-[#3baf75] to-[#1f7a4d]" : "bg-gradient-to-r from-[#f5c96b] to-[#d9a441]"
                    )}
                    style={{ width: `${Math.max(3, p.pct)}%` }}
                  />
                </div>
                <p className="mt-2 text-[11px] text-white/40">
                  {s.lessons.length} lessen · {s.flashcards.length} kaarten · {s.tests.length} toetsen
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
