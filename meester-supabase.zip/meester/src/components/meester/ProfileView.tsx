"use client";

// ============================================================
// PROFILE — rank ladder, stats, ornaments (badges), logout
// ============================================================

import { useMeester } from "@/lib/store";
import { RANKS, rankForXp } from "@/lib/ranks";
import { SUBJECTS, allFlashcards } from "@/lib/curriculum";
import { cn } from "@/lib/utils";
import {
  Award,
  BadgeCheck,
  Binoculars,
  BookOpenCheck,
  Crown,
  Eye,
  Flame,
  Medal,
  Shield,
  Star,
  TreePine,
  Brain,
  Sparkles,
  CircleDot,
  LogOut,
} from "lucide-react";

const RANK_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Shield,
  Eye,
  Binoculars,
  BadgeCheck,
  Medal,
  Award,
  Star,
  Crown,
  Flame,
};

export default function ProfileView() {
  const { user, progress, logout } = useMeester();
  const xp = progress.streak.xp;
  const rank = rankForXp(xp);
  const cards = allFlashcards();

  const lessonsDone = Object.keys(progress.lessons).length;
  const testsPassed = Object.values(progress.tests).filter((t) => t.passed).length;
  const perfect = Object.values(progress.tests).filter((t) => t.passed && t.score === t.total).length;
  const cardsLearned = Object.keys(progress.srs).length;
  const reviews = progress.streak.reviews;
  const logicSolved = Object.entries(progress.puzzles).filter(([k, v]) => k.startsWith("logic-") && v.solved).length;
  const nbackBest = progress.puzzles["nback-dual"]?.bestLevel ?? 0;
  const feynmanDone = Object.values(progress.feynman).filter((f) => f.completed).length;

  // Ornaments — kerstballen = badges
  const ornaments = [
    { label: "Eerste les", icon: BookOpenCheck, earned: lessonsDone >= 1, hint: "Voltooi je eerste les" },
    { label: "7-daagse streak", icon: Flame, earned: progress.streak.longest >= 7, hint: "Houd 7 dagen achter elkaar je streak vast" },
    { label: "10/10 Schutter", icon: Sparkles, earned: perfect >= 1, hint: "Behaal een perfecte oefentoets" },
    { label: "Gouden Draak ×3", icon: Crown, earned: perfect >= 3, hint: "Drie perfecte oefentoetsen" },
    { label: "SRS-Veteraan", icon: TreePine, earned: reviews >= 50, hint: "50 flashcard-herhalingen" },
    { label: "Brein-atleet", icon: Brain, earned: nbackBest >= 3 || logicSolved >= 2, hint: "N-Back niveau 3 of 2 logica-puzzels" },
    { label: "Feynman-Meester", icon: Medal, earned: feynmanDone >= 1, hint: "Voltooi één Feynman-analyse" },
    { label: "Vak-voltooid", icon: Award, earned: SUBJECTS.some((s) => s.lessons.every((l) => progress.lessons[l.id])), hint: "Alle lessen van één vak" },
  ];

  return (
    <div className="space-y-5">
      {/* Identity card */}
      <header className="glass-strong p-6 text-center">
        <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#f5c96b] to-[#a92638] text-3xl font-extrabold text-[#0a1128]">
          {(user?.name ?? "?").charAt(0).toUpperCase()}
        </div>
        <h1 className="text-xl font-extrabold">{user?.name}</h1>
        <p className="text-xs text-white/45">{user?.email}</p>
        <p className="gold-text mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-4 py-1.5 text-sm font-bold">
          {(() => {
            const Icon = RANK_ICONS[rank.current.icon] ?? Shield;
            return <Icon className="h-4 w-4" aria-hidden="true" />;
          })()}
          {rank.current.name} · {xp} XP
        </p>
        <p className="mt-2 text-xs italic text-white/45">{rank.current.description}</p>
      </header>

      {/* Stats */}
      <section className="glass grid grid-cols-2 gap-4 p-5 sm:grid-cols-4" aria-label="Statistieken">
        {[
          { label: "Lessen", value: lessonsDone, sub: `van ${SUBJECTS.reduce((n, s) => n + s.lessons.length, 0)}` },
          { label: "Toetsen", value: testsPassed, sub: "behaald" },
          { label: "Kaarten", value: cardsLearned, sub: `van ${cards.length} geleerd` },
          { label: "Herhalingen", value: reviews, sub: "totaal" },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <p className="gold-text text-2xl font-extrabold">{s.value}</p>
            <p className="text-xs font-bold text-white/70">{s.label}</p>
            <p className="text-[10px] text-white/40">{s.sub}</p>
          </div>
        ))}
      </section>

      {/* Rank ladder */}
      <section className="glass p-5" aria-label="Rangleer">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
          <Crown className="h-4 w-4 text-[#f5c96b]" aria-hidden="true" /> Rangleer — discipline meet je groei
        </h2>
        <div className="space-y-1.5">
          {RANKS.map((r) => {
            const reached = xp >= r.minXp;
            const Icon = RANK_ICONS[r.icon] ?? Shield;
            return (
              <div
                key={r.name}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border px-3.5 py-2.5",
                  reached ? "border-[#f5c96b]/30 bg-[#f5c96b]/8" : "border-white/8 bg-white/[0.03] opacity-55"
                )}
              >
                <div
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-xl",
                    reached ? "bg-gradient-to-br from-[#f5c96b] to-[#d9a441] text-[#0a1128]" : "bg-white/10 text-white/40"
                  )}
                >
                  <Icon className="h-4.5 w-4.5 h-5 w-5" aria-hidden="true" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold">{r.name}</p>
                  <p className="text-[11px] text-white/45">{r.description}</p>
                </div>
                <span className="text-xs font-bold text-white/40">{r.minXp} XP</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Ornaments (badges) */}
      <section className="glass p-5" aria-label="Ornamenten">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
          <CircleDot className="h-4 w-4 text-[#e04355]" aria-hidden="true" /> Ornamenten — kerstballen aan jouw boom
        </h2>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {ornaments.map((o) => {
            const Icon = o.icon;
            return (
              <div
                key={o.label}
                title={o.hint}
                className={cn(
                  "flex flex-col items-center gap-2 rounded-2xl border p-4 text-center transition",
                  o.earned
                    ? "border-[#f5c96b]/35 bg-gradient-to-b from-[#f5c96b]/12 to-transparent"
                    : "border-white/8 bg-white/[0.03] opacity-45"
                )}
              >
                <div
                  className={cn(
                    "flex h-12 w-12 items-center justify-center rounded-full",
                    o.earned ? "bg-gradient-to-br from-[#f5c96b] via-[#e04355] to-[#a92638] text-white shadow-[0_0_18px_rgba(245,201,107,0.35)]" : "bg-white/10 text-white/30"
                  )}
                >
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </div>
                <p className="text-[11px] font-bold leading-tight">{o.label}</p>
              </div>
            );
          })}
        </div>
      </section>

      <button
        onClick={logout}
        className="flex h-12 w-full items-center justify-center gap-2 rounded-full border border-[#e04355]/40 bg-[#e04355]/10 text-sm font-bold text-[#ff9aa5] transition hover:bg-[#e04355]/20"
      >
        <LogOut className="h-4 w-4" aria-hidden="true" /> Uitloggen
      </button>
      <div className="pb-2" />
    </div>
  );
}
