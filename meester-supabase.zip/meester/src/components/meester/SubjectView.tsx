"use client";

// ============================================================
// SUBJECT VIEW — lessons / flashcards / practice tests per vak
// The 10/10 gate: tests are locked until ALL lessons are done.
// ============================================================

import { useMeester } from "@/lib/store";
import { SUBJECT_BY_ID } from "@/lib/curriculum";
import { cn } from "@/lib/utils";
import {
  ArrowLeft,
  CheckCircle2,
  Circle,
  Clock,
  Lock,
  ChevronRight,
  Layers,
  Repeat,
  ClipboardCheck,
} from "lucide-react";
import { SubjectIcon } from "./subjectIcons";

export default function SubjectView({ subjectId }: { subjectId: string }) {
  const { progress, setView } = useMeester();
  const subject = SUBJECT_BY_ID.get(subjectId);
  if (!subject) return null;

  const lessonsDone = subject.lessons.filter((l) => progress.lessons[l.id]).length;
  const allLessonsDone = lessonsDone === subject.lessons.length;


  return (
    <div className="space-y-5">
      <button
        onClick={() => setView({ name: "subjects" })}
        className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        aria-label="Terug naar vakken"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Alle vakken
      </button>

      {/* Header */}
      <header className="glass overflow-hidden">
        <div className={cn("h-20 bg-gradient-to-br", subject.gradient)} />
        <div className="p-5 pt-4">
          <div className="-mt-10 mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-white/20 bg-[oklch(0.22_0.05_268/0.95)] shadow-lg">
            <SubjectIcon name={subject.icon} className="h-7 w-7 text-[#f5c96b]" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">{subject.name}</h1>
          <p className="mt-1 text-sm text-white/60">{subject.description}</p>
        </div>
      </header>

      {/* Lessons */}
      <section className="glass p-5" aria-label="Lessen">
        <div className="mb-3 flex items-center gap-2">
          <Layers className="h-4 w-4 text-[#f5c96b]" aria-hidden="true" />
          <h2 className="text-sm font-bold uppercase tracking-widest text-white/60">
            Lessen · {lessonsDone}/{subject.lessons.length}
          </h2>
        </div>
        <div className="space-y-2">
          {subject.lessons.map((lesson) => {
            const done = Boolean(progress.lessons[lesson.id]);
            return (
              <button
                key={lesson.id}
                onClick={() => setView({ name: "lesson", subjectId, lessonId: lesson.id })}
                className={cn(
                  "flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left transition hover:bg-white/10",
                  done ? "border-[#3baf75]/35 bg-[#3baf75]/8" : "border-white/10 bg-white/5"
                )}
              >
                {done ? (
                  <CheckCircle2 className="h-5 w-5 shrink-0 text-[#3baf75]" aria-hidden="true" />
                ) : (
                  <Circle className="h-5 w-5 shrink-0 text-white/30" aria-hidden="true" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{lesson.title}</p>
                  <p className="flex items-center gap-1 text-xs text-white/45">
                    <Clock className="h-3 w-3" aria-hidden="true" /> {lesson.durationMin} min
                  </p>
                </div>
                <ChevronRight className="h-4 w-4 text-white/30" aria-hidden="true" />
              </button>
            );
          })}
        </div>
      </section>

      {/* Flashcards */}
      <section className="glass flex flex-wrap items-center gap-4 p-5" aria-label="Flashcards">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#3baf75] to-[#1f7a4d]">
          <Repeat className="h-6 w-6 text-white" aria-hidden="true" />
        </div>
        <div className="flex-1">
          <h2 className="font-bold">Flashcards · SRS</h2>
          <p className="text-xs text-white/50">
            {subject.flashcards.length} kaarten · IJzeren Vuist-schema (Ebbinghaus)
          </p>
        </div>
        <button
          onClick={() => setView({ name: "flashcards", subjectId })}
          className="rounded-full border border-white/15 bg-white/5 px-5 py-2.5 text-sm font-bold transition hover:bg-white/10 active:scale-95"
        >
          Oefenen
        </button>
      </section>

      {/* Tests — the 10/10 gate */}
      <section className="glass p-5" aria-label="Oefentoetsen">
        <div className="mb-3 flex items-center gap-2">
          <ClipboardCheck className="h-4 w-4 text-[#e04355]" aria-hidden="true" />
          <h2 className="text-sm font-bold uppercase tracking-widest text-white/60">
            Oefentoetsen · 10/10 vereist
          </h2>
        </div>
        {!allLessonsDone && (
          <p className="mb-3 rounded-xl border border-[#f5c96b]/25 bg-[#f5c96b]/8 px-3 py-2 text-xs text-[#f8dd9a]">
            <Lock className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />
            Voltooi eerst alle lessen om de toets te ontgrendelen. IJzeren vuist: geen snelkoppelingen.
          </p>
        )}
        <div className="space-y-2">
          {subject.tests.map((test) => {
            const result = progress.tests[test.id];
            const unlocked = allLessonsDone;
            return (
              <div
                key={test.id}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border px-4 py-3.5 transition",
                  unlocked ? "border-white/10 bg-white/5 hover:bg-white/10" : "border-white/5 bg-white/[0.02] opacity-60"
                )}
              >
                {unlocked ? (
                  <ClipboardCheck className={cn("h-5 w-5 shrink-0", result?.passed ? "text-[#3baf75]" : "text-[#f5c96b]")} aria-hidden="true" />
                ) : (
                  <Lock className="h-5 w-5 shrink-0 text-white/30" aria-hidden="true" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{test.title}</p>
                  <p className="text-xs text-white/45">
                    {test.questions.length} vragen
                    {result ? ` · beste score: ${result.score}/${result.total}${result.passed ? " ✓ behaald" : ""}` : " · nog niet gemaakt"}
                  </p>
                </div>
                {unlocked ? (
                  <button
                    onClick={() => setView({ name: "test", subjectId, testId: test.id })}
                    className="rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] px-4 py-2 text-xs font-bold text-[#0a1128] transition hover:brightness-110 active:scale-95"
                  >
                    {result?.passed ? "Opnieuw" : "Start"}
                  </button>
                ) : (
                  <Lock className="h-4 w-4 text-white/25" aria-hidden="true" />
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
