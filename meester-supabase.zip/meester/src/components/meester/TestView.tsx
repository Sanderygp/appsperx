"use client";

// ============================================================
// PRACTICE TEST — the 10/10 gate
// ------------------------------------------------------------
// One question per screen (iOS flow). Submitting scores the
// attempt; ONLY a perfect score passes. 10/10 triggers the
// Golden Dragon / Fireworks celebration. Below 10/10 the
// review screen shows every answer + explanation: "Opnieuw.
// Discipline overwint."
// ============================================================

import { useState } from "react";
import { useMeester } from "@/lib/store";
import { SUBJECT_BY_ID } from "@/lib/curriculum";
import { cn } from "@/lib/utils";
import { ArrowLeft, CheckCircle2, XCircle, Loader2, RotateCcw, Swords } from "lucide-react";

type Phase = "quiz" | "result";

export default function TestView({ subjectId, testId }: { subjectId: string; testId: string }) {
  const { submitTest, setView, setCelebration } = useMeester();
  const subject = SUBJECT_BY_ID.get(subjectId);
  const test = subject?.tests.find((t) => t.id === testId);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [phase, setPhase] = useState<Phase>("quiz");
  const [score, setScore] = useState(0);
  const [busy, setBusy] = useState(false);
  if (!subject || !test) return null;

  const currentIdx = test.questions.findIndex((q) => !answers[q.id] && answers[q.id] !== 0);
  const active = currentIdx === -1 ? test.questions.length : currentIdx;
  const question = test.questions[Math.min(active, test.questions.length - 1)];
  const answeredCount = Object.keys(answers).length;

  const choose = (idx: number) => {
    setAnswers((a) => ({ ...a, [question.id]: idx }));
  };

  const submit = async () => {
    setBusy(true);
    try {
      const s = test.questions.reduce((n, q) => n + (answers[q.id] === q.answerIndex ? 1 : 0), 0);
      const res = await submitTest(subjectId, testId, s, test.questions.length);
      setScore(s);
      setPhase("result");
      if (res.passed && test.questions.length === 10) {
        setCelebration(true, true); // Golden Dragon: 10/10!
      }
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setAnswers({});
    setPhase("quiz");
    setScore(0);
  };

  // ---------- RESULT ----------
  if (phase === "result") {
    const perfect = score === test.questions.length;
    return (
      <div className="space-y-5">
        <div className="glass-strong p-8 text-center">
          <div
            className={cn(
              "mx-auto flex h-24 w-24 items-center justify-center rounded-full",
              perfect ? "bg-gradient-to-br from-[#f5c96b] to-[#d9a441]" : "bg-gradient-to-br from-[#e04355] to-[#a92638]"
            )}
          >
            <span className="text-3xl font-extrabold text-[#0a1128]">
              {score}<span className="text-lg">/{test.questions.length}</span>
            </span>
          </div>
          <h1 className={cn("mt-4 text-2xl font-extrabold", perfect ? "gold-text" : "text-white")}>
            {perfect ? "Gouden Draak behaald!" : "Opnieuw. Discipline overwint."}
          </h1>
          <p className="mx-auto mt-2 max-w-sm text-sm text-white/60">
            {perfect
              ? "Perfecte score. Dit is de norm — niet de uitzondering. Volgende vak wacht."
              : "Alleen 10/10 telt. Lees de uitleg hieronder, herhaal de flashcards, en kom terug. Elke poging maakt je scherper."}
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button
              onClick={reset}
              className="flex items-center gap-2 rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] px-6 py-3 text-sm font-bold text-[#0a1128] transition hover:brightness-110 active:scale-95"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" /> Opnieuw
            </button>
            <button
              onClick={() => setView({ name: "subject", subjectId })}
              className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold transition hover:bg-white/10"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Terug naar vak
            </button>
          </div>
        </div>

        {/* Per-question review */}
        <div className="space-y-3">
          {test.questions.map((q, i) => {
            const chosen = answers[q.id];
            const ok = chosen === q.answerIndex;
            return (
              <div key={q.id} className="glass p-5">
                <div className="mb-2 flex items-start gap-2.5">
                  {ok ? (
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#3baf75]" aria-hidden="true" />
                  ) : (
                    <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-[#e04355]" aria-hidden="true" />
                  )}
                  <p className="text-sm font-semibold">
                    {i + 1}. {q.question}
                  </p>
                </div>
                <div className="ml-8 space-y-1.5">
                  {!ok && chosen !== undefined && (
                    <p className="text-xs text-[#ff9aa5]">Jouw antwoord: {q.options[chosen]}</p>
                  )}
                  <p className="text-xs font-semibold text-[#3baf75]">Correct: {q.options[q.answerIndex]}</p>
                  <p className="text-xs leading-relaxed text-white/55">{q.explanation}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // ---------- QUIZ ----------
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setView({ name: "subject", subjectId })}
          className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> {subject.name}
        </button>
        <p className="flex items-center gap-1.5 text-xs font-semibold text-white/50">
          <Swords className="h-3.5 w-3.5 text-[#e04355]" aria-hidden="true" />
          {answeredCount}/{test.questions.length}
        </p>
      </div>

      {/* Progress dots */}
      <div className="flex gap-1.5">
        {test.questions.map((q, i) => (
          <div
            key={q.id}
            className={cn(
              "h-1.5 flex-1 rounded-full transition",
              i < answeredCount ? "bg-[#f5c96b]" : i === active ? "bg-white/40" : "bg-white/10"
            )}
          />
        ))}
      </div>

      <div className="glass-strong p-6 sm:p-8" aria-live="polite">
        <p className="mb-1 text-[11px] uppercase tracking-widest text-white/45">{test.title}</p>
        <h1 className="text-xl font-bold leading-relaxed">{question.question}</h1>

        <div className="mt-5 space-y-2" role="radiogroup" aria-label="Antwoordopties">
          {question.options.map((opt, idx) => {
            const selected = answers[question.id] === idx;
            return (
              <button
                key={idx}
                onClick={() => choose(idx)}
                role="radio"
                aria-checked={selected}
                className={cn(
                  "flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left text-sm transition active:scale-[0.99]",
                  selected
                    ? "border-[#f5c96b] bg-[#f5c96b]/15 font-semibold text-white"
                    : "border-white/10 bg-white/5 text-white/80 hover:bg-white/10"
                )}
              >
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                    selected ? "bg-[#f5c96b] text-[#0a1128]" : "bg-white/10 text-white/60"
                  )}
                >
                  {String.fromCharCode(65 + idx)}
                </span>
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      <button
        onClick={submit}
        disabled={answeredCount < test.questions.length || busy}
        className={cn(
          "flex h-14 w-full items-center justify-center gap-2 rounded-full text-base font-bold transition active:scale-[0.98]",
          answeredCount < test.questions.length || busy
            ? "cursor-not-allowed bg-white/5 text-white/30"
            : "bg-gradient-to-r from-[#e04355] to-[#a92638] text-white hover:brightness-110"
        )}
      >
        {busy ? (
          <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
        ) : (
          "Inleveren — alleen 10/10 telt"
        )}
      </button>
    </div>
  );
}
