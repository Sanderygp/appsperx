"use client";

// ============================================================
// FEYNMAN TECHNIQUE — 4 steps, tracked and saved to the cloud
// ------------------------------------------------------------
// 1. KIES een begrip
// 2. LEG UIT alsof je het aan een 12-jarige vertelt
// 3. WIJS de hiaten aan (waar je vastliep = wat je niet begrijpt)
// 4. VEREENVOUDIG met een analogie
// Completed = all four steps have real content. +80 XP.
// ============================================================

import { useMemo, useState } from "react";
import { useMeester } from "@/lib/store";
import { SUBJECTS } from "@/lib/curriculum";
import { cn } from "@/lib/utils";
import { ArrowLeft, Check, ChevronLeft, ChevronRight, PenLine, Trash2 } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

const STEP_TITLES = [
  "Leg uit aan een 12-jarige",
  "Wijs je hiaten aan",
  "Vereenvoudig + analogie",
  "Slotcontrole",
];
const STEP_HINTS = [
  "Schrijf in gewone taal uit wat dit begrip betekent. Geen jargon. Alsof je het aan je kleine broertje uitlegt.",
  "Waar liep je vast? Welke woorden moest je vermijden? Welke vraag kon je niet beantwoorden? Dít is wat je nog moet leren.",
  "Vereenvoudig je uitleg en voeg één analogie toe uit het dagelijks leven.",
  "Lees alles terug. Is het kort, correct en volledig? Pas aan wat nodig is en sluit af.",
];

export default function FeynmanView() {
  const { progress, saveFeynman, setView } = useMeester();
  const concepts = useMemo(
    () => SUBJECTS.flatMap((s) => s.feynmanConcepts.map((c) => ({ ...c, subject: s.name }))),
    []
  );

  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const concept = concepts.find((c) => c.key === selectedKey);
  const entry = selectedKey ? progress.feynman[selectedKey] : undefined;

  const [step, setStep] = useState(0);
  const [texts, setTexts] = useState<string[]>(["", "", "", ""]);
  const [busy, setBusy] = useState(false);

  const open = (key: string) => {
    const existing = progress.feynman[key];
    setSelectedKey(key);
    setStep(existing ? Math.min(3, existing.stepsDone) : 0);
    setTexts(
      existing && existing.steps.length === 4 ? [...existing.steps] : ["", "", "", ""]
    );
  };

  const persist = async (completed: boolean) => {
    if (!concept) return;
    setBusy(true);
    try {
      await saveFeynman(concept.key, concept.label, texts, completed ? 4 : step, completed);
    } finally {
      setBusy(false);
    }
  };

  const saveDraft = async () => {
    await persist(false);
  };

  const finish = async () => {
    await persist(true);
    setStep(4);
  };

  // ---------- Concept picker ----------
  if (!concept) {
    const doneCount = concepts.filter((c) => progress.feynman[c.key]?.completed).length;
    return (
      <div className="space-y-4">
        <header className="glass p-5">
          <h1 className="text-2xl font-extrabold tracking-tight">Feynman-techniek</h1>
          <p className="mt-1 text-sm leading-relaxed text-white/60">
            &ldquo;Als je iets niet eenvoudig kunt uitleggen, begrijp je het niet goed genoeg.&rdquo;
            Kies een begrip, leg het uit in vier stappen, en de app bewaart je gedachtegang.
            Voltooid = alle vier de stappen ingevuld. ({doneCount}/{concepts.length} voltooid)
          </p>
        </header>

        <div className="grid gap-2 sm:grid-cols-2">
          {concepts.map((c) => {
            const e = progress.feynman[c.key];
            return (
              <button
                key={c.key}
                onClick={() => open(c.key)}
                className={cn(
                  "glass flex items-center gap-3 p-4 text-left transition hover:bg-white/10",
                  e?.completed && "border-[#3baf75]/40 bg-[#3baf75]/8"
                )}
              >
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                    e?.completed ? "bg-gradient-to-br from-[#3baf75] to-[#1f7a4d]" : "bg-white/8 bg-white/10"
                  )}
                >
                  {e?.completed ? (
                    <Check className="h-5 w-5 text-white" aria-hidden="true" />
                  ) : (
                    <PenLine className="h-5 w-5 text-white/70" aria-hidden="true" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold">{c.label}</p>
                  <p className="text-xs text-white/45">
                    {c.subject}
                    {e ? ` · ${e.stepsDone}/4 stappen` : " · niet begonnen"}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const completed = Boolean(entry?.completed) || step === 4;

  // ---------- Wizard ----------
  return (
    <div className="space-y-5">
      <button
        onClick={() => {
          saveDraft();
          setSelectedKey(null);
        }}
        className="flex items-center gap-1.5 text-sm font-semibold text-white/60 transition hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Alle begrippen
      </button>

      <div className="glass-strong p-6">
        <p className="text-xs uppercase tracking-widest text-white/45">{concept.subject}</p>
        <h1 className="mt-1 text-xl font-extrabold">{concept.label}</h1>

        {/* Step indicator */}
        <div className="mt-4 flex items-center gap-1.5">
          {[0, 1, 2, 3].map((i) => (
            <button
              key={i}
              onClick={() => setStep(i)}
              aria-label={`Stap ${i + 1}`}
              className={cn(
                "h-1.5 flex-1 rounded-full transition",
                i === step ? "bg-[#f5c96b]" : texts[i] ? "bg-[#3baf75]/60" : "bg-white/10"
              )}
            />
          ))}
        </div>

        <div className="mt-4">
          <p className="text-xs font-bold uppercase tracking-widest text-[#f5c96b]">
            Stap {step + 1}/4
          </p>
          <h2 className="mt-1 text-lg font-bold">{STEP_TITLES[step]}</h2>
          <p className="mt-1 text-sm text-white/55">{STEP_HINTS[step]}</p>
          <Textarea
            value={texts[step]}
            onChange={(e) => setTexts((t) => t.map((v, i) => (i === step ? e.target.value : v)))}
            placeholder="Schrijf hier je uitleg…"
            className="mt-3 min-h-40 rounded-2xl border-white/10 bg-white/5 text-sm leading-relaxed"
          />
        </div>

        <div className="mt-4 flex items-center justify-between gap-2">
          <button
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0}
            className="flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold disabled:opacity-30"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" /> Vorige
          </button>
          <button
            onClick={saveDraft}
            disabled={busy}
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-white/70 transition hover:bg-white/10"
          >
            Concept opslaan
          </button>
          {step < 3 ? (
            <button
              onClick={() => setStep((s) => Math.min(3, s + 1))}
              className="flex items-center gap-1 rounded-full bg-gradient-to-r from-[#f5c96b] to-[#d9a441] px-4 py-2 text-sm font-bold text-[#0a1128] transition hover:brightness-110"
            >
              Volgende <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          ) : (
            <button
              onClick={finish}
              disabled={busy || !texts.every((t) => t.trim().length > 5)}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-bold transition",
                texts.every((t) => t.trim().length > 5)
                  ? "bg-gradient-to-r from-[#3baf75] to-[#1f7a4d] text-white hover:brightness-110"
                  : "cursor-not-allowed bg-white/5 text-white/30"
              )}
            >
              Voltooi (+80 XP)
            </button>
          )}
        </div>
      </div>

      {completed && (
        <div className="glass flex items-center gap-3 border-[#3baf75]/40 p-4" role="status">
          <Check className="h-6 w-6 shrink-0 text-[#3baf75]" aria-hidden="true" />
          <p className="text-sm">
            <b className="text-[#3baf75]">Gedachtegang voltooid.</b> Je kunt dit begrip nu eenvoudig
            uitleggen — dát is meesterschap, niet uitwendigheid.
          </p>
          <button
            onClick={async () => {
              await saveFeynman(concept.key, concept.label, ["", "", "", ""], 0, false);
              open(concept.key);
            }}
            className="ml-auto rounded-full border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
            aria-label="Opnieuw beginnen"
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  );
}
