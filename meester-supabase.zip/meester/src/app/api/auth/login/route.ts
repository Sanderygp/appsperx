import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");

    const user = await db.user.findUnique({ where: { email } });
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json(
        { error: "Onjuiste inloggegevens. Discipline: probeer opnieuw." },
        { status: 401 }
      );
    }

    await touchStreak(user.id, 0);
    await setSessionCookie(createSessionToken(user.id));

    return NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name },
      progress: await buildProgressPayload(user.id),
    });
  } catch {
    return NextResponse.json({ error: "Inloggen mislukt. Probeer opnieuw." }, { status: 500 });
  }
}
