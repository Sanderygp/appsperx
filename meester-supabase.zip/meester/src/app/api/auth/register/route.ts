import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");

    if (name.length < 2) {
      return NextResponse.json({ error: "Naam moet minstens 2 tekens zijn." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: "Voer een geldig e-mailadres in." }, { status: 400 });
    }
    if (password.length < 6) {
      return NextResponse.json({ error: "Wachtwoord moet minstens 6 tekens zijn." }, { status: 400 });
    }

    const existing = await db.user.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json(
        { error: "Dit e-mailadres bestaat al. Log in." },
        { status: 409 }
      );
    }

    const user = await db.user.create({
      data: { email, name, passwordHash: hashPassword(password) },
    });

    await touchStreak(user.id, 0);
    await setSessionCookie(createSessionToken(user.id));

    return NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name },
      progress: await buildProgressPayload(user.id),
    });
  } catch {
    return NextResponse.json({ error: "Registreren mislukt. Probeer opnieuw." }, { status: 500 });
  }
}
