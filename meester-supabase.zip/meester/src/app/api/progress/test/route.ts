import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

const XP_PASS = 100;
const XP_PERFECT_BONUS = 50;

/** POST { testId, subjectId, score, total } — only a PERFECT score passes the gate. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });

  const body = await req.json();
  const testId = String(body.testId ?? "");
  const subjectId = String(body.subjectId ?? "");
  const score = Math.max(0, Number(body.score ?? 0));
  const total = Math.max(1, Number(body.total ?? 1));
  if (!testId || !subjectId) {
    return NextResponse.json({ error: "testId en subjectId vereist." }, { status: 400 });
  }

  // Keep the BEST result ever achieved for this test.
  const existing = await db.testAttempt.findUnique({
    where: { userId_testId: { userId: user.id, testId } },
  });
  const bestScore = Math.max(score, existing?.score ?? 0);
  const passed = score >= total || Boolean(existing?.passed);

  await db.testAttempt.upsert({
    where: { userId_testId: { userId: user.id, testId } },
    update: { score: bestScore, total: { set: total }, passed: { set: passed } },
    create: { userId: user.id, testId, subjectId, score: bestScore, total, passed },
  });

  // XP only for the moment the test is FIRST passed perfectly.
  let xpGained = 0;
  if (score >= total && !existing?.passed) {
    xpGained = XP_PASS + (total === 10 ? XP_PERFECT_BONUS : 0);
    await touchStreak(user.id, xpGained);
  }

  return NextResponse.json({
    progress: await buildProgressPayload(user.id),
    xpGained,
    passed: score >= total,
    perfect: score >= total && total === 10,
  });
}
