import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

const XP_LESSON = 50;

/** POST { lessonId, subjectId, completed } — instantly written to the DB. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });

  const body = await req.json();
  const lessonId = String(body.lessonId ?? "");
  const subjectId = String(body.subjectId ?? "");
  const completed = Boolean(body.completed);
  if (!lessonId || !subjectId) {
    return NextResponse.json({ error: "lessonId en subjectId vereist." }, { status: 400 });
  }

  if (completed) {
    await db.lessonProgress.upsert({
      where: { userId_lessonId: { userId: user.id, lessonId } },
      update: {},
      create: { userId: user.id, lessonId, subjectId },
    });
    await touchStreak(user.id, XP_LESSON);
  } else {
    await db.lessonProgress.deleteMany({ where: { userId: user.id, lessonId } });
  }

  return NextResponse.json({ progress: await buildProgressPayload(user.id), xpGained: completed ? XP_LESSON : 0 });
}
