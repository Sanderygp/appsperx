import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

/**
 * POST /api/progress/activity — the "heartbeat".
 * Called on app start and after meaningful actions. Keeps the
 * Daily Discipline streak alive (server-authoritative, Europe/Amsterdam).
 */
export async function POST() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });
  await touchStreak(user.id, 0);
  return NextResponse.json({ progress: await buildProgressPayload(user.id) });
}
