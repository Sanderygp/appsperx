import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload } from "@/lib/progress";

/** GET /api/progress — full state dump; called on every app start. */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });
  return NextResponse.json({ progress: await buildProgressPayload(user.id) });
}
