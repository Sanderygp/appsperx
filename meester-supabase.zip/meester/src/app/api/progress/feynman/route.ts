import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

const XP_COMPLETE = 80;

/** POST { conceptKey, concept, steps: string[4], stepsDone, completed } — Feynman technique. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });

  const body = await req.json();
  const conceptKey = String(body.conceptKey ?? "");
  const concept = String(body.concept ?? "");
  const steps: string[] = Array.isArray(body.steps) ? body.steps.map(String) : [];
  const stepsDone = Math.max(0, Math.min(4, Number(body.stepsDone ?? 0)));
  const completed = Boolean(body.completed);
  if (!conceptKey) return NextResponse.json({ error: "conceptKey vereist." }, { status: 400 });

  const existing = await db.feynmanEntry.findUnique({
    where: { userId_conceptKey: { userId: user.id, conceptKey } },
  });

  await db.feynmanEntry.upsert({
    where: { userId_conceptKey: { userId: user.id, conceptKey } },
    update: {
      concept: { set: concept },
      steps: { set: JSON.stringify(steps) },
      stepsDone: { set: stepsDone },
      completed: { set: completed || Boolean(existing?.completed) },
    },
    create: { userId: user.id, conceptKey, concept, steps: JSON.stringify(steps), stepsDone, completed },
  });

  let xpGained = 0;
  if (completed && !existing?.completed) {
    xpGained = XP_COMPLETE;
    await touchStreak(user.id, xpGained);
  }

  return NextResponse.json({ progress: await buildProgressPayload(user.id), xpGained });
}
