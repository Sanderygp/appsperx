import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";

const XP_NEW_BEST = 30;

/** POST { puzzleKey, puzzleType, score, level, solved } — cognitive gym scores. */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });

  const body = await req.json();
  const puzzleKey = String(body.puzzleKey ?? "");
  const puzzleType = String(body.puzzleType ?? "nback");
  const score = Math.max(0, Number(body.score ?? 0));
  const level = Math.max(0, Number(body.level ?? 0));
  const solved = Boolean(body.solved);
  if (!puzzleKey) return NextResponse.json({ error: "puzzleKey vereist." }, { status: 400 });

  const existing = await db.puzzleScore.findUnique({
    where: { userId_puzzleKey: { userId: user.id, puzzleKey } },
  });

  const isNewBest = score > (existing?.bestScore ?? -1);

  await db.puzzleScore.upsert({
    where: { userId_puzzleKey: { userId: user.id, puzzleKey } },
    update: {
      bestScore: Math.max(score, existing?.bestScore ?? 0),
      bestLevel: Math.max(level, existing?.bestLevel ?? 0),
      plays: { increment: 1 },
      solved: solved || Boolean(existing?.solved),
    },
    create: { userId: user.id, puzzleKey, puzzleType, bestScore: score, bestLevel: level, plays: 1, solved },
  });

  let xpGained = 0;
  if (isNewBest) {
    xpGained = XP_NEW_BEST;
    await touchStreak(user.id, xpGained);
  }

  return NextResponse.json({ progress: await buildProgressPayload(user.id), xpGained, isNewBest });
}
