import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { buildProgressPayload, touchStreak } from "@/lib/progress";
import { review, type SrsGrade } from "@/lib/srs";

const XP_REVIEW = 2;

/**
 * POST { cardId, subjectId, grade }
 * Runs the SM-2 (Ebbinghaus) algorithm server-side so the schedule
 * is identical on every device. The new card state is stored and the
 * full payload is returned.
 */
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Niet ingelogd." }, { status: 401 });

  const body = await req.json();
  const cardId = String(body.cardId ?? "");
  const subjectId = String(body.subjectId ?? "");
  const grade = String(body.grade ?? "good") as SrsGrade;
  if (!cardId) return NextResponse.json({ error: "cardId vereist." }, { status: 400 });

  const existing = await db.srsCard.findUnique({
    where: { userId_cardId: { userId: user.id, cardId } },
  });

  const next = review(
    existing
      ? {
          easeFactor: existing.easeFactor,
          intervalDays: existing.intervalDays,
          repetitions: existing.repetitions,
          lapses: existing.lapses,
          dueDate: existing.dueDate.toISOString(),
          lastReviewed: existing.lastReviewed?.toISOString(),
        }
      : {},
    grade
  );

  await db.srsCard.upsert({
    where: { userId_cardId: { userId: user.id, cardId } },
    update: {
      easeFactor: next.easeFactor,
      intervalDays: next.intervalDays,
      repetitions: next.repetitions,
      lapses: next.lapses,
      dueDate: new Date(next.dueDate),
      lastReviewed: new Date(next.lastReviewed!),
    },
    create: {
      userId: user.id,
      cardId,
      subjectId,
      easeFactor: next.easeFactor,
      intervalDays: next.intervalDays,
      repetitions: next.repetitions,
      lapses: next.lapses,
      dueDate: new Date(next.dueDate),
      lastReviewed: new Date(next.lastReviewed!),
    },
  });

  await db.streak.updateMany({ where: { userId: user.id }, data: { reviews: { increment: 1 } } });
  await touchStreak(user.id, XP_REVIEW);

  return NextResponse.json({
    progress: await buildProgressPayload(user.id),
    xpGained: XP_REVIEW,
    nextCard: {
      cardId,
      easeFactor: next.easeFactor,
      intervalDays: next.intervalDays,
      repetitions: next.repetitions,
      lapses: next.lapses,
      dueDate: next.dueDate,
      lastReviewed: next.lastReviewed,
    },
  });
}
