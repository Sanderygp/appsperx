import MeesterApp from "@/components/meester/MeesterApp";

export default function Page() {
  return <MeesterApp />;
}
