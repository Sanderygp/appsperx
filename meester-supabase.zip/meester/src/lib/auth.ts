// ============================================================
// MEESTER — Authentication & session helpers
// ------------------------------------------------------------
// Email/password auth with zero external dependencies:
//  - Password hashing: Node crypto.scrypt (salted, 64 bytes)
//  - Sessions: HMAC-SHA256 signed token in an httpOnly cookie
//    (same mechanism a Supabase JWT session fulfils in prod)
//
// PRODUCTION NOTE (Supabase): swap this file for
// @supabase/ssr with createServerClient() — the API routes keep
// the exact same shape (getCurrentUser() → User | null).
// ============================================================

import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

const SECRET =
  process.env.SESSION_SECRET || "meester-dev-secret-change-me-in-production";
const COOKIE_NAME = "meester_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 dagen

// Prod-waarschuwing (Vercel): zonder SESSION_SECRET zijn sessies
// met een bekende standaardkey getekend → iemand kan een cookie
// vervalsen. Zet dus ALTIJD SESSION_SECRET in de Vercel-env-vars.
if (process.env.NODE_ENV === "production" && !process.env.SESSION_SECRET) {
  console.warn(
    "WAARSCHUWING: SESSION_SECRET is niet ingesteld! " +
      "Zet deze environment variable in Vercel (Settings → Environment Variables)."
  );
}

export interface SessionUser {
  id: string;
  email: string;
  name: string;
}

// ---------- password hashing ----------

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return (
    candidate.length === expected.length &&
    timingSafeEqual(candidate, expected)
  );
}

// ---------- signed session token ----------

function sign(payload: string): string {
  return createHmac("sha256", SECRET).update(payload).digest("base64url");
}

export function createSessionToken(userId: string): string {
  const payload = Buffer.from(
    JSON.stringify({ uid: userId, exp: Date.now() + MAX_AGE_SECONDS * 1000 })
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string): string | null {
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return null;
  if (sign(payload) !== signature) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (typeof data.uid !== "string" || typeof data.exp !== "number") return null;
    if (Date.now() > data.exp) return null;
    return data.uid;
  } catch {
    return null;
  }
}

// ---------- cookie helpers ----------

export async function setSessionCookie(token: string) {
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.set(COOKIE_NAME, "", { httpOnly: true, path: "/", maxAge: 0 });
}

/** Returns the logged-in user, or null. Used by every API route. */
export async function getCurrentUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const userId = verifySessionToken(token);
  if (!userId) return null;
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, name: true },
  });
  return user ?? null;
}
