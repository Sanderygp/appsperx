import type { Subject } from "./types";

// ============================================================
// VAK 6 — NEDERLANDS (spelling, grammatica, communicatie)
// ============================================================

export const nederlands: Subject = {
  id: "nederlands",
  name: "Nederlands",
  short: "Nederlands",
  tagline: "Een rapport met spelfouten is een rapport met een zwak plek.",
  description:
    "Werkwoordspelling, de/t-fouten, zinsbouw, kommaregels en professionele schriftelijke communicatie: de taalvaardigheid die je boetes en rapporten onweerlegbaar maakt.",
  gradient: "from-orange-500/80 to-amber-600/60",
  accent: "text-orange-300",
  icon: "BookOpenText",
  lessons: [
    {
      id: "ned-1",
      title: "Werkwoordspelling en de 't fokschaap",
      durationMin: 25,
      intro:
        "Spelfouten in een proces-verbaal zijn geen detail: ze ondermijnen je betrouwbaarheid. Deze les maakt je werkwoordspelling examenvast.",
      sections: [
        {
          heading: "Tegenwoordige tijd: stam + t",
          body: "De stam van het werkwoord = infinitief minus -en (lopen → loop). Regel: ik + stam (ik loop). Hij/zij/het + stam + t (hij loopt). Jij + stam, behalve als jij VOOR het werkwoord staat: 'loop jij?' maar 'jij loopt'. Meervoud: wij lopen (hele werkwoord). De klassieke fout: 'wij loopt' — onthoud: wij = hele werkwoord, altijd.",
          bullets: [
            "ik loop | jij loopt (als jij ervoor) | hij loopt",
            "wij/jullie/zij lopen — hele werkwoord",
            "Vraag: 'Loop jij?' (t valt weg)",
          ],
        },
        {
          heading: "Verleden tijd: 't fokschaap",
          body: "Verleden tijd van zwakke werkwoorden: stam + te/de of ten/den. De truc is het 't fokschaap: woorden die eindigen op f, k, s, ch, p krijgen T (stemloze medeklinkers); andere medeklinkers (b, d, g, l, m, n, r, v, w, z) krijgen D (stemhebbend). Voorbeelden: werken (k → werkte), reizen (z → reisde), plassen (p → plaste), horen (r → hoorde). Twijfelgeval? Maak het lang: 'hij reisde' — spreek het uit als 'reisduh' → D.",
        },
        {
          heading: "Voltooid deelwoord: ge- ... -d/-t",
          body: "Het voltooid deelwoord van zwakke werkwoorden: ge- + stam + d of t volgens hetzelfde fokschaap: gewerkt (k), gereisd (z), geplast (p), gehoord (r). LET OP werkwoorden op -eren (antwoorden → geantwoord, geen extra ge- na het eren-deel? wel: antwoord → geantwoord) en werkwoorden met be-/ver-/ont-/her- krijgen GEEN ge-: 'hij heeft geantwoord' (met ge-) maar 'hij heeft verteld' (geen ge-). Dit onderscheid staat elk jaar op het examen.",
        },
        {
          heading: "De/het en trema's",
          body: "De of het? Ongeveer 75% is 'de'; 'het' bij: verkleinwoorden (het huisje), talen (het Nederlands), landen/steden (meestal), metals (het ijzer), en vaste uitzonderingen (het water, het wiel, het theater, het bedrijf). Twee klinkers die niet samen één klank vormen krijgen een trema: reëel, beïnvloeden, geïnteresseerd. In rapporten schrijf je 'het college' correct — de/het-fouten vallen direct op bij een boetebesluit.",
        },
      ],
      keyPoints: [
        "Stam = ik-vorm; hij/zij/het = stam + t; wij = hele ww",
        "'t fokschaap: f-k-s-ch-p → T, rest → D",
        "be-/ver-/ont-/her- werkwoorden: geen ge-",
        "Trema bij twee klinkers die geen klankverbinding vormen",
      ],
    },
    {
      id: "ned-2",
      title: "Zinsdelen, komma's en zinsbouw",
      durationMin: 25,
      intro:
        "Wie zinsdelen herkent, schrijft zinnen die nooit dubbelzinnig zijn — essentieel in juridische teksten waar elk woord telt.",
      sections: [
        {
          heading: "Persoonsvorm, onderwerp en gezegde",
          body: "De persoonsvorm (pv) is het vervoegde werkwoord: zet de zin in een andere tijd en het woord dat verandert is de pv ('De man loopt weg.' → 'De man liep weg.' → loopt/liep = pv). Het onderwerp is wie of wat + pv: 'Wie loopt er weg? De man.' Het gezegde = pv + rest van de werkwoorden. Als je pv en onderwerp kunt vinden, kun je elk zinsdeel vinden — en fouten vermijden als 'de man en ik loopt' (fout: meervoud → lopen).",
        },
        {
          heading: "Kommaregels die ertoe doen",
          body: "Vier regels dekken 90% van je behoefte: (1) Komma tussen opsommingen: 'hij schreeuwde, sloeg en rende weg.' (2) Komma tussen hoofdzin en bijzin: 'Ik zag dat de man wegliep, terwijl hij schreeuwde.' (3) Geen komma tussen onderwerp en pv, ook niet bij lange zinsdelen: FOUT 'De man die ik aansprak, rende' — dit MAG eigenlijk met toevoeging tussen komma's... maar tussen Onderwerp-PV zelf nooit: 'De man, die ik aansprak, rende weg.' (tussenkomma's rond de bijzin, niet voor de pv). (4) Komma bij aansluiting: 'Ik vroeg zijn naam, maar hij liep door.'",
          bullets: [
            "Opsomming: a, b en c",
            "Bijzin na/voor hoofdzin afzonderen",
            "Nooit komma tussen onderwerp en persoonsvorm",
          ],
        },
        {
          heading: "Woordvolgorde in de zin",
          body: "Hoofdzin: gebruik het eenvoudige model VOOR – PV – MIDDEN – ACHTER. Vraagzin: pv eerst ('Liep de man weg?'). Bijzin: pv staat ACHTERAAN ('...dat de man wegliep'). Met deze drie patronen kun je elke zin correct bouwen — en in rapporten kies je korte hoofdzinnen; bijzinnen alleen als ze inhoud toevoegen.",
        },
      ],
      keyPoints: [
        "PV vinden = tijdtest; onderwerp = wie/wat + pv",
        "Nooit komma tussen onderwerp en pv",
        "Bijzin: pv achteraan",
        "Korte hoofdzinnen = heldere rapporten",
      ],
    },
    {
      id: "ned-3",
      title: "Professionele schriftelijke communicatie",
      durationMin: 20,
      intro:
        "Van boetebrief tot e-mail aan je teamleider: professioneel Nederlands volgt vaste vormregels. Beheers ze en je schrijft als een volgende inspecteur.",
      sections: [
        {
          heading: "E-mail en brief: de vaste opbouw",
          body: "Structuur: (1) Aanhef — 'Geachte heer/mevrouw Jansen' bij formeel, 'Beste Jan' bij bekenden. (2) Aanleiding — waarom je schrijft, in de eerste zin. (3) Kern — feiten en het verzoek of besluit, logisch geordend. (4) Afsluiting — wat je verwacht ('Ik ontvang graag uw reactie vóór 1 januari.') en groet ('Met vriendelijke groet,'). Vermijd: spreektaal ('even bellen misschien?'), uitroeptekens, en onnodige omwoording ('Ik zou zeggen dat misschien wellicht...').",
        },
        {
          heading: "Feitelijk en neutraal formuleren",
          body: "In handhavingsteksten geldt: geen emotie, geen oordelen, geen bijvoeglijke maar meetbare woorden. Niet 'de man was agressief' maar 'de man verhoogde zijn stem en verscheen met gebalde vuisten'. Niet 'de winkel was smerig' maar 'in de winkel lagen etensresten op drie tafels'. Deze stijl heet zakelijk-neutraal en is de standaard voor alle officiële documenten.",
        },
        {
          heading: "Spreektaal versus schrijftaal",
          body: "Spreektaal: 'Toen ging die gast heel erg brutaal doen.' Schrijftaal: 'Vervolgens gedroeg de betrokkene zich onbeschoft.' Verschillen: geen straattaal ('gast', 'die'), geen samensmeltend ('d'r' → 'er'), volledige zinnen, correcte woordkeus ('betrokkene' in plaats van 'de man' is juristentaal — in een PV is 'de verdachte' of 'de man' prima). Lees je tekst terug hardop: klinkt het als een rapport of als een praatje op straat?",
        },
      ],
      keyPoints: [
        "E-mail: aanhef → aanleiding → kern → concrete afsluiting",
        "Zakelijk-neutraal: meetbaar, geen oordeel",
        "Schrijftaal: volledige zinnen, geen straattaal",
        "Hardop teruglezen = foutenvanger",
      ],
    },
  ],
  flashcards: [
    { id: "ned-f1", front: "hij/wij + 'lopen': correct?", back: "hij loopt, wij lopen — wij neemt het hele werkwoord" },
    { id: "ned-f2", front: "'jij loopt' vs 'loop jij?' — wanneer geen t?", back: "Als jij ACHTER het werkwoord staat (vraagvorm)" },
    { id: "ned-f3", front: "'t fokschaap letters?", back: "f, k, s, ch, p → te; overige medeklinkers → de" },
    { id: "ned-f4", front: "werken in verleden tijd?", back: "werkte (k → T)" },
    { id: "ned-f5", front: "reizen in verleden tijd?", back: "reisde (z → D)" },
    { id: "ned-f6", front: "Voltooid deelwoord van 'antwoorden'?", back: "geantwoord (op -eren: alleen ge- vooraan)" },
    { id: "ned-f7", front: "Wanneer GEEN ge- in voltooid deelwoord?", back: "Bij be-, ver-, ont-, her-: verteld, ontdekt, herhaald" },
    { id: "ned-f8", front: "Trema nodig: 'reeel' of 'reëel'?", back: "reëel — twee klinkers die niet één klank vormen" },
    { id: "ned-f9", front: "Komma tussen onderwerp en persoonsvorm?", back: "Nooit" },
    { id: "ned-f10", front: "PV vinden met welke test?", back: "Tijdtest: zet de zin in een andere tijd; het veranderende werkwoord = pv" },
    { id: "ned-f11", front: "Niet 'de man was agressief', maar...", back: "'de man verhoogde zijn stem en verscheen met gebalde vuisten' (meetbaar)" },
    { id: "ned-f12", front: "Formele aanhef bij onbekende ontvanger?", back: "Geachte heer/mevrouw [achternaam]" },
  ],
  tests: [
    {
      id: "ned-t1",
      title: "Toets 1: Spelling & grammatica",
      questions: [
        {
          id: "ned-t1-q1",
          question: "Welke zin is correct?",
          options: ["De BOA's noteerd de feiten.", "De BOA's noteren de feiten.", "De BOA's noteert de feiten.", "De BOA's noteerden het feiten."],
          answerIndex: 1,
          explanation: "Meervoud onderwerp → hele werkwoord: noteren.",
        },
        {
          id: "ned-t1-q2",
          question: "Verleden tijd van 'plassen':",
          options: ["plasde", "plaste", "plaaste", "plassde"],
          answerIndex: 1,
          explanation: "p zit in het fokschaap → T: plaste.",
        },
        {
          id: "ned-t1-q3",
          question: "Verleden tijd van 'horen':",
          options: ["hoorde", "hoorte", "hoordde", "horede"],
          answerIndex: 0,
          explanation: "r is stemhebbend → D: hoorde.",
        },
        {
          id: "ned-t1-q4",
          question: "Voltooid deelwoord van 'vertellen':",
          options: ["geverteld", "verteld", "geverteldt", "verteldt"],
          answerIndex: 1,
          explanation: "ver- werkwoord: geen ge- → verteld.",
        },
        {
          id: "ned-t1-q5",
          question: "Welke zin heeft de juiste komma's?",
          options: [
            "De man, die ik aansprak, rende weg.",
            "De man die ik aansprak rende weg, snel.",
            "De man die, ik aansprak, rende weg.",
            "De man die ik aansprak, rende, weg.",
          ],
          answerIndex: 0,
          explanation: "De bijzin 'die ik aansprak' wordt tussen komma's gezet.",
        },
        {
          id: "ned-t1-q6",
          question: "Welke zin is correct geschreven?",
          options: [
            "Hij reageerde reëel en beïnvloedde het gesprek.",
            "Hij reageerde reeel en beinvloedde het gesprek.",
            "Hij reageerde reeel en beïnvloede het gesprek.",
            "Hij reageerde reëel en beinvloed het gesprek.",
          ],
          answerIndex: 0,
          explanation: "reëel (trema) + beïnvloedde (trema + correcte verleden tijd).",
        },
        {
          id: "ned-t1-q7",
          question: "Onderwerp in deze zin: 'Op het plein zaten drie jongeren te roken.'",
          options: ["Op het plein", "drie jongeren", "te roken", "zaten"],
          answerIndex: 1,
          explanation: "Wie zat er te roken? De jongeren → onderwerp (pv 'zaten' verwijst ernaar).",
        },
        {
          id: "ned-t1-q8",
          question: "Welke formulering hoort in een officieel rapport?",
          options: [
            "De gast was gewoon aso bezig.",
            "De betrokkene gedroeg zich onbeschoft en weigerde medewerking.",
            "Die man was echt heel erg rot.",
            "Man deed lastig, heb boete gegeven.",
          ],
          answerIndex: 1,
          explanation: "Zakelijk-neutraal: geen straattaal, wel feitelijk gedrag.",
        },
        {
          id: "ned-t1-q9",
          question: "Correcte afsluiting van een formele brief:",
          options: ["Doeg! xx", "Groetjes", "Met vriendelijke groet,", "Laters"],
          answerIndex: 2,
          explanation: "Formeel: 'Met vriendelijke groet,' met komma.",
        },
        {
          id: "ned-t1-q10",
          question: "Zet in de juiste tijd: 'Gisteren ___ (zien) ik de man weggooien.'",
          options: ["zie", "zag", "gezien", "ziet"],
          answerIndex: 1,
          explanation: "Gisteren = verleden tijd; zien is sterk: ik zag.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "ned-feyn-fokschaap", label: "Het 't fokschaap uitleggen" },
    { key: "ned-feyn-zakelijk", label: "Wat is zakelijk-neutraal taalgebruik?" },
  ],
};
