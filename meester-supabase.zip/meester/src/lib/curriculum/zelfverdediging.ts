import type { Subject } from "./types";

// ============================================================
// VAK 4 — ZELFVERDEDIGING (theorie & techniek)
// Focus: rechtmatig geweld, escalatietrap, basistechnieken
// ============================================================

export const zelfverdediging: Subject = {
  id: "zelfverdediging",
  name: "Zelfverdediging",
  short: "Zelfverdediging",
  tagline: "Geweld is het laatste middel — en dan voer je het correct uit.",
  description:
    "De juridische grenzen van geweld (noodweer, art. 41 Sr; geweldbevoegdheid ambtenaren), de escalatietrap met verhoudingsgeweld, basistechnieken theorie en nazorg na een incident.",
  gradient: "from-rose-600/80 to-red-700/60",
  accent: "text-rose-300",
  icon: "Swords",
  lessons: [
    {
      id: "zvd-1",
      title: "Rechtmatig geweld: de juridische kaders",
      durationMin: 30,
      intro:
        "Als BOA mag je in uitzonderlijke situaties geweld gebruiken — maar de wet trekt strakke grenzen. Buiten die grenzen bega je zelf een strafbaar feit. Dit hoofdstuk is examenkern én je persoonlijke bescherming.",
      sections: [
        {
          heading: "Noodweer: artikel 41 Wetboek van Strafrecht",
          body: "Noodweer (art. 41 lid 1 Sr) betekent: geen strafbaar feit als het misdrijf het gevolg is van de noodzakelijke verdediging van eigen of andermans lijf, eerbaarheid, eigendom tegen onmiddellijke onrechtmatige aanranding. Drie voorwaarden: (1) er is een ONMIDDELLIJKE aanranding — het gevaar is nu, niet gisteren of misschien later; (2) de verdediging is ONMIDDELLIJK en (3) SUBSIDIAR en PROPORTIONAL — je kiest het lichtste middel dat nog werkt, en het middel staat in verhouding tot de aanval.",
          bullets: [
            "Onmiddellijke onrechtmatige aanranding vereist",
            "Verdediging moet noodzakelijk zijn (subsidiariteit)",
            "Verhouding aanval–verdediging (proportionaliteit)",
          ],
        },
        {
          heading: "Geweldbevoegdheid van ambtenaren",
          body: "Naast noodweer hebben opsporingsambtenaren specifieke geweldbevoegdheden uit de wet: art. 164 Sv regelt het gebruik van middelen van geweld bij de uitvoering van aanhouding en voorhouding; art. 165 Sv gaat over het achtervolgen van vluchtende verdachten op heterdaad. De Algemene maatregel (Geweldsbevoegdhedenbesluit politie) rangschikt middelen: van aanwezigheid en verbale communicatie tot controleren, slag- en stoottechnieken, wapenstok, en als uiterste middel het vuurwapen. Elke stap vereist: aankondiging ('Loslaten!') en beoordeling van effect en gevolg.",
        },
        {
          heading: "Proportionaliteit en subsidiariteit in de praktijk",
          body: "Subsidiariteit: gebruik het MILDESTE middel dat nog effectief is. Proportionaliteit: het middel mag niet zwaarder zijn dan de dreiging. Voorbeeld: een persoon duwt je weg en loopt weg — een stokslag is disproportioneel; bijhouden en melding maken is het juiste middel. Maar: iemand slaat met een fles — dan kan een hardere controle (armgreep, valtechniek) proportional zijn. Noteer na elk geweldsgebruik: dreiging, jouw waarschuwing, middel, duur, effect en gevolg. Die geweldsrapportage is verplicht en beschermt jou.",
        },
        {
          heading: "Noodweerexcess en ontslag van alle straf",
          body: "Wat als je verdediging 'doorschiet'? Noodweerexcess (art. 41 lid 2 Sr) geldt als de verdediging disproportioneel was maar uit paniek of verwarring voortkwam die niet te vermijden was. Er bestaat dan geen strafbaar feit OF een strafverminderende grondslag (ontslag van alle rechtsgevolg bij psychische overmacht). Dit is geen vrijbrief: de rechter beoordeelt of de paniek begrijpelijk was. Conclusie: trainen op beheersing is de beste juridische bescherming.",
        },
      ],
      keyPoints: [
        "Noodweer = art. 41 lid 1 Sr: onmiddellijk, noodzakelijk, proportioneel",
        "Art. 164/165 Sv: geweld bij aanhouding en achtervolging",
        "Subsidiariteit: lichtste middel dat werkt",
        "Geweldsrapportage is verplicht en beschermt jou",
      ],
    },
    {
      id: "zvd-2",
      title: "De escalatietrap en verhoudingsgeweld",
      durationMin: 25,
      intro:
        "Geweldsgebruik kent in Nederland een gestructureerde trap: je stapt alleen zo hoog als nodig, en nooit hoger dan de situatie toelaat.",
      sections: [
        {
          heading: "De zes trappen",
          body: "Trap 1 AANWEZIGHEID: uniform, houding en oogcontact lossen vaak al de situatie op. Trap 2 COMMUNICATIE: aanspreken, vragen, opties geven. Trap 3 ZACHTE CONTROLE: geleiden bij de arm, controle-omklemming, tegenhouden. Trap 4 HARDE CONTROLE: slag- en stoottechnieken, valtechnieken, geweldstok. Trap 5 ZWARE MIDDELEN: chemische middelen (pepperspray, alleen bevoegden) en dienstwapen dreiging. Trap 6 VUURWAPEN: uiterste middel bij levensgevaar. Elke trap vereist een passende dreiging — trap hoogte volgt de aanval, niet je boosheid.",
          bullets: [
            "1 Aanwezigheid | 2 Communicatie | 3 Zachte controle",
            "4 Harde controle | 5 Zware middelen | 6 Vuurwapen",
            "Altijd aankondigen en afbouwen als dreiging stopt",
          ],
        },
        {
          heading: "Afbouwen en nazorg",
          body: "Zodra de weerstand stopt, stopt jouw geweld. Je bouwt af: van harde controle naar begeleiden naar communicatie. Check de aangehouden persoon op letsel en bel zo nodig hulp. Elke geweldsdaad die je toepast moet in je geweldsrapportage: welke dreiging, welke waarschuwing, welk middel, hoe lang, met welk resultaat en eventuele schade. Camera (bodycam) bevestigt jouw versie — melden dat hij draait is ook de-escalatie.",
        },
        {
          heading: "Wanneer NOOIT geweld?",
          body: "Geen geweld uit frustratie, als straf, of om gezag te tonen — geweld is een middel om een wettelijke taak uit te voeren, nooit een reactie op respectloos taalgebruik. Verbaal geweld (beledigen) maak je niet ongedaan met fysiek geweld: daarvoor is een boete of PV de route. Vraag jezelf bij elke situatie af: 'Welke wettelijke taak voer ik uit en welk middel is het lichtste dat die taak mogelijk maakt?'",
        },
      ],
      keyPoints: [
        "Zes trappen: aanwezigheid → vuurwapen",
        "Trap volgt de dreiging, nooit de emotie",
        "Afbouwen zodra weerstand stopt",
        "Geweld is taakuitvoering, geen straf",
      ],
    },
    {
      id: "zvd-3",
      title: "Basistechnieken: houding, afstand, valbreken",
      durationMin: 30,
      intro:
        "Techniek begint met theorie: waar je staat, hoe je valt, hoe je kracht ontvangt. In de leszaal oefen je deze uit; hier leer je waarom elke techniek bestaat en hoe je ze veilig uitvoert.",
      sections: [
        {
          heading: "Basispositie en afstand",
          body: "De basispositie: voeten op schouderbreedte, één voet licht achter, knieën licht gebogen, handen open en boven de taille ('tactische positie'). Gewichtsverdeling 50/50 zodat je in alle richtingen kunt bewegen. Afstand: op 1,5+ meter kan niemand je vastgrijpen zonder stap te zetten — die stap ziet en voelt jou. De 'reactieve zone' tussen 1 en 2 meter is waar aanvallen beginnen: daar vergroot je oplettendheid.",
          bullets: [
            "Voeten schouderbreedte, gewicht 50/50",
            "Handen open boven de taille",
            "1,5+ meter = grijpzone vermijden",
            "Oogcontact + omgeving scannen",
          ],
        },
        {
          heading: "Dekken en kracht ontvangen",
          body: "Dekken: handen beschermen hoofd en hals (hoog dek), of armen beschermen romp (laag dek). Bij een aanval: niet wegdraaien maar de aanval MET je lichaam ontvangen en afrollen — kracht die je meegeeft (meebewegen) verliest energie die tegen jou zou slaan. Blokkades: onderarm blokkeert inboog of uitboog, nooit botten tegen botten zonder hoek: impact dempen door mee te geven en hoek te zetten.",
        },
        {
          heading: "Vallen en valbreken",
          body: "Valbreken achterwaarts: kin op borst (hoofd beschermen), rug rond, armen 45° naar voren, slap op de grond landen door met de handen vlak en gelijktijdig te klappen — de klapslag verdeelt de impact. Zijwaarts: zelfde beginsel, arm op de valrichting. Voorwaarts: op onderarmen landen, hoofd van de grond. Trainen in de leszaal is verplicht: op gras of mat val je zacht; op straat moet je techniek automatisch zijn. Valbreken redt je bij duwen, stoten en hoge stappen.",
        },
        {
          heading: "Losmaken van grepen en afstand nemen",
          body: "Beginsel: beweeg je richting de duim (de zwakste kant van de greep) en gebruik je hele lichaam, niet alleen armkracht. Polsgreep losmaken: draai onder beweging naar de duim en stap door. Kantegreep: verlaag je centrum, stap breed, roteer heup. Na losmaken: afstand nemen, dek zetten, situatie herbeoordelen — wegrennen of vasthouden kan beide juist zijn, afhankelijk van taak en dreiging.",
        },
      ],
      keyPoints: [
        "Basispositie: 50/50 gewicht, handen open, 1,5 m afstand",
        "Kracht meegeven verliest energie",
        "Valbreken: kin omlaag, ronde rug, klappen met platte hand",
        "Losmaken: richting de duim, lichaamskracht, dan afstand",
      ],
    },
    {
      id: "zvd-4",
      title: "Na het incident: rapportage en nazorg",
      durationMin: 20,
      intro:
        "Het incident is voorbij, jouw werk niet: geweldsrapportage, letselcheck, melding en eigen nazorg bepalen of het incident juridisch en mentaal goed wordt afgesloten.",
      sections: [
        {
          heading: "Geweldsrapportage",
          body: "Elk geweldsgebruik — ook 'alleen' vasthouden — moet binnen korte termijn worden gerapporteerd: situatie (dreiging en verloop), waarschuwing die je gaf, middelen en duur, effect, letsel (beide partijen), getuigen en beeldmateriaal. Rapporteer feitelijk en volledig; een gemiste detail kan maanden later je verdediging zijn. Rapporteer ook ALS er niets gebeurde maar dreiging was — patrooninformatie helpt je team.",
        },
        {
          heading: "Nazorg voor de ander",
          body: "Na fysiek contact: check bewustzijn, ademhaling en zichtbaar letsel. Bel 112 bij verdenking van hoofdletsel of ernstig letsel. Geef water en rust, praat kalm, blijf aanwezig tot overdracht. Dit is niet zwakte: het is proportie herstellen en aantoonbaar zorgvuldig optreden. Dat verhoogt je geloofwaardigheid in elk later onderzoek.",
        },
        {
          heading: "Nazorg voor jezelf",
          body: "Adrenaline daalt na 20-45 minuten; daarna kan trillen, misselijkheid of gevoelloosheid volgen — normaal fysiologisch gedrag. Adem 4 tellen in, 6 tellen uit, enkele minuten. Praat met collega's over het incident (collegiale opvang), meld je bij je leidinggevende als het zwaar was, en zoek professionele opvang bij aanhoudende klachten (slaap, spannen, flashbacks). Sterk zijn betekent nazorg durven vragen.",
        },
      ],
      keyPoints: [
        "Rapporteer elk geweldsgebruik — feitelijke en volledig",
        "Letselcheck en hulp verlenen na fysiek contact",
        "Adrenaline-dip is normaal; adem 4-6",
        "Collegiale en professionele opvang bestaat — gebruik het",
      ],
    },
  ],
  flashcards: [
    { id: "zvd-f1", front: "Welk artikel regelt noodweer?", back: "Artikel 41 lid 1 Wetboek van Strafrecht" },
    { id: "zvd-f2", front: "Drie voorwaarden noodweer?", back: "Onmiddellijke onrechtmatige aanranding + noodzakelijke (subsidiaire) + proportionele verdediging" },
    { id: "zvd-f3", front: "Wat is noodweerexcess?", back: "Disproportionele verdediging uit niet-vermijdbare paniek/verwarring (art. 41 lid 2 Sr)" },
    { id: "zvd-f4", front: "Welk artikel Sv regelt geweld bij aanhouding?", back: "Artikel 164 Sv (165 = achtervolging op heterdaad)" },
    { id: "zvd-f5", front: "Noem de zes trappen van geweldsgebruik", back: "1 Aanwezigheid 2 Communicatie 3 Zachte controle 4 Harde controle 5 Zware middelen 6 Vuurwapen" },
    { id: "zvd-f6", front: "Subsidiariteit betekent...", back: "Gebruik het lichtste middel dat nog effectief is" },
    { id: "zvd-f7", front: "Proportionaliteit betekent...", back: "Middel moet in verhouding staan tot de dreiging" },
    { id: "zvd-f8", front: "Wanneer stopt geweldsgebruik?", back: "Zodra de weerstand/dreiging stopt — daarna afbouwen" },
    { id: "zvd-f9", front: "Basispositie: gewichtsverdeling en handen?", back: "50/50, voeten schouderbreedte, handen open boven de taille" },
    { id: "zvd-f10", front: "Reactieve zone (grijpzone) begint rond...", back: "1–1,5 meter; daar vergroot je oplettendheid en afstand" },
    { id: "zvd-f11", front: "Drie principes van valbreken achterwaarts?", back: "Kin op borst, ronde rug, klappen met platte handen (45°)" },
    { id: "zvd-f12", front: "Polsgreep losmaken: beweging richting...", back: "De duim — de zwakste kant van de greep" },
    { id: "zvd-f13", front: "Wat moet er in een geweldsrapportage?", back: "Dreiging, waarschuwing, middel, duur, effect, letsel, getuigen, beeld" },
    { id: "zvd-f14", front: "Ademhalingsoefening na incident?", back: "4 tellen in, 6 tellen uit — activeert herstel" },
  ],
  tests: [
    {
      id: "zvd-t1",
      title: "Toets 1: Rechtmatig geweld",
      questions: [
        {
          id: "zvd-t1-q1",
          question: "Noodweer staat in welk artikel?",
          options: ["Artikel 36 Sr", "Artikel 41 Sr", "Artikel 164 Sv", "Artikel 52 Sv"],
          answerIndex: 1,
          explanation: "Art. 41 lid 1 Sr regelt noodweer; art. 164 Sv regelt geweld bij aanhouding.",
        },
        {
          id: "zvd-t1-q2",
          question: "Welke combinatie hoort bij de voorwaarden van noodweer?",
          options: [
            "Toekomstige dreiging + zware middelen + boosheid",
            "Onmiddellijke aanranding + noodzakelijke verdediging + proportionaliteit",
            "Verbaal conflict + afstand + wapenstok",
            "Provocatie + reactie + uniform",
          ],
          answerIndex: 1,
          explanation: "Onmiddellijk, noodzakelijk (subsidiar), proportioneel — die drie samen maken verdediging rechtmatig.",
        },
        {
          id: "zvd-t1-q3",
          question: "Een man duwt je weg en loopt rennend weg. Wat is proportioneel?",
          options: [
            "Stokslag naar de benen",
            "Volgen op afstand, waarschuwen en melding/achtervolging conform bevoegdheid",
            "Pepperspray inzetten",
            "Vastgrijpen aan de keel",
          ],
          answerIndex: 1,
          explanation: "De dreiging is voorbij; lichte middelen (volgen, melden) zijn subsidiar en proportioneel.",
        },
        {
          id: "zvd-t1-q4",
          question: "Wanneer begint noodweerexcess juridisch te spelen?",
          options: [
            "Als je verdediging disproportioneel was door niet-vermijdbare paniek",
            "Als je eerst sloeg",
            "Als er getuigen waren",
            "Als je een uniform droeg",
          ],
          answerIndex: 0,
          explanation: "Art. 41 lid 2 Sr: excess door psychische overmacht/paniek — rechter beoordeelt begrijpelijkheid.",
        },
        {
          id: "zvd-t1-q5",
          question: "Trap 3 van de escalatietrap is...",
          options: ["Communicatie", "Zachte controle (geleiden, omklemming)", "Vuurwapen", "Harde controle"],
          answerIndex: 1,
          explanation: "1 aanwezigheid, 2 communicatie, 3 zachte controle, 4 harde controle, 5 zware middelen, 6 vuurwapen.",
        },
        {
          id: "zvd-t1-q6",
          question: "De aanval stopt. Wat doe je?",
          options: [
            "Nog één keer laten voelen wie de baas is",
            "Afbouwen: minder middelen, letselcheck, zorg, rapportage",
            "Direct rapport schrijven en weggaan",
            "Pepperspray als 'verzekering' aanhouden",
          ],
          answerIndex: 1,
          explanation: "Geweld stopt met de dreiging; afbouwen + zorg + rapportage is de plicht.",
        },
        {
          id: "zvd-t1-q7",
          question: "Valbreken achterwaarts: welke beschrijving klopt?",
          options: [
            "Hoofd rechtop, armen gestrekt boven het hoofd",
            "Kin op borst, rug rond, klappen met platte handen in 45° hoek",
            "Op de ellebogen landen",
            "Benen gestrekt houden",
          ],
          answerIndex: 1,
          explanation: "Kin omlaag beschermt hoofd; ronde rol verdeelt impact; klapslag dempt.",
        },
        {
          id: "zvd-t1-q8",
          question: "Waarom beweeg je bij losmaken van een polsgreep richting de duim?",
          options: [
            "Omdat dat de zwakste kant van de greep is",
            "Omdat het er beter uitziet",
            "Omdat de duim pijn doet",
            "Dat is niet waar, je trekt gewoon hard",
          ],
          answerIndex: 0,
          explanation: "De greep is richting duim het zwakst; daar breken met minimale kracht.",
        },
        {
          id: "zvd-t1-q9",
          question: "Wat hoort verplicht na elk gebruik van geweld?",
          options: [
            "Een korte sms naar je collega",
            "Geweldsrapportage: dreiging, waarschuwing, middel, duur, effect, letsel, getuigen",
            "Niets, als er geen letsel is",
            "Alleen melding bij serieuze schade",
          ],
          answerIndex: 1,
          explanation: "Volledige en feitelijke geweldsrapportage is verplicht en beschermt jou juridisch.",
        },
        {
          id: "zvd-t1-q10",
          question: "Ademhalingsoefening voor herstel na een incident?",
          options: [
            "6 tellen in, 4 uit, sneller ademen",
            "4 tellen in, 6 tellen uit, rustig herhalen",
            "Adem inhouden 30 seconden",
            "Diep hoesten",
          ],
          answerIndex: 1,
          explanation: "Lange uitademing (4-6) kalmeert het zenuwstelsel en versnelt herstel.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "zvd-feyn-noodweer", label: "Noodweer en de drie voorwaarden" },
    { key: "zvd-feyn-escalatie", label: "De escalatietrap van geweld" },
    { key: "zvd-feyn-proportie", label: "Subsidiariteit vs. proportionaliteit" },
  ],
};
