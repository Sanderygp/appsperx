import type { Subject } from "./types";

// ============================================================
// VAK 9 — RTGB & ORIËNTATIE OP DE POLITIE
// Focus: risicoanalyse & veiligheidsbeheersing + politietraject
// ============================================================

export const rtgbPolitie: Subject = {
  id: "rtgb-politie",
  name: "RTGB & Politie",
  short: "RTGB/Politie",
  tagline: "Ken de risico's vóórdat ze je vinden — en weet waar je heen groeit.",
  description:
    "Risico's inventariseren en beheersen, veilig werken op locatie, en volledige oriëntatie op het politiewerk: organisatie, kernopgaven, selectie en het traject van BOA naar politieagent.",
  gradient: "from-slate-600/80 to-blue-800/60",
  accent: "text-slate-300",
  icon: "Landmark",
  lessons: [
    {
      id: "rtg-1",
      title: "Risico's inventariseren en beheersen",
      durationMin: 25,
      intro:
        "Risico-analyse is het verschil tussen reageren en voorbereid zijn. Als handhaver analyseer je vóór elke opdracht: wat kan er misgaan, hoe groot is de kans, hoe groot is het effect?",
      sections: [
        {
          heading: "Risico = kans × effect",
          body: "Een risico heeft twee maten: de KANS dat het gebeurt (laag/middel/hoog) en het EFFECT als het gebeurt (licht/zwaar/kritiek). Vermenigvuldig ze mentaal en je krijgt prioriteit. Voorbeeld: flessengooi bij een uitgaansgelegenheid — kans: hoog (happened twice already), effect: kritiek (letsel). Dit risico gaat bovenop de lijst. Formele uitspraak: prioriteit = kans × effect; hoge kans × licht effect kan óók belangrijk zijn als het dagelijks speelt (overlast).",
        },
        {
          heading: "De risicomatrix",
          body: "Een risicomatrix is een tabel met op de ene as kans en op de andere as effect. Elke risico krijgt een cel: groen (acceptabel, monitoren), geel (maatregelen nemen), rood (direct actie, escaleren). Zet risico's als: alcoholoverlast bij station (geel-rood), verkeersonveiligheid bij scholen (geel, tijdsgebonden), drugsoverlast in park (geel), sabotage/terreur (rood, laag kans maar kritiek effect). De matrix rechtvaardigt jouw planning richting leidinggevenden.",
          bullets: [
            "Groen: acceptabel — monitoren",
            "Geel: preventieve maatregelen",
            "Rood: directe actie en escalatie",
          ],
        },
        {
          heading: "Preventief vs. repressief",
          body: "PREVENTIEF: voorkomen — aanwezigheid, voorlichting, fysieke maatregelen (verlichting, camera's, afzettingen), afspraken met ondernemers. REPRESSIEF: optreden ná de overtreding — boetes, PV's, overdracht. Preventie is goedkoper en veiliger; repressie maakt preventie geloofwaardig. De verhouding in goed handhavingsbeleid: preventie domineert, repressie raakt de overtrevers die preventie testen.",
        },
      ],
      keyPoints: [
        "Prioriteit = kans × effect",
        "Risicomatrix: groen monitoren, geel maatregelen, rood actie",
        "Preventie domineert, repressie maakt haar geloofwaardig",
      ],
    },
    {
      id: "rtg-2",
      title: "Veilig werken op locatie",
      durationMin: 25,
      intro:
        "Je eigen veiligheid gaat vóór alles — een gewonde handhaver helpt niemand. Deze les maakt veiligheid tot routine.",
      sections: [
        {
          heading: "De werkplekinspectie",
          body: "Vóór elke opdracht: bekijk de locatie (of foto's) — in- en uitgangen, verlichting, dekmogelijkheden, vluchtwegen, telefoniebereik, en waar collega's/hulp kunnen staan. Tijdens de opdracht: herinspecteer bij verandering (groep groeit, het wordt donker, geluid stijgt). Noteer gevaren en rapporteer ze: een kapotte lamp in een tunnelingang is een veiligheidsrisico dat je meldt, niet ignoreert.",
        },
        {
          heading: "PBM: persoonlijke beschermingsmiddelen",
          body: "Standaard uitrusting: stevig schoeisel, handschoenen (bij aanraking van personen of scherp afval), en bij specifieke taken: bodycam, flitsvest bij verkeer, gehoorbescherming bij evenementen. Gebruik PBM's correct: handschoenen beperken wat je voelt maar beschermen tegen prikken en beten; flitsvest maakt je zichtbaar — bij verkeer is zichtbaarheid letterlijk levensbelang. Controleer je uitrusting vóór elke dienst; kapot materiaal is onbruikbaar materiaal.",
        },
        {
          heading: "Plan van aanpak bij evenementen",
          body: "Bij evenementen loop je een vast plan: (1) Wat is het evenement en verwacht aantal bezoekers? (2) Wie is verantwoordelijk (organisatie, veiligheidscoördinator)? (3) Waar zijn risicopunten (barrières, podiumranden, drankpunten, uitgangen)? (4) Waar sta jij en wat is je opdracht? (5) Wat is het communicatiemiddel en noodsignaal? Loop dit door vóór het evenement; improviseer niet — improviseren is wat je doet binnen het plan, niet in plaats van het plan.",
        },
      ],
      keyPoints: [
        "Werkplekinspectie: uitgangen, verlichting, vluchtwegen, telefonie",
        "PBM's checken vóór elke dienst",
        "Evenementen: vast plan van aanpak, geen improvisatie",
      ],
    },
    {
      id: "rtg-3",
      title: "Oriëntatie op de politie",
      durationMin: 30,
      intro:
        "De politie is je belangrijkste partner én voor veel BOA's de volgende stap. Ken de organisatie, de kernopgaven en de cultuur.",
      sections: [
        {
          heading: "Organisatie van de politie",
          body: "De Nederlandse politie is één nationaal korps onder verantwoordelijkheid van de minister van Justitie en Veiligheid (korpsbeheer), met regionale EENHEDEN (met districten en teams) en de LANDELIJKE EENHEID (speciale opsporing, beveiliging, verkeer, water). Op straat ken je: de wijkagent (kent het gebied, zichtbaar, aanspreekpunt), de basisteam-agenten (112-uitruk, aanhoudingen), en recherche (ernstige opsporing). De meldkamer (112) stuurt hulpdiensten en kent prioriteiten: P1 (levensbedreigend, direct), P2 (spoed), P3 (niet-spoed).",
          bullets: [
            "Eén korps: regionale eenheden + landelijke eenheid",
            "Wijkagent = gezicht van het gebied",
            "Meldkamer prioriteiten: P1 direct, P2 spoed, P3 routine",
          ],
        },
        {
          heading: "Kernopgaven van de politie",
          body: "Vier kernopgaven volgens de Politiewet 2012: (1) daadwerkelijke handhaving van de rechtsorde (opsporing, aanhouding), (2) hulpverlening (aan mensen die hulp behoeven — grootste deel van het werk!), (3) preventie (voorkomen van strafbaar gedrag en onveiligheid), (4) ondersteuning van andere diensten (justitie, gemeenten, brandweer). Merk op: hulpverlening en preventie vormen het merendeel van dagelijks werk — politie is veel meer dan uiterste geweld.",
        },
        {
          heading: "Samenwerking politie – BOA",
          body: "BOA's en politie zijn collega's met verschillende taakvelden. Goede samenwerking: je neemt alles aan wat buiten jouw taakveld valt en schakelt; zij rekenen op jouw feitelijke vaststellingen en rapportage. Praktisch: wijkagent en gemeentelijke handhaver plannen samen gebieden, delen signalen (via de wijkcoördinatie), en optreden gezamenlijk bij grote overlast. Respect werkt twee kanten: ken hun bevoegdheden (algemene opsporing) en laat jouw taakveld-expertise zien (APV, DHW, lokaal beleid).",
        },
        {
          heading: "Van MBO naar politie: het traject",
          body: "Wil je door naar de politie? Het standaardtraject: solliciteren bij een regionale eenheid als korpsagent (MBO 4 werk- en denkniveau vereist — jouw MBO 3-route met opvallende resultaten is een goede basis; veel aspiranten volgen eerst een doorstroom naar MBO 4 of HBO). Selectie omvat: intake, psychologisch onderzoek (PIW), keuring, sports-test (conditie en kracht) en een vertrouwensonderzoek. Kernwaarden: moedig, verbindend, zichtbaar. TIP van de meester: je werk als BOA is je auditie op straat — netheid, kennis en rust zijn je referenties.",
        },
      ],
      keyPoints: [
        "Eén korps: regionale + landelijke eenheid; wijkagent op straat",
        "Meldkamer: P1 direct, P2 spoed, P3 routine",
        "Politiewet 2012: handhaving, hulpverlening, preventie, ondersteuning",
        "BOA–politie: taakvelden respecteren, signalen delen",
      ],
    },
  ],
  flashcards: [
    { id: "rtg-f1", front: "Formule voor risicoprioriteit?", back: "Kans × effect" },
    { id: "rtg-f2", front: "Risicomatrix: groen betekent...", back: "Acceptabel — monitoren" },
    { id: "rtg-f3", front: "Geel betekent...", back: "Preventieve maatregelen nemen" },
    { id: "rtg-f4", front: "Rood betekent...", back: "Directe actie en escalatie" },
    { id: "rtg-f5", front: "Preventie vs repressie?", back: "Preventie = voorkomen (aanwezigheid, maatregelen); repressie = optreden ná overtreding (boetes, PV)" },
    { id: "rtg-f6", front: "Vier PBM's die je standaard controleert?", back: "Schoeisel, handschoenen, flitsvest (verkeer), bodycam (opdracht)" },
    { id: "rtg-f7", front: "Vijf vragen in een plan van aanpak (evenement)?", back: "Evenement/bezoekers, verantwoordelijke, risicopunten, jouw positie/opdracht, communicatie/noodsignaal" },
    { id: "rtg-f8", front: "Politiewet 2012: vier kernopgaven?", back: "Handhaving, hulpverlening, preventie, ondersteuning" },
    { id: "rtg-f9", front: "Meldkamer prioriteit P1 betekent...", back: "Levensbedreigende situatie — directe inzet" },
    { id: "rtg-f10", front: "Wijkagent is...", back: "Het zichtbare aanspreekpunt dat het gebied en de bewoners kent" },
    { id: "rtg-f11", front: "Kernwaarden van de politie?", back: "Moedig, verbindend, zichtbaar" },
    { id: "rtg-f12", front: "BOA ziet een inbraak tijdens zijn ronde. Wat eerst?", back: "Veilig vaststellen + 112/meldkamer bellen — inbraak valt buiten zijn taakveld; politie komt" },
  ],
  tests: [
    {
      id: "rtg-t1",
      title: "Toets 1: Risico's & politie",
      questions: [
        {
          id: "rtg-t1-q1",
          question: "Risicoprioriteit bereken je als...",
          options: ["Kans ÷ effect", "Kans × effect", "Effect − kans", "Kans + effect"],
          answerIndex: 1,
          explanation: "Prioriteit = kans × effect; beide maten samen bepalen de lijst.",
        },
        {
          id: "rtg-t1-q2",
          question: "Een risico met lage kans maar kritiek effect (bijv. aanslag) valt in de matrix doorgaans in...",
          options: ["Groen", "Geel", "Rood", "Niet op de matrix"],
          answerIndex: 2,
          explanation: "Kritiek effect = rood, ongeacht de lage kans.",
        },
        {
          id: "rtg-t1-q3",
          question: "Welke maatregel is PREVENTIEF?",
          options: [
            "Boete uitdelen na overlast",
            "Extra verlichting en aanwezigheid op een hotspot",
            "PV opmaken bij vernieling",
            "Verdachten staande houden",
          ],
          answerIndex: 1,
          explanation: "Preventie voorkomt: verlichting, aanwezigheid, afspraken.",
        },
        {
          id: "rtg-t1-q4",
          question: "Werkplekinspectie: wat check je minimaal?",
          options: [
            "Alleen het weer",
            "Uitgangen, verlichting, vluchtwegen, telefoniebereik",
            "Alleen het aantal bezoekers",
            "De lokale horecaprijzen",
          ],
          answerIndex: 1,
          explanation: "Veiligheidsinventarisatie: weg eruit, zicht, dekking, communicatie.",
        },
        {
          id: "rtg-t1-q5",
          question: "Waarom handschoenen bij contact met personen of afval?",
          options: [
            "Zo oog je stoer",
            "Bescherming tegen prikken, beten en besmetting",
            "Voor warmte",
            "Om vast te grijpen",
          ],
          answerIndex: 1,
          explanation: "PBM tegen hygiënisch en fysiek risico.",
        },
        {
          id: "rtg-t1-q6",
          question: "Bij evenementen geldt...",
          options: [
            "Improviseren is prima",
            "Een vast plan van aanpak vóóraf, improviseren alleen binnen het plan",
            "Alleen de organisatie heeft een plan",
            "Plannen zijn voor politie alleen",
          ],
          answerIndex: 1,
          explanation: "Plan vóóraf: bezoekers, verantwoordelijke, risicopunten, positie, communicatie.",
        },
        {
          id: "rtg-t1-q7",
          question: "Welke kernopgave van de politie neemt het grootste deel van het dagelijkse werk in beslag?",
          options: ["Uiterste geweld", "Hulpverlening en preventie", "Bijstand aan het leger", "Fiscale controles"],
          answerIndex: 1,
          explanation: "Politiewerk is merendeels hulpverlening en preventie — niet geweld.",
        },
        {
          id: "rtg-t1-q8",
          question: "Meldkamer prioriteit P2 betekent...",
          options: ["Niet urgent", "Spoed — snel inzetten, geen levensbedreiging", "Levensbedreigend", "Alleen administratief"],
          answerIndex: 1,
          explanation: "P1 = levensbedreigend/direct, P2 = spoed, P3 = niet-spoed.",
        },
        {
          id: "rtg-t1-q9",
          question: "Je ziet tijdens je ronde een overval plaatsvinden. Wat doe je?",
          options: [
            "Zelf de overvaller staande houden — je bent BOA",
            "Bewust de situatie vaststellen, jezelf in veiligheid brengen, 112 bellen, observatie doorgeven",
            "Weggaan — niet jouw werk",
            "Fotograferen van dichtbij",
          ],
          answerIndex: 1,
          explanation: "Overval = buiten taakveld: veiligheid eerst, melding, doorgeven als ooggetuige.",
        },
        {
          id: "rtg-t1-q10",
          question: "Kernwaarden van de politie zijn...",
          options: [
            "Snel, streng, onzichtbaar",
            "Moedig, verbindend, zichtbaar",
            "Verder weg, formeel, stil",
            "Geld, status, macht",
          ],
          answerIndex: 1,
          explanation: "Moedig, verbindend, zichtbaar — dat is de politiecultuur waar je naar groeit.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "rtg-feyn-kans", label: "Risico = kans × effect uitleggen" },
    { key: "rtg-feyn-politie", label: "De vier kernopgaven van de politie" },
  ],
};
