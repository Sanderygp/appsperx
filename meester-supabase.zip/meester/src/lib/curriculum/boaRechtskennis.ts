import type { Subject } from "./types";

// ============================================================
// VAK 2 — BOA RECHTSKENNIS
// Focus: rechtsstaat, BOA-bevoegdheden, DHW, APV, WPV 2000, etc.
// ============================================================

export const boaRechtskennis: Subject = {
  id: "boa-rechtskennis",
  name: "BOA Rechtskennis",
  short: "Rechtskennis",
  tagline: "De wet is je wapen. Ken hem beter dan wie dan ook.",
  description:
    "De positie van de BOA, bevoegdheden en grenzen, en de bijzondere wetten die je dagelijks handhaaft: Drank- en Horecawet, APV, Wet Personenvervoer 2000, Opiumwet en meer.",
  gradient: "from-red-600/80 to-rose-700/60",
  accent: "text-red-300",
  icon: "Scale",
  lessons: [
    {
      id: "brk-1",
      title: "De rechtsstaat: waarom jouw bon wet is",
      durationMin: 25,
      intro:
        "Voordat je één boete uitdeelt, moet je begrijpen waar Nederlandse handhaving vandaan komt: de rechtsstaat. Alles wat jij doet als BOA is gegrond op wetgeving die door gekozen volksvertegenwoordigers is aangenomen.",
      sections: [
        {
          heading: "Trias politica: drie machten",
          body: "De macht in Nederland is verdeeld om machtsmisbruik te voorkomen. De WETGEVER (regering + Staten-Generaal) maakt wetten. De RECHTSPRAAK (rechters) beoordeelt geschillen en oordeelt of straffen terecht zijn. De UITVOERENDE macht (regering, ministers, gemeentebestuur — en daaronder jij als toezichthouder) voert wetten uit en handhaaft ze. Als BOA maak je deel uit van die uitvoerende macht: je handhaaft, je oordeelt niet over schuld en je bent geen rechter.",
          bullets: [
            "Wetgever: maakt formele wetten (regering + Kamers)",
            "Rechter: beoordeelt en straft",
            "Uitvoering: ministers, gemeenten, toezichthouders",
          ],
        },
        {
          heading: "Rechtsbronnen: waar vind je 'de wet'?",
          body: "Nederland kent vier rechtsbronnen. Eén: de wetgeving (Grondwet, formele wetten, gemeentelijke verordeningen zoals de APV). Twee: verdragen (zoals het EVRM, Europees Verdrag voor de Rechten van de Mens). Drie: jurisprudentie (uitspraken van rechters die als richtlijn dienen). Vier: gewoonte (gebruik dat als regel wordt ervaren). Als een burger vraagt 'op welke grond'], dan moet je de wet kunnen noemen: dat maakt jouw optreden rechtmatig.",
        },
        {
          heading: "Publiekrecht vs. privaatrecht",
          body: "Privaatrecht regelt verhoudingen tussen burgers onderling (contracten, koop, schadevergoeding). Publiekrecht regelt de verhouding tussen overheid en burger — daar zit jouw werkgebied: strafrecht (Wetboek van Strafrecht en van Strafvordering), bestuursrecht (Algemene wet bestuursrecht) en bestuursrechtelijke handhaving. Een boete van het bestuur is bestuursrecht; een strafzaak bij de rechter is strafrecht. Als BOA begeef je je in beide domeinen: je kunt een proces-verbaal opmaken (strafrecht) én een boetebeschikking voorbereiden (bestuursrecht).",
        },
        {
          heading: "De gemeente en de APV",
          body: "Gemeenten hebben eigen regelgeving: de Algemene Plaatselijke Verordening (APV). De gemeenteraad stelt de APV vast; het college van burgemeester en wethouders (B&W) voert uit en handhaaft. De meeste gemeentelijke BOA's handhaven precies deze verordening: drinkverbod op straat, sluitingstijden, samenscholingsverbod, wildplassen. Elke gemeente mag eigen regels stellen, dus leer ALTIJD de lokale APV van jouw werkgebied.",
        },
      ],
      keyPoints: [
        "Trias politica: wetgever, rechter, uitvoering — jij bent uitvoering",
        "Vier rechtsbronnen: wetgeving, verdragen, jurisprudentie, gewoonte",
        "BOA-werk = publiekrecht: strafrecht + bestuursrecht",
        "APV = lokale verordening, vastgesteld door de raad",
      ],
    },
    {
      id: "brk-2",
      title: "De BOA: positie, bevoegdheden en grenzen",
      durationMin: 30,
      intro:
        "Buitengewoon opsporingsambtenaar (BOA): de titel zegt het al — je oefent OPSPOORING uit, maar 'buitengewoon': buiten het politiekorps om, voor een specifieke organisatie en een specifiek taakveld.",
      sections: [
        {
          heading: "Wettelijke basis: artikel 142 Sv",
          body: "Artikel 141 Wetboek van Strafvordering benoemt de gewone opsporingsambtenaren (politie, Koninklijke Marechaussee, FIOD). Artikel 142 Sv benoemt de categorieën buitengewoon opsporingsambtenaren: onder andere gemeentelijke handhavers, boswachters, douane, Toezicht&Handhaving-corpora. Naast de wettelijke aanwijzing heb je een eed/verklaring afgelegd, een machtiging en een legimitatiebewijs. Zonder legimitatie kun je niet in functie optreden — die moet je op verzoek altijd tonen.",
        },
        {
          heading: "Taakveld: jouw beperkte opsporingsbevoegdheid",
          body: "De meeste BOA's hebben een BEPERKTE opsporingsbevoegdheid: opsporing alleen binnen hun taakveld. Een gemeentelijke BOA met taakveld APV en Drank- en Horecawet mag die wetten opsporen, maar niet fraude of moord. Slechts weinigen hebben een algemene opsporingsbevoegdheid. Dit onderscheid is examenstof én dagelijkse praktijk: optreden buiten je taakveld = rechtsonzekerheid en nietige besluiten.",
          bullets: [
            "Beperkte opsporing: alleen binnen het toegewezen taakveld",
            "Algemene opsporing: alle strafbare feiten (uitzondering)",
            "Taakveld staat in je aanwijzing/benoeming",
          ],
        },
        {
          heading: "Kernbevoegdheden op straat",
          body: "De belangrijkste bevoegdheden: (1) STAANDE HOUDEN — art. 52 Sv: je mag iemand aanhouden en zijn identiteit vaststellen als die verdachte is van een overtreding in jouw taakveld. (2) IDENTIFICATIE — art. 2 Wet op de identificatieplicht: iedereen van 14+ moet een geldig identiteitsbewijs kunnen tonen. (3) VASTHOUDEN en overdracht aan de politie als iemand niet meewerkt. (4) PROCES-VERBAAL opmaken — art. 148 Sv. (5) Bestuurlijke boetes voorbereiden volgens de bijzondere wet of de Wet boete. Wat je NIET zomaar hebt: fouilleerbevoegdheid — die bestaat alleen als een bijzondere wet die expliciet geeft.",
          bullets: [
            "Staande houden: art. 52 Sv",
            "Identificatieplicht: art. 2 Wid — vanaf 14 jaar",
            "PV: art. 148 Sv",
            "Fouilleren: alleen met expliciete wettelijke basis",
          ],
        },
        {
          heading: "De bestuurlijke boete en de Wet boete",
          body: "Sinds 1 juli 2024 geldt de Wet boete: één algemene regeling voor bestuursrechtelijke boetes, in plaats van regels verspreid over tientallen bijzondere wetten. Kernpunten: er moet een wettelijke grondslag zijn, de boetebeschikking wordt schriftelijk genomen door het bestuursorgaan (bijvoorbeeld het college van B&W), en er geldt een verjaringstermijn: na een aantal jaren kan de boete niet meer worden opgelegd. Tegen een boetebeschikking kan bezwaar en daarna beroep bij de rechter. Jij stelt de feiten vast en meldt; het bestuursorgaan neemt de beslissing — die scheiding is wezenlijk.",
        },
      ],
      keyPoints: [
        "Art. 141 Sv = opsporingsambtenaren; art. 142 Sv = BOA's",
        "Beperkte opsporingsbevoegdheid = alleen je taakveld",
        "Staande houden (52 Sv), identificatie (art. 2 Wid), PV (148 Sv)",
        "Wet boete (2024): één regeling voor bestuursrechtelijke boetes",
      ],
    },
    {
      id: "brk-3",
      title: "Drank- en Horecawet en APV in de praktijk",
      durationMin: 30,
      intro:
        "Alcoholcontrole is het brood en boter van de gemeentelijke BOA. De regels zijn helder — jouw werk is ze consequent en verhoudingsgewijs handhaven.",
      sections: [
        {
          heading: "Leeftijdsgrenzen: 18 jaar, zonder uitzondering",
          body: "Sinds de wetswijziging van 2014 geldt: alcohol kopen, bestellen of krijgen mag pas vanaf 18 jaar — dus OOK zwakke drank zoals bier en wijn (voorheen 16). Verkopen, schenken of anderszins verstrekken aan jongeren onder 18 is verboden (art. 20 DHW) en is een economisch delict waarvoor de ondernemer verantwoordelijk is. Zelf bezitten en drinken onder de 18 is voor de jongere zelf niet strafbaar — maar de drank kan in beslag worden genomen.",
          bullets: [
            "18 jaar voor ALLE alcohol (zwak én sterk)",
            "Verstrekken aan <18 = verboden (art. 20 DHW)",
            "Ondernemer draagt de verantwoordelijkheid",
          ],
        },
        {
          heading: "Vergunningen en toezicht in de horeca",
          body: "Alcohol schenken mag alleen met een Drank- en Horecavergunning (art. 3 DHW) en alleen door of onder toezicht van een meerderjarige manager (art. 1 lid 1 DHW). Bij controle check je: vergunning aanwezig en geldig, leeftijdscontrolesystematiek aanwezig (bijv. vragen bij twijfel), geen verkoop aan duidelijk dronken gasten. Op evenementen geldt vaak een ontheffing met voorwaarden — lees de voorwaarden, want daar hangt jouw toezicht aan op.",
        },
        {
          heading: "Leeftijdscontrole uitvoeren",
          body: "Vraag identiteitsbewijs bij iedereen die er jonger dan ongeveer 25 uitziet — dat is de professionele norm. Geldige bewijzen: Nederlandse identiteitskaart, paspoort, rijbewijs; bij vreemdelingen ook de verblijfsvergunning. Vervalsingen herken je aan: afwijkende letters of kleuren, losse folie, verkeerde pasfoto, hologram dat niet beweegt bij kantelen. Weet dat bij leeftijdscontrole in de horeca een beperkte fouilleerbevoegdheid kan gelden op grond van de Drank- en Horecawet: alleen in kledingzakken zoeken, nooit doorzoeken van koffers zonder toestemming.",
        },
        {
          heading: "APV: drinkverbod en sluitingstijden",
          body: "De meeste gemeenten verbieden in de APV alcohol op of in de openbare weg en openbare ruimten (drinkverbod, doorgaans art. 2.37 Model-APV). drank dat in beslag wordt genomen wordt vernietigd. Sluitingstijden voor horeca en winkels staan ook in de APV; na sluitingstijd moet de exploitant de zaak sluiten. Samenscholingsverbod: bij ernstige overlast mag de burgemeester een groep bevelen uiteen te gaan. Ken de exacte lokale artikelen — bij je toets en in de straat telt dat je de juiste wetsartikelen kunt noemen.",
        },
      ],
      keyPoints: [
        "18+ voor alle alcohol; verstrekken aan <18 verboden",
        "Drank- en Horecavergunning + manager meerderjarig",
        "Check ID bij twijfel tot 25 jaar",
        "Drinkverbod = APV (meestal art. 2.37)",
      ],
    },
    {
      id: "brk-4",
      title: "Wet Personenvervoer 2000 en overige wetten",
      durationMin: 25,
      intro:
        "Naast alcohol en APV controleer je taxi's, openbare orde en soms drugs. Elke wet heeft eigen klemtoonpunten — hieronder de examenkern.",
      sections: [
        {
          heading: "Wet Personenvervoer 2000 (WPV 2000)",
          body: "Taxivervoer tegen betaling mag alleen met een vergunning en een taxipas. Bij een taxi-controle check je: geldige vergunning documenten in het voertuig, taxipas met foto van de chauffeur aanwezig, tarieven zichtbaar vermeld, taximeter goed functioneert, en de chauffeur gebruikt de daarvoor bedoelde oprijstroken/standplaatsen. Illegaal personenvervoer ('zwarte taxi') is een economisch delict; je kunt een PV opmaken en het voertuig rapporteren voor verdere handhaving.",
        },
        {
          heading: "Opiumwet: lijst I, lijst II en gedoogbeleid",
          body: "De Opiumwet kent twee lijsten. Lijst I = harddrugs (heroïne, cocaïne, XTC, methamfetamine): bezit en handel ALTIJD strafbaar. Lijst II = softdrugs (hennep, hasj, paddenstoelen met psilocine). Het Nederlandse gedoogbeleid betekent niet dat softdrugs legaal zijn — het bezit van kleine hoeveelheden (tot circa 5 gram voor eigen gebruik) wordt volgens OM-aanwijzing vaak niet vervolgd, maar de drank kan wel in beslag worden genomen. Voor jou als BOA geldt je taakveld: handhaving van gedoogbeleid in coffeeshops (geen verkoop aan <18, geen harddrugs, geen reclame, max. voorraad).",
        },
        {
          heading: "Wet wapens en munitie (WWM)",
          body: "De WWM kent categorieën. Categorie II: vuurwapens (vergunningplichtig, vrijwel alleen voor politie en jacht). Categorie III: steek- en stootwerktuigen zoals vlakmes met knooppunt, boksbeugel, valstrikmes — bezit en dragen in de openbare ruimte is verboden. Categorie IV: onder meer luchtdrukwepens en imitatievuurwapens (vergunningplichtig sinds 2010). Bij fouillering of melding: documentatie is alles — welk wapen, waar gevonden, wie droeg het.",
        },
        {
          heading: "Wegenverkeerswet en parkeren",
          body: "Gemeentelijke BOA's handhaven vaak parkeerregels op grond van de Wegenverkeerswet 1994 (WVW): parkeren op een plek waar dat verboden is, te lang parkeren met betaald parkeren, of gebruik van gehandicaptenparkeerplaats zonder kaart. De handhaving verloopt via bestuurlijke boetes of naheffingsaanslag parkeerbelasting. Werk altijd met fotograferend bewijs: kenteken, plaats, tijdstip, situatie — dat is je bewijs tegen bezwaar.",
        },
      ],
      keyPoints: [
        "WPV 2000: vergunning, taxipas, tarieven, meter",
        "Opiumwet: lijst I harddrugs altijd strafbaar; lijst II gedoogd in kleine hoeveelheden",
        "WWM cat. III: steekwerktuigen verboden in openbare ruimte",
        "WVW-parkeren: bewijs = kenteken + plaats + tijd + foto",
      ],
    },
  ],
  flashcards: [
    { id: "brk-f1", front: "Welk artikel Sv benoemt BOA's?", back: "Artikel 142 Wetboek van Strafvordering (141 = gewone opsporingsambtenaren)" },
    { id: "brk-f2", front: "Beperkte opsporingsbevoegdheid betekent...", back: "Opsporen mag alleen binnen jouw taakveld (bijv. APV + DHW)" },
    { id: "brk-f3", front: "Staande houden staat in welk artikel?", back: "Artikel 52 Sv" },
    { id: "brk-f4", front: "Vanaf welke leeftijd geldt de identificatieplicht?", back: "Vanaf 14 jaar (art. 2 Wet op de identificatieplicht)" },
    { id: "brk-f5", front: "Welke alcoholleeftijd geldt in Nederland?", back: "18 jaar voor alle alcohol (zwak én sterk), sinds 2014" },
    { id: "brk-f6", front: "Verstrekken van alcohol aan <18 jaar staat in...", back: "Artikel 20 Drank- en Horecawet — verboden, economisch delict" },
    { id: "brk-f7", front: "Drank- en Horecavergunning = welk artikel DHW?", back: "Artikel 3 DHW" },
    { id: "brk-f8", front: "Tot welke leeftijd vraag je standaard ID bij alcohol?", back: "Bij iedereen die jonger dan ~25 jaar lijkt (professionele norm)" },
    { id: "brk-f9", front: "Drinkverbod op straat staat doorgaans in...", back: "De APV van de gemeente (model-artikel 2.37)" },
    { id: "brk-f10", front: "Wie stelt de APV vast?", back: "De gemeenteraad" },
    { id: "brk-f11", front: "Opiumwet lijst I vs lijst II?", back: "Lijst I = harddrugs (altijd strafbaar), lijst II = softdrugs (kleine hoeveelheden gedoogd)" },
    { id: "brk-f12", front: "Welke WWM-categorie dekt steek- en stootwerktuigen?", back: "Categorie III — verboden bezit/dragen in openbare ruimte" },
    { id: "brk-f13", front: "Drie kerncontroles bij een taxi?", back: "Vergunning/documenten, taxipas met foto, tarieven + meter" },
    { id: "brk-f14", front: "Sinds wanneer geldt de Wet boete?", back: "1 juli 2024 — één algemene regeling voor bestuursrechtelijke boetes" },
    { id: "brk-f15", front: "Vier rechtsbronnen?", back: "Wetgeving, verdragen, jurisprudentie, gewoonte" },
  ],
  tests: [
    {
      id: "brk-t1",
      title: "Toets 1: BOA & bevoegdheden",
      questions: [
        {
          id: "brk-t1-q1",
          question: "In welk artikel van het Wetboek van Strafvordering staan de buitengewoon opsporingsambtenaren genoemd?",
          options: ["Artikel 141 Sv", "Artikel 142 Sv", "Artikel 52 Sv", "Artikel 148 Sv"],
          answerIndex: 1,
          explanation: "Art. 141 Sv = gewone OA's; art. 142 Sv = de categorieën BOA's.",
        },
        {
          id: "brk-t1-q2",
          question: "Een gemeentelijke BOA met taakveld APV/DHW ziet een winkeldiefstal. Mag hij die opsporen?",
          options: [
            "Ja, BOA's hebben algemene opsporingsbevoegdheid",
            "Nee, winkeldiefstal valt buiten zijn taakveld",
            "Ja, mits de winkelier het vraagt",
            "Alleen als een politieagent toekijkt",
          ],
          answerIndex: 1,
          explanation: "Met een beperkte opsporingsbevoegdheid mag je alleen binnen je taakveld opsporen. Winkeldiefstal (Sr) valt daarbuiten.",
        },
        {
          id: "brk-t1-q3",
          question: "Op grond van welk artikel mag je iemand staande houden?",
          options: ["Artikel 52 Sv", "Artikel 2 Wid", "Artikel 20 DHW", "Artikel 1 Grondwet"],
          answerIndex: 0,
          explanation: "Art. 52 Sv: staande houden van een verdachte.",
        },
        {
          id: "brk-t1-q4",
          question: "Vanaf welke leeftijd moet iemand op verzoek een geldig identiteitsbewijs tonen?",
          options: ["Vanaf 12 jaar", "Vanaf 14 jaar", "Vanaf 16 jaar", "Vanaf 18 jaar"],
          answerIndex: 1,
          explanation: "Art. 2 Wet op de identificatieplicht: 14 jaar en ouder.",
        },
        {
          id: "brk-t1-q5",
          question: "Mag een BOA standaard iemand fouilleren bij een verdenking van overtreding van de APV?",
          options: [
            "Ja, bij elke overtreding",
            "Nee, fouilleren vereist een expliciete wettelijke basis in een bijzondere wet",
            "Ja, als de persoon toestemt na verzoek",
            "Alleen met toestemming van de burgemeester",
          ],
          answerIndex: 1,
          explanation: "Er is geen algemene fouilleerbevoegdheid; die moet expliciet in een bijzondere wet staan (bijv. leeftijdscontrole DHW).",
        },
        {
          id: "brk-t1-q6",
          question: "Sinds wanneer geldt de Wet boete als algemene regeling voor bestuursrechtelijke boetes?",
          options: ["1 januari 2020", "1 juli 2024", "1 januari 2023", "1 juli 2022"],
          answerIndex: 1,
          explanation: "De Wet boete is op 1 juli 2024 in werking getreden.",
        },
        {
          id: "brk-t1-q7",
          question: "Wie neemt de bestuurlijke boetebeschikking eigenlijk?",
          options: [
            "De BOA die de overtreding zag",
            "Het bevoegde bestuursorgaan, bijvoorbeeld het college van B&W",
            "De politie",
            "De officier van justitie",
          ],
          answerIndex: 1,
          explanation: "De BOA stelt feiten vast; het bestuursorgaan neemt de beschikking. Die scheiding is wezenlijk.",
        },
        {
          id: "brk-t1-q8",
          question: "Welk rechtsmiddel staat open tegen een bestuurlijke boetebeschikking?",
          options: ["Bezwaar, dan beroep", "Direct cassatie", "Hoger beroep bij de Hoge Raad", "Geen"],
          answerIndex: 0,
          explanation: "Bestuursrechtelijke route: eerst bezwaar bij het bestuursorgaan, daarna beroep bij de bestuursrechter.",
        },
        {
          id: "brk-t1-q9",
          question: "Wat is een correcte omschrijving van 'gedoogbeleid'?",
          options: [
            "Softdrugs zijn legaal in Nederland",
            "Er is een wettelijk verbod, maar het OM vervolgt kleine hoeveelheden voor eigen gebruik niet",
            "Gemeenten mogen drugs verkopen",
            "Harddrugs zijn toegestaan in coffeeshops",
          ],
          answerIndex: 1,
          explanation: "Gedogen = verbod blijft bestaan, maar overtredingen in bepaalde gevallen niet vervolgd.",
        },
        {
          id: "brk-t1-q10",
          question: "Bij leeftijdscontrole in de horeca mag de toezichthouder op grond van de DHW onder meer...",
          options: [
            "een tas volledig doorzoeken",
            "kledingzakken laten leeghalen (beperkte fouilleerbevoegdheid)",
            "een telefoon doorzoeken",
            "iemand vastketenen",
          ],
          answerIndex: 1,
          explanation: "De DHW kent een beperkte fouilleerbevoegdheid: alleen in kledingzakken, nooit tassen of telefoons.",
        },
      ],
    },
    {
      id: "brk-t2",
      title: "Toets 2: DHW, APV & bijzondere wetten",
      questions: [
        {
          id: "brk-t2-q1",
          question: "Een 17-jarige wil bier kopen in de supermarkt. Wat geldt?",
          options: [
            "Toegestaan, zwakke drank vanaf 16",
            "Verboden — alle alcohol vanaf 18 jaar",
            "Toegestaan met ouderlijke toestemming",
            "Alleen verboden op weekdagen",
          ],
          answerIndex: 1,
          explanation: "Sinds 2014: 18 jaar voor álle alcohol.",
        },
        {
          id: "brk-t2-q2",
          question: "Wie draagt de verantwoordelijkheid als een ondernemer alcohol schenkt aan een 16-jarige?",
          options: ["De 16-jarige", "De ondernemer", "De ouders", "Niemand"],
          answerIndex: 1,
          explanation: "Verstrekken is een economisch delict van de ondernemer (art. 20 DHW).",
        },
        {
          id: "brk-t2-q3",
          question: "Welke documenten zijn GELDIG als leeftijdsbewijs?",
          options: [
            "Studentenkaart en OV-chipkaart",
            "Paspoort, Nederlandse ID-kaart, rijbewijs",
            "Geboortebewijs en bankpas",
            "Elk document met foto",
          ],
          answerIndex: 1,
          explanation: "Alleen officiële identiteitsdocumenten: paspoort, ID-kaart, rijbewijs (en vreemdelingendocument).",
        },
        {
          id: "brk-t2-q4",
          question: "Herkenteken vervalsing? Eén van deze signalen klopt NIET:",
          options: [
            "Hologram beweegt niet bij kantelen",
            "Losse folie of luchtbellen",
            "Gelamineerde pasfoto",
            "De foto is gelijk aan de drager",
          ],
          answerIndex: 3,
          explanation: "'De foto is gelijk aan de drager' is juist een goed teken. De overige drie zijn vervalsingssignalen.",
        },
        {
          id: "brk-t2-q5",
          question: "Stelt de gemeenteraad of het college de APV vast?",
          options: ["Het college van B&W", "De gemeenteraad", "De burgemeester alleen", "De provincie"],
          answerIndex: 1,
          explanation: "De raad stelt de APV vast; het college voert uit en handhaaft.",
        },
        {
          id: "brk-t2-q6",
          question: "Drinkverbod op de openbare weg regelt de gemeente via...",
          options: ["De Grondwet", "De APV", "De Opiumwet", "De WPV 2000"],
          answerIndex: 1,
          explanation: "Het drinkverbod staat in de APV (doorgaans model-artikel 2.37).",
        },
        {
          id: "brk-t2-q7",
          question: "Wat controleer je bij een taxi op grond van de WPV 2000? (beste antwoord)",
          options: [
            "Alleen het kenteken",
            "Vergunningdocumenten, taxipas met foto, zichtbare tarieven en werkende meter",
            "Alleen of er een stickers staan",
            "De muziek in de taxi",
          ],
          answerIndex: 1,
          explanation: "De vier kerncontroles: documenten, taxipas, tarieven, meter.",
        },
        {
          id: "brk-t2-q8",
          question: "Heroïne en cocaïne staan op...",
          options: ["Lijst I Opiumwet", "Lijst II Opiumwet", "Lijst III WWM", "Geen lijst"],
          answerIndex: 0,
          explanation: "Lijst I = harddrugs, altijd strafbaar.",
        },
        {
          id: "brk-t2-q9",
          question: "Een vlakmes met knooppunt in de broekzak op straat valt onder...",
          options: [
            "Categorie II WWM — vergunning mogelijk",
            "Categorie III WWM — verboden in openbare ruimte",
            "Categorie IV WWM — vrij",
            "Geen wettelijke regeling",
          ],
          answerIndex: 1,
          explanation: "Steek- en stootwerktuigen = categorie III WWM; bezit/dragen op straat is verboden.",
        },
        {
          id: "brk-t2-q10",
          question: "Welke bewijsmiddelen bouw je op bij parkeerhandhaving (WVW)?",
          options: [
            "Alleen je eigen verklaring",
            "Kenteken, locatie, tijdstip en fotograferend bewijs",
            "Getuigenverklaring van voorbijgangers",
            "Geen bewijs nodig bij parkeren",
          ],
          answerIndex: 1,
          explanation: "Fotografisch bewijs van kenteken, plaats, tijd en situatie is de standaard tegen bezwaar.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "brk-feyn-taakveld", label: "Beperkte vs. algemene opsporingsbevoegdheid" },
    { key: "brk-feyn-dhw", label: "Waarom 18 jaar voor alle alcohol" },
    { key: "brk-feyn-boete", label: "Hoe een bestuurlijke boete tot stand komt" },
  ],
};
