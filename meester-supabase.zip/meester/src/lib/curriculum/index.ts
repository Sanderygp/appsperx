import type { Subject } from "./types";
import { rekenen } from "./rekenen";
import { boaRechtskennis } from "./boaRechtskennis";
import { boaPraktijk } from "./boaPraktijk";
import { zelfverdediging } from "./zelfverdediging";
import { engels } from "./engels";
import { nederlands } from "./nederlands";
import { coaching } from "./coaching";
import { proVaardigheden } from "./proVaardigheden";
import { rtgbPolitie } from "./rtgbPolitie";

export * from "./types";

export const SUBJECTS: Subject[] = [
  rekenen,
  boaRechtskennis,
  boaPraktijk,
  zelfverdediging,
  engels,
  nederlands,
  coaching,
  proVaardigheden,
  rtgbPolitie,
];

export const SUBJECT_BY_ID = new Map(SUBJECTS.map((s) => [s.id, s]));

export function allFlashcards(): { subject: Subject; card: (typeof SUBJECTS)[0]["flashcards"][0] }[] {
  return SUBJECTS.flatMap((subject) =>
    subject.flashcards.map((card) => ({ subject, card }))
  );
}

export function totalLessonCount(): number {
  return SUBJECTS.reduce((n, s) => n + s.lessons.length, 0);
}

export function subjectProgress(
  subject: Subject,
  completedLessons: Record<string, unknown>,
  passedTests: Record<string, unknown>
): { lessonsDone: number; lessonsTotal: number; testPassed: boolean; pct: number } {
  const lessonsDone = subject.lessons.filter((l) => completedLessons[l.id]).length;
  const lessonsTotal = subject.lessons.length;
  const testPassed = subject.tests.some((t) => passedTests[t.id]);
  const pct = Math.round(((lessonsDone + (testPassed ? 1 : 0)) / (lessonsTotal + 1)) * 100);
  return { lessonsDone, lessonsTotal, testPassed, pct };
}
