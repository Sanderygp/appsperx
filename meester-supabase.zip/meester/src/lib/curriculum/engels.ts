import type { Subject } from "./types";

// ============================================================
// VAK 5 — ENGELS (Security & Enforcement context)
// ============================================================

export const engels: Subject = {
  id: "engels",
  name: "Engels",
  short: "Engels",
  tagline: "English is your second uniform: wear it correctly.",
  description:
    "Engels voor handhaving en veiligheid: vakwoordenlijst, instructies geven, gesprekken voeren met internationale bezoekers en incidentverslagen in het Engels schrijven.",
  gradient: "from-sky-600/80 to-cyan-700/60",
  accent: "text-sky-300",
  icon: "Languages",
  lessons: [
    {
      id: "eng-1",
      title: "Vocabulary: On Duty",
      durationMin: 20,
      intro:
        "In tourist areas you will speak English daily. These are the core words of your trade — learn them by heart, they appear in every exam and every conversation on the street.",
      sections: [
        {
          heading: "Core enforcement vocabulary",
          body: "Start with the nouns you use every shift. An enforcement officer supervises compliance with local rules. A fine (or administrative penalty) is a financial sanction; a warning is lighter. You check identification documents, you report an incident, and you may confiscate alcohol in a no-drinking area. Learn them in short phrases, not as loose words: 'issue a fine', 'check your ID', 'report the incident'.",
          bullets: [
            "enforcement officer = handhaver",
            "fine / penalty = boete",
            "warning = waarschuwing",
            "ID check = identiteitscontrole",
            "to confiscate = in beslag nemen",
            "no-drinking area = drinkverbod-gebied",
          ],
        },
        {
          heading: "Places and people",
          body: "You work in public spaces. The public road is 'the street' or 'public road'; a park is a park, but a square is a 'square' (like Dam Square). People you deal with: a resident (bewoner), a visitor, a shopkeeper, a suspect (verdachte) and a witness (getuige). The police station is where you hand over detained persons; the town hall houses the mayor's office (burgemeester).",
          bullets: [
            "square = plein | public road = openbare weg",
            "resident = bewoner | witness = getuige | suspect = verdachte",
            "police station = politiebureau",
          ],
        },
        {
          heading: "Verbs of the job",
          body: "Action verbs carry your authority: to stop someone (staande houden), to question (vragen stellen), to warn (waarschuwen), to issue a fine, to seize property (in beslag nemen), to escort (begeleiden), to detain (vasthouden). Use the correct past tense in reports: stopped, warned, issued, seized, detained — all regular except 'seize → seized' (still regular spelling: -d).",
        },
      ],
      keyPoints: [
        "Learn vocabulary in phrases, not single words",
        "fine = boete | warning = waarschuwing | witness = getuige",
        "Report verbs: stopped, warned, issued, seized, detained",
      ],
    },
    {
      id: "eng-2",
      title: "Grammar: Present, Past and Questions",
      durationMin: 25,
      intro:
        "Correct grammar makes instructions unambiguous. In enforcement, ambiguity creates danger. Master these three structures and you can handle almost any street conversation.",
      sections: [
        {
          heading: "Present simple vs. present continuous",
          body: "Use the PRESENT SIMPLE for rules and facts: 'Smoking is prohibited here.' 'The bar closes at 01:00.' Use the PRESENT CONTINUOUS (am/is/are + -ing) for what is happening right now: 'You are drinking alcohol in a no-drinking area.' The contrast matters: rules are timeless (simple), observations are ongoing (continuous). Exam tip: choose simple for regulations, continuous for what you see.",
          bullets: [
            "Rule: 'Alcohol is prohibited in this park.' (simple)",
            "Observation: 'You are standing in a restricted area.' (continuous)",
          ],
        },
        {
          heading: "Past simple for reports",
          body: "Reports are written in past simple. Regular verbs take -ed: 'I stopped the man at 21:45.' Irregular verbs must be memorised: see → saw, take → took, give → gave, go → went, find → found, run → ran, catch → caught. Negatives and questions use did + infinitive: 'He did not comply.' 'Did you see who threw the bottle?' Never double the past: NOT 'He did not complied'.",
          bullets: [
            "Regular: stopped, warned, asked, identified",
            "Irregular: saw, took, gave, went, found, ran, caught",
            "Negative/question: did + basisvorm ('Did he comply?')",
          ],
        },
        {
          heading: "Polite questions and instructions",
          body: "Authority does not require rudeness. Polite forms increase compliance: 'Could you show me your ID, please?' 'Would you mind putting out the cigarette?' Direct instructions use the imperative, which is firm but neutral: 'Step aside, please.' 'Leave the area now.' Add 'please' to soften; never add 'okay?' at the end of a lawful instruction — it weakens the command.",
        },
      ],
      keyPoints: [
        "Rules = present simple | live observations = continuous",
        "Reports = past simple; know your irregular verbs",
        "Questions: did + infinitive",
        "Polite forms ('Could you...') increase compliance",
      ],
    },
    {
      id: "eng-3",
      title: "Incident reports & street conversations",
      durationMin: 25,
      intro:
        "From a drunk tourist who lost his phone to an aggressive group: you handle it in English. Structure and calm language win every time.",
      sections: [
        {
          heading: "The standard incident report (English)",
          body: "Use the same five-W structure as in Dutch. Model opening: 'On 14 December 2025 at approximately 21:45, I, officer Jansen, BOA for the municipality of Tilburg, was on patrol at Market Square. I observed three men drinking beer on a bench. Alcohol consumption is prohibited in this area by municipal regulation. I approached the men and identified myself.' Then facts in chronological order, then your actions, then the outcome. Keep sentences short. Never write slang.",
        },
        {
          heading: "Useful phrases for control situations",
          body: "Memorise these blocks: 'Excuse me, may I see your ID, please?' 'I'm afraid this area is alcohol-free.' 'You will receive a fine of 95 euros.' 'Do you understand what I just said?' 'I need you to step aside.' 'Stay calm. Help is on the way.' 'Could you wait here for the police, please?' Practise them out loud until they come automatically under stress.",
          bullets: [
            "'May I see your ID, please?'",
            "'This area is alcohol-free.'",
            "'You will receive a fine of ... euros.'",
            "'Stay calm. Help is on the way.'",
          ],
        },
        {
          heading: "Handling misunderstandings",
          body: "Not every visitor speaks perfect English. Speak slowly, use short sentences, avoid idioms ('break a leg' confuses people). Ask closed questions: 'Do you have identification with you — yes or no?' Use gestures to point at signs. If communication fails, seek help: a colleague, an interpreter line, or the police. Write down what language the person spoke — that fact matters for follow-up.",
        },
      ],
      keyPoints: [
        "Five-W structure also applies in English reports",
        "Phrase blocks beat loose words under stress",
        "Short sentences, no idioms, closed questions",
        "Note the language barrier in your report",
      ],
    },
  ],
  flashcards: [
    { id: "eng-f1", front: "fine (noun) betekent...", back: "Boete ('issue a fine' = een boete uitdelen)" },
    { id: "eng-f2", front: "to confiscate betekent...", back: "In beslag nemen ('I confiscated the alcohol')" },
    { id: "eng-f3", front: "witness / suspect / resident", back: "Getuige / verdachte / bewoner" },
    { id: "eng-f4", front: "Past simple van: see, take, give, go, find, run, catch", back: "saw, took, gave, went, found, ran, caught" },
    { id: "eng-f5", front: "Regel uitspreken (present simple): 'Alcohol ___ (prohibit) here.'", back: "'Alcohol is prohibited here.' — regels = present simple passief" },
    { id: "eng-f6", front: "Observatie nu: 'You ___ (drink) alcohol in a no-drinking area.'", back: "'You are drinking...' — live observatie = present continuous" },
    { id: "eng-f7", front: "Vraag in past simple: '___ he ___ (comply)?'", back: "'Did he comply?' — did + basisvorm" },
    { id: "eng-f8", front: "Hoe vraag je beleefd om een ID?", back: "'May / Could I see your ID, please?'" },
    { id: "eng-f9", front: "'Help is on the way' betekent...", back: "Hulp is onderweg" },
    { id: "eng-f10", front: "Idiom in rapporten? (wel/niet)", back: "Niet — geen spreekwoorden of slang; korte, letterlijke zinnen" },
    { id: "eng-f11", front: "'restricted area' betekent...", back: "Verboden/afgesloten gebied" },
    { id: "eng-f12", front: "Rapport-rotsooi vermijden: wat met 'okay?' na een instructie?", back: "Weglaten — het verzwakt het bevel ('Leave the area now.')" },
  ],
  tests: [
    {
      id: "eng-t1",
      title: "Toets 1: Vocabulary & Grammar",
      questions: [
        {
          id: "eng-t1-q1",
          question: "Choose the correct sentence for stating a rule:",
          options: [
            "Alcohol is prohibited in this park.",
            "Alcohol prohibits in this park.",
            "Alcohol was prohibiting here.",
            "Alcohol being prohibited here.",
          ],
          answerIndex: 0,
          explanation: "Regels = present simple passief: 'is prohibited'.",
        },
        {
          id: "eng-t1-q2",
          question: "Complete the live observation: 'Look — they ___ over there!'",
          options: ["fight", "are fighting", "fought", "fights"],
          answerIndex: 1,
          explanation: "Nu bezig = present continuous 'are fighting'.",
        },
        {
          id: "eng-t1-q3",
          question: "Past simple of 'to seize':",
          options: ["seized", "seized up", "seazon", "seize"],
          answerIndex: 0,
          explanation: "Regular: seize → seized.",
        },
        {
          id: "eng-t1-q4",
          question: "Correct question in past simple:",
          options: [
            "Did you saw the bottle?",
            "Did you see the bottle?",
            "Do you saw the bottle?",
            "Have you see the bottle?",
          ],
          answerIndex: 1,
          explanation: "did + basisvorm: 'Did you see...?'",
        },
        {
          id: "eng-t1-q5",
          question: "'The officer confiscated two bottles.' means:",
          options: [
            "De agent kocht twee flessen",
            "De agent nam twee flessen in beslag",
            "De agent brak twee flessen",
            "De agent vond twee flessen",
          ],
          answerIndex: 1,
          explanation: "confiscate = in beslag nemen.",
        },
        {
          id: "eng-t1-q6",
          question: "Most polite way to ask for ID:",
          options: [
            "Give me your ID.",
            "ID. Now.",
            "Could you show me your ID, please?",
            "Where is your ID, okay?",
          ],
          answerIndex: 2,
          explanation: "'Could you... please' is beleefd en toch duidelijk.",
        },
        {
          id: "eng-t1-q7",
          question: "In your English report, what is the correct opening?",
          options: [
            "I go to the square and see three guys drinking.",
            "On 14 December at 21:45, I observed three men drinking alcohol at Market Square.",
            "There was this guy and he was like drinking.",
            "Alcohol! Three men! Fine!",
          ],
          answerIndex: 1,
          explanation: "Rapporten: datum/tijd + waarneming in past simple, feitelijk en formeel.",
        },
        {
          id: "eng-t1-q8",
          question: "'witness' means:",
          options: ["verdachte", "getuige", "slachtoffer", "aangever"],
          answerIndex: 1,
          explanation: "witness = getuige; victim = slachtoffer; suspect = verdachte.",
        },
        {
          id: "eng-t1-q9",
          question: "A tourist does not understand you. Best approach:",
          options: [
            "Speak louder and faster",
            "Use idioms to sound natural",
            "Speak slowly, short sentences, closed questions",
            "Give up and walk away",
          ],
          answerIndex: 2,
          explanation: "Langzaam, kort, gesloten vragen + gebaren; hulp zoeken als het misgaat.",
        },
        {
          id: "eng-t1-q10",
          question: "Complete: 'I ___ the man at 21:45 and ___ him a fine.'",
          options: ["stop / give", "stopped / gave", "stopped / given", "stopping / giving"],
          answerIndex: 1,
          explanation: "Past simple beide: stopped + gave.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "eng-feyn-simple", label: "Present simple vs. continuous in enforcement" },
    { key: "eng-feyn-report", label: "De opbouw van een Engels incidentrapport" },
  ],
};
