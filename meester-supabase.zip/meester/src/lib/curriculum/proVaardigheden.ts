import type { Subject } from "./types";

// ============================================================
// VAK 8 — PROFESSIONELE VAARDIGHEDEN
// Focus: ethiek, uitstraling, communicatie
// ============================================================

export const proVaardigheden: Subject = {
  id: "pro-vaardigheden",
  name: "Professionele Vaardigheden",
  short: "Prof. Vaardigdh.",
  tagline: "Integriteit is wat je doet als niemand kijkt — behalve de bodycam.",
  description:
    "Ethiek en integriteit, uitstraling en lichaamstaal, en gesprekstechnieken die medewerking winnen. De vaardigheid waarmee je elke andere vak naar een hoger plan tilt.",
  gradient: "from-teal-600/80 to-emerald-700/60",
  accent: "text-teal-300",
  icon: "GraduationCap",
  lessons: [
    {
      id: "pro-1",
      title: "Ethiek en integriteit",
      durationMin: 25,
      intro:
        "Als toezichthouder ben je het gezicht van de rechtsstaat. Eén integriteitsfout schaadt niet alleen jou, maar het vertrouwen in de hele handhaving.",
      sections: [
        {
          heading: "Kernwaarden van de handhaving",
          body: "Vier kernwaarden sturen al je gedrag: INTEGRITEIT (eerlijk, geen misbruik van macht of informatie), PROPORTIONALITEIT (middel past bij het probleem), VAKMATIGHEID (je kent en past de regels correct toe) en DIENSTBAARHEID (je werkt voor de samenleving, niet tegen burgers). Elke beslissing test je tegen deze vier — en als één waarde onder druk komt, bespreek je dat met je leidinggevende vóór je handelt.",
          bullets: [
            "Integriteit: geen cadeaus, geen informatieverkoop, geen favoritisme",
            "Proportionaliteit: lichtste middel eerst",
            "Vakmatigheid: wetsartikelen correct toepassen",
            "Dienstbaarheid: respect voor elke burger",
          ],
        },
        {
          heading: "Belangenverstrengeling herkennen",
          body: "Belangenverstrengeling ontstaat wanneer je privébelangen je vakmatig oordeel raken: je handhaaft bij de kroeg van je oom, je ontvangt korting van een ondernemer die je controleert, of je verkoopt informatie over controles. De regel is hard: meld het vóóraf, draag de taak over, accepteer GEEN cadeaus of gunsten (ook geen koffie-met-appeltaart bij herhaling). Bij twijfel: altijd melden. Niemand oordeelt jou om het melden; wel om het zwijgen.",
        },
        {
          heading: "Discretie en geheimhouding",
          body: "Je ziet en hoort dingen die burgers niet zien: namen, adressen, gezondheidsinfo, camerabeelden. Alles wat je in je functie leert, is vertrouwelijk — ook 'gewoon' praten met je partner of vrienden is een inbreuk. Sociale media: nooit beelden of details van incidenten delen, nooit in uniform met politieke uitspraken. Wie discretie schendt, verliest zijn functie én kan strafrechtelijk worden vervolgd.",
        },
        {
          heading: "Het ethisch dilemma: een werkwijze",
          body: "Bij een dilemma loop je vijf stappen: (1) Wat is de feitelijke situatie? (2) Welke regels en waarden spelen? (3) Wie zijn de belanghebbenden? (4) Welke opties heb ik en wat is het gevolg per optie? (5) Kies, handel, en leg je keuze vast. Voorbeeld: je ziet je buurman iets doen wat op een overtreding lijkt — meld het bij je leidinggevende en vraag overdracht van de zaak. Transparantie wint altijd van stilte.",
        },
      ],
      keyPoints: [
        "Vier kernwaarden: integriteit, proportionaliteit, vakmatigheid, dienstbaarheid",
        "Belangenverstrengeling: melden vóóraf, taak overdragen",
        "Geen cadeaus, geen info delen, geen social media over incidenten",
        "Dilemma's: 5 stappen + keuze vastleggen",
      ],
    },
    {
      id: "pro-2",
      title: "Uitstraling, houding en lichaamstaal",
      durationMin: 20,
      intro:
        "Burgers oordelen binnen 7 seconden. Vóór je één woord zegt, heeft je uitstraling al de toon gezet.",
      sections: [
        {
          heading: "Verzorging en uniform",
          body: "Je uniform is niet mode maar symbool: strak gestreken, schoon, compleet, met correcte naamsinsignia. Haar verzorgd, schoenen gepoetst, geen privé-sieraden die gevaarlijk zijn bij fysiek contact. Waarom deze strengheid? Omdat schijnbare slordigheid wordt gelezen als slordig handhaven. Burgers accepteren een correctie van iemand die professioneel oogt sneller dan van iemand met een open veters.",
        },
        {
          heading: "Lichaamstaal die medewerking wint",
          body: "Gewenste houding: rechtop maar niet stijf, handen zichtbaar en ontspannen, oogcontact opzoeken zonder stares, en een open gezicht. Benadering in een hoek (niet frontaal-dreigend), armen nooit gekruist (sluit af), wijsvinger nooit in het gezicht (provocerend). Bij spanning: langzamer bewegen — snelheid voelt als dreiging. Spiegeltechniek: licht afstemmen op de tempo van de ander verlaagt weerstand.",
          bullets: [
            "Handen zichtbaar, open gestalten",
            "Benaderen in een hoek, op 1,5+ meter",
            "Langzamer bewegen bij spanning",
            "Oogcontact: aanwezig, niet starend",
          ],
        },
        {
          heading: "Stemgebruik",
          body: "Je stem is je krachtigste middel: laag tempo, laag volume bij spanning (omgekeerd instinct), duidelijke articulatie, en pauzes — stilte laat een boodschap landen. Bevelen formuleer je kort en zonder twijfelvormen ('Zet de muziek nu uit' niet 'Zou je misschien als het kan...'). Maar respect: 'u' tenzij de situatie een terechte 'jij' rechtvaardigt — consistent zijn is belangrijker dan welke van de twee.",
        },
      ],
      keyPoints: [
        "7 seconden eerste indruk: uniform + houding + stem",
        "Handen zichtbaar, hoekbenadering, langzaam bij spanning",
        "Bevelen kort en zonder twijfelvormen",
        "Stem omlaag bij agressie — niet omhoog",
      ],
    },
    {
      id: "pro-3",
      title: "Gesprekstechnieken die medewerking winnen",
      durationMin: 25,
      intro:
        "Een gesprek is een vak. Met deze technieken verhoog je de kans dat mensen meewerken — zelfs wanneer ze aanvankelijk boos zijn.",
      sections: [
        {
          heading: "Actief luisteren",
          body: "Actief luisteren = volledige aandacht + teruggeven wat je hoorde. Technieken: knikken en korte signalen ('ja', 'begrijp ik'), herhalen van kern ('Dus u stond hier al vóór half acht?'), samenvatten ('Samengevat: u voelde zich niet gehoord door de medewerker.'), en doorvragen op feiten ('Hoe laat precies? Wie was erbij?'). Luisteren kost minuten, bespaar een half uur discussie.",
        },
        {
          heading: "Ik-boodschappen",
          body: "Ik-boodschap = mijn observatie + mijn gevoel + mijn verzoek. 'Als u schreeuwt (observatie), kan ik mijn werk niet doen (effect). Ik wil u graag helpen — praat we rustiger (verzoek).' Vergelijk met jij-boodschap ('U schreeuwt, dat kan niet') die direct verdediging opwekt. Ik-boodschappen de-escaleren omdat ze geen aanval zijn, maar eerlijkheid.",
        },
        {
          heading: "Omgaan met verbaal verzet",
          body: "Verzet ('deze regels zijn belachelijk', 'doe maar normaal') is normaal en is geen persoonlijke aanval. Strategie: erken het gevoel ('Ik begrijp dat u dit vervelend vindt'), herhaal de regel kort en rustig ('De regel blijft: hier geldt een sluitingstijd'), geef keuze ('U kiest zelf hoe we dit afsluiten: de boete of meewerken?'), en sluit af. Niet herhalen als een machine: variatie in taal, vastheid in inhoud.",
        },
      ],
      keyPoints: [
        "Actief luisteren: herhalen, samenvatten, doorvragen",
        "Ik-boodschap: observatie + effect + verzoek",
        "Verzet = normaal; erken gevoel, houd de regel vast",
        "Keuze geven verhoogt medewerking",
      ],
    },
  ],
  flashcards: [
    { id: "pro-f1", front: "Vier kernwaarden handhaving?", back: "Integriteit, proportionaliteit, vakmatigheid, dienstbaarheid" },
    { id: "pro-f2", front: "Cadeautje van de horecaondernemer?", back: "Niet accepteren — meld het; ook herhaalde gunsten zijn belangenverstrengeling" },
    { id: "pro-f3", front: "Je ziet je buurman een overtreding doen?", back: "Melden bij leidinggevende + overdracht van de zaak vragen" },
    { id: "pro-f4", front: "Mag je incidentdetails delen met je partner?", back: "Nee — alles uit je functie is vertrouwelijk" },
    { id: "pro-f5", front: "Benadering in hoek of frontaal?", back: "In een hoek, op 1,5+ meter — frontaal voelt als dreiging" },
    { id: "pro-f6", front: "Stemvolume bij agressie?", back: "Omlaag — langzaam en zacht verslaat luid en snel" },
    { id: "pro-f7", front: "Drie technieken actief luisteren?", back: "Herhalen van kern, samenvatten, doorvragen op feiten" },
    { id: "pro-f8", front: "Ik-boodschap = ...", back: "Observatie + effect + verzoek" },
    { id: "pro-f9", front: "Verbaal verzet is...", back: "Normaal, geen persoonlijke aanval: erken gevoel, houd de regel, geef keuze" },
    { id: "pro-f10", front: "Hoeveel seconden eerste indruk?", back: "±7 seconden — vóór het eerste woord" },
  ],
  tests: [
    {
      id: "pro-t1",
      title: "Toets 1: Ethiek & communicatie",
      questions: [
        {
          id: "pro-t1-q1",
          question: "Een caféhouder waar jij controleert biedt je elke week een gratis maaltijd aan. Wat doe je?",
          options: [
            "Aanvaarden — het is maar eten",
            "Aanvaarden maar niets terugdoen",
            "Weigeren en melden; herhaalde gunsten zijn belangenverstrengeling",
            "Aanvaarden en betalen als je zin hebt",
          ],
          answerIndex: 2,
          explanation: "Gunsten ondermijnen je onafhankelijkheid; weigeren + melden is de norm.",
        },
        {
          id: "pro-t1-q2",
          question: "Wat hoort NIET thuis bij de kernwaarde integriteit?",
          options: [
            "Geen informatie verkopen of delen",
            "Favoritisme vermijden",
            "Straffer handhaven bij mensen die je niet aardig vindt",
            "Transparant handelen",
          ],
          answerIndex: 2,
          explanation: "Straffer handhaven uit ongunst = misbruik van bevoegdheid, geen integriteit.",
        },
        {
          id: "pro-t1-q3",
          question: "Je moet controleren bij de winkel van je oom. Correcte handeling?",
          options: [
            "Gewoon doen, familie is geen probleem",
            "Doen maar niet rapporteren",
            "Melden en overdracht van de taak vragen",
            "Zeggen dat je ziek bent",
          ],
          answerIndex: 2,
          explanation: "Belangenverstrengeling: melden vóóraf en overdragen.",
        },
        {
          id: "pro-t1-q4",
          question: "Welke lichaamstaal de-escaleren het beste?",
          options: [
            "Frontaal dichterbij komen en wijzen",
            "In hoek benaderen, handen zichtbaar, langzaam bewegen",
            "Armen gekruist, starend oogcontact",
            "Telefoon erbij nemen",
          ],
          answerIndex: 1,
          explanation: "Hoek + zichtbare handen + tempo omlaag = veilig en uitnodigend tot medewerking.",
        },
        {
          id: "pro-t1-q5",
          question: "Beste formulering van een bevel?",
          options: [
            "'Zou je misschien, als het kan, de muziek wat zachter kunnen zetten?'",
            "'Zet de muziek nu uit, alstublieft.'",
            "'Musiek uit!!'",
            "'Kunnen we het erover hebben dat de muziek...'",
          ],
          answerIndex: 1,
          explanation: "Kort, duidelijk, beleefd: geen twijfelvormen, geen schreeuwen.",
        },
        {
          id: "pro-t1-q6",
          question: "'Als u blijft schreeuwen, kan ik u niet helpen. Praat we rustiger.' Dit is een...",
          options: ["jij-boodschap met dreiging", "ik-boodschap (observatie + effect + verzoek)", "bevel zonder toelichting", "machtsshow"],
          answerIndex: 1,
          explanation: "Observatie (schreeuwen) + effect (kan niet helpen) + verzoek (rustiger) = ik-boodschap.",
        },
        {
          id: "pro-t1-q7",
          question: "Iemand zegt: 'Die regels zijn toch belachelijk.' Beste reactie?",
          options: [
            "'U heeft gewoon gelijk, ik vind ze ook niks.'",
            "'Ik begrijp dat u het vervolgd vindt; de regel geldt hier wel. U kiest zelf hoe we dit afronden.'",
            "'Pas op met wat je zegt.'",
            "Zwijgen en boete uitschrijven",
          ],
          answerIndex: 1,
          explanation: "Erken gevoel + vasthouden aan regel + keuze geven.",
        },
        {
          id: "pro-t1-q8",
          question: "Waarom is een verzorgd uniform belangrijk?",
          options: [
            "Puur esthetisch",
            "Slordigheid wordt gelezen als slordig handhaven; uitstraling bepaalt acceptatie",
            "Omdat de directie dat wil",
            "Het is niet belangrijk",
          ],
          answerIndex: 1,
          explanation: "De eerste 7 seconden bepalen de toon van elk gesprek.",
        },
        {
          id: "pro-t1-q9",
          question: "Sociale media: wat mag?",
          options: [
            "Een foto van een boete met kenteken",
            "Een video van een incident zonder namen",
            "Niets over incidenten — geen beelden, geen details",
            "Meningen in uniform over politiek",
          ],
          answerIndex: 2,
          explanation: "Discretie: geen incidentcontent, geen beelden, geen politiek in uniform.",
        },
        {
          id: "pro-t1-q10",
          question: "Eerste stap bij een ethisch dilemma?",
          options: [
            "Direct kiezen wat je gevoel zegt",
            "Feitelijke situatie helder krijgen: wat gebeurt er precies?",
            "Vragen aan een vriend",
            "Wachten tot het overwaait",
          ],
          answerIndex: 1,
          explanation: "Stap 1 van de werkwijze: feiten boven gevoel, dan waarden, belanghebbenden, opties.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "pro-feyn-integriteit", label: "Waarom geen cadeaus van ondernemers" },
    { key: "pro-feyn-ikboodschap", label: "De ik-boodschap in vier woorden" },
  ],
};
