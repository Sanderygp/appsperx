import type { Subject } from "./types";

// ============================================================
// VAK 7 — COACHING (leiderschap, feedback, psychologie)
// ============================================================

export const coaching: Subject = {
  id: "coaching",
  name: "Coaching",
  short: "Coaching",
  tagline: "Leiderschap is geen rang — het is gedrag dat anderen beter maakt.",
  description:
    "Situatiegericht leiderschap, feedback volgens het SBI-model en psychologische inzichten: biases, stress en motivatie. Voor wie groeit van wachter naar aanvoerder.",
  gradient: "from-violet-600/80 to-purple-700/60",
  accent: "text-violet-300",
  icon: "Users",
  lessons: [
    {
      id: "coa-1",
      title: "Leiderschapsstijlen",
      durationMin: 25,
      intro:
        "Er is geen beste leiderschapstijl — er is een passende stijl per persoon en per situatie. Wie dat snapt, leidt zowel een 17-jarige nieuwe collega als een doorgewinterde teamleider.",
      sections: [
        {
          heading: "Situatiegericht leiderschap (Hersey & Blanchard)",
          body: "De kern: jouw stijl hangt af van de ONTWIKKELINGSFASE van de medewerker in die specifieke taak. Fase 1 (onbekwaam maar gemotiveerd): STUREND leiderschap — duidelijke instructie, dicht erop. Fase 2 (matig bekwaam, wisselend gemotiveerd): COACHEND — instructie PLUS aandacht en aanmoediging. Fase 3 (bekwaam, onzeker): ONDERSTEUNEND — deelnemen, vragen stellen, vertrouwen geven. Fase 4 (bekwaam en zeker): DELEGEREND — doel afspreken en loslaten. Fout: fase-4-collega's micro-managen (frustratie) of fase-1-collega's delegeren (riskant).",
          bullets: [
            "Fase 1 → sturend | Fase 2 → coachend",
            "Fase 3 → ondersteunend | Fase 4 → delegerend",
            "Stijl volgt de fase, niet jouw voorkeur",
          ],
        },
        {
          heading: "Autoritair vs. democratisch",
          body: "Autoritair (de leidinggevende beslist alleen) werkt bij acute veiligheidsrisico's: 'Nu afzetten, geen discussie.' Democratisch (beslissen samen) werkt bij plannen, verbeteringen en motivatie. Laissez-faire (alles loslaten) werkt vrijwel nooit bij handhaving — niemand weet waar hij aan toe is. Een goede aanvoerder schakelt: in het incident autoritair, in de evaluatie democratisch.",
        },
        {
          heading: "Voorbeeld: de eerste patrouille van een nieuwe collega",
          body: "Nieuwe collega, eerste ronde (fase 1): jij loopt voor, demonstreert de aanspreektechniek, beslist over de boete, legt na elke stap uit waarom. Week drie (fase 2): collega loopt voor, jij noteert observaties en geeft tussendoor feedback. Twee maanden (fase 3): collega doet alles, jij stelt vragen en versterkt. Zes maanden (fase 4): jij stuurt collega alleen op pad en bespreek je afwijkingen achteraf. Zo groei je van opleider naar coach naar vertrouwenspersoon.",
        },
      ],
      keyPoints: [
        "Leiderschapsstijl volgt de ontwikkelingsfase van de ander",
        "Sturend → coachend → ondersteunend → delegerend",
        "Incident = autoritair, evaluatie = democratisch",
      ],
    },
    {
      id: "coa-2",
      title: "Feedback geven volgens het SBI-model",
      durationMin: 20,
      intro:
        "Feedback is geen kritiek — het is informatie die iemand helpt te groeien. Slechte feedback vernietigt; goede feedback bouwt. Het SBI-model is je gereedschap.",
      sections: [
        {
          heading: "Situatie – Gedrag – Impact (SBI)",
          body: "SITUATIE: benoem het concrete moment ('Gisteren tijdens de controle aan de Kerkstraat...'). GEDRAG: beschrijf wat je ZAG en HOORDE, zonder oordeel ('...onderbrak je de burger drie keer terwijl hij zijn verhaal deed...'). IMPACT: benoem het effect ('...waardoor hij onrustig werd en we informatie misliepen.'). Sluit af met een vraag: 'Wat zag jij er van?' Zo houdt het een gesprek en geen vonnis.",
          bullets: [
            "S: concreet moment, niet 'altijd' of 'nooit'",
            "B: waarneembaar gedrag, geen interpretatie",
            "I: effect op jou, het team of de burger",
          ],
        },
        {
          heading: "Feedbackregels",
          body: "Regel 1: feedback gaat over GEDRAG, nooit over de persoon ('je was ongeduldig' → persoonlijk; 'je onderbrak hem' → gedrag). Regel 2: positieve feedback krijgt EVENVEEL aandacht als corrigerende feedback — en is concreet, geen 'goed gedaan' maar 'jouw rustige toon hield die groep kalm, sterk gedaan'. Regel 3: kies het moment — niet in de hitte van het incident, maar kort erna. Regel 4: één thema per gesprek. Regel 5: check of de boodschap aankomt; laat de ander teruggeven wat hij hoort.",
        },
        {
          heading: "Feedback ontvangen",
          body: "Professionele groei vraagt óók ontvangen kunnen. Luister zonder te verdedigen, vat samen ('dus je vond dat ik te snel ging?'), vraag om voorbeelden, en bedank — ook als je het niet helemaal eens bent. Zoek actief feedback: 'Wat kan ik volgende ronde beter?' Dat signaal versterkt jouw positie in elk team.",
        },
      ],
      keyPoints: [
        "SBI: Situatie – Gedrag – Impact, afsluiten met vraag",
        "Gedrag, nooit de persoon",
        "Positieve feedback = concreet, niet algemeen",
        "Feedback ontvangen: luisteren, samenvatten, bedanken",
      ],
    },
    {
      id: "coa-3",
      title: "Psychologische inzichten voor de straat",
      durationMin: 25,
      intro:
        "Je brein neemt honderden beslissingen per dienst. Psychologische bias en stressmechanismen kleuren die beslissingen — wie ze kent, denkt scherper.",
      sections: [
        {
          heading: "Bevestigingsbias en het halo-effect",
          body: "Bevestigingsbias: je zoekt (onbewust) informatie die je eerste indruk bevestigt. Denk je 'die jongen zit aan de drank', dan zie je elke babbel als dranksignaal en negeer je dat hij een medicijngebruiker is. Halo-effect: één positief of negatief kenmerk kleurt al het andere — een nette man met een zakdiploma lijkt betrouwbaarder, maar dat is géén bewijs. Tegengif: bewijs verzamelen vóór je conclusie trekt, en jezelf vragen: 'Welk bewijs zou mijn hypothese WEERLEGGEN?'",
        },
        {
          heading: "Stress en het brein",
          body: "Onder stress versmalt je blik (tunnelvisie), valt fijnmotoriek weg en neemt de gerichtheid op één dreiging toe. Dat is evolutionair nuttig maar gevaarlijk als je een groep moet overzien. Tegengif: ademhaling 4-6, bewust rondkijken ('head on a swivel'), en vooraf bedachte routines (meldkamer bellen, afstand, dekpositie) — routines blijven werken als het denken stopt. Oefening onder druk (rollenspellen) maakt je brein stabieler.",
        },
        {
          heading: "Motivatie: intrinsiek versus extrinsiek",
          body: "Extrinsieke motivatie komt van buiten (boetes, bonussen, straf). Intrinsieke motivatie komt van binnen (meesterschap, autonomie, verbondenheid). Wie wil motiveren, koppelt taken aan die drie: 'Jij kent dit gebied als geen ander (autonomie); jouw aanpak van die groep heeft de overlast gehalveerd (meesterschap); het team rekent op je (verbondenheid).' Straf gedrag aan, maar bouw gedrag op met intrinsieke motivatie — dat geldt voor collega's én voor overlastgevers.",
        },
      ],
      keyPoints: [
        "Zoek bewijs dat je hypothese WEERLEGT (tegen bevestigingsbias)",
        "Eén kenmerk bepaalt geen hele persoon (halo)",
        "Onder stress: adem 4-6, routines volgen, rondkijken",
        "Motivatie: autonomie, meesterschap, verbondenheid",
      ],
    },
  ],
  flashcards: [
    { id: "coa-f1", front: "Vier stijlen van situatiegericht leiderschap?", back: "Sturend, coachend, ondersteunend, delegerend" },
    { id: "coa-f2", front: "Fase 1 (onbekwaam + gemotiveerd) vraagt welke stijl?", back: "Sturend — duidelijke instructie, dichtbij" },
    { id: "coa-f3", front: "Fase 4 (bekwaam + zeker) vraagt...?", back: "Delegerend — doel afspreken en loslaten" },
    { id: "coa-f4", front: "SBI staat voor...", back: "Situatie – Gedrag – Impact" },
    { id: "coa-f5", front: "Feedback over gedrag of over de persoon?", back: "Over gedrag: 'je onderbrak hem', niet 'je bent ongeduldig'" },
    { id: "coa-f6", front: "Wanneer feedback geven?", back: "Kort na het moment, niet in de hitte van het incident; één thema" },
    { id: "coa-f7", front: "Bevestigingsbias is...", back: "Zoeken naar informatie die je eerste indruk bevestigt" },
    { id: "coa-f8", front: "Tegengif tegen bias?", back: "Zoek bewijs dat je hypothese weerlegt" },
    { id: "coa-f9", front: "Halo-effect betekent...", back: "Eén kenmerk kleurt je hele oordeel over iemand" },
    { id: "coa-f10", front: "Ademhalingsoefening onder stress?", back: "4 tellen in, 6 tellen uit" },
    { id: "coa-f11", front: "Drie bronnen van intrinsieke motivatie?", back: "Autonomie, meesterschap, verbondenheid" },
    { id: "coa-f12", front: "Incident vs evaluatie: welke stijl?", back: "Incident: autoritair (snel beslissen). Evaluatie: democratisch." },
  ],
  tests: [
    {
      id: "coa-t1",
      title: "Toets 1: Leiderschap & psychologie",
      questions: [
        {
          id: "coa-t1-q1",
          question: "Een nieuwe collega (week 1, eerste controles). Welke stijl past?",
          options: ["Delegerend", "Sturend", "Ondersteunend", "Laissez-faire"],
          answerIndex: 1,
          explanation: "Fase 1 = sturend: instructie, demonstratie, dichtbij blijven.",
        },
        {
          id: "coa-t1-q2",
          question: "Wat is het risico als je een fase-4-collega blijft micro-managen?",
          options: [
            "Niets, voorzichtigheid loont altijd",
            "Frustratie en demotivatie; vertrouwen wordt geschaad",
            "De collega wordt automatisch fase 1",
            "De taak wordt beter uitgevoerd",
          ],
          answerIndex: 1,
          explanation: "Stijl moet passen bij de fase; te sturend bij fase 4 = demotivatie.",
        },
        {
          id: "coa-t1-q3",
          question: "Welke feedback is correct volgens SBI?",
          options: [
            "'Je bent altijd zo ongeduldig.'",
            "'Gisteren bij de controle onderbrak je de man driemaal, waardoor hij stilviel en we informatie misliepen. Wat zag jij?'",
            "'Je doet het prima, ga zo door!'",
            "'Volgende keer gewoon beter luisteren.'",
          ],
          answerIndex: 1,
          explanation: "S (gisteren bij de controle) + B (onderbrak driemaal) + I (informatie misgelopen) + vraag.",
        },
        {
          id: "coa-t1-q4",
          question: "'De man draagt een pak, dus hij is betrouwbaar.' Welke bias is dit?",
          options: ["Bevestigingsbias", "Halo-effect", "Recency-effect", "Ankereffect"],
          answerIndex: 1,
          explanation: "Eén kenmerk (net uiterlijk) kleurt het hele oordeel = halo-effect.",
        },
        {
          id: "coa-t1-q5",
          question: "Wanneer is een autoritaire stijl passend?",
          options: [
            "Bij jaarplanning van het team",
            "Bij acute veiligheidsrisico's waar snelheid telt",
            "Bij het beoordelen van collega's",
            "Altijd — zo toon je gezag",
          ],
          answerIndex: 1,
          explanation: "Snelheid en veiligheid vragen één beslisser; planning en evaluatie vragen democratie.",
        },
        {
          id: "coa-t1-q6",
          question: "Positieve feedback werkt het beste als ze...",
          options: [
            "algemeen is: 'goed gedaan'",
            "concreet is over welk gedrag welk effect had",
            "in het openbaar wordt gegeven terwijl anderen toekijken",
            "wordt gecombineerd met kritiek",
          ],
          answerIndex: 1,
          explanation: "Concreet gedrag + effect = herhaalbaar en geloofwaardig.",
        },
        {
          id: "coa-t1-q7",
          question: "Wat gebeurt er met je waarneming onder acute stress?",
          options: [
            "Ze wordt breder en rustiger",
            "Tunnelvisie, verlies van fijnmotoriek, focus op één dreiging",
            "Niets merkbaars",
            "Je hoort beter dan normaal zonder nadelen",
          ],
          answerIndex: 1,
          explanation: "Stress versmalt perceptie; daarom routines en rondkijken trainen.",
        },
        {
          id: "coa-t1-q8",
          question: "Welke vraag weerlegt een hypothese (tegen bevestigingsbias)?",
          options: [
            "'Welk bewijs bevestigt mijn vermoeden?'",
            "'Welk bewijs zou mijn vermoeden wegnemen?'",
            "'Wat denken anderen er ook van?'",
            "'Heb ik gelijk?'",
          ],
          answerIndex: 1,
          explanation: "Falsificatie-denken: zoek de tegenbewijzen.",
        },
        {
          id: "coa-t1-q9",
          question: "Autonomie, meesterschap en verbondenheid zijn bronnen van...",
          options: ["extrinsieke motivatie", "intrinsieke motivatie", "stress", "bias"],
          answerIndex: 1,
          explanation: "Intrinsieke motivatie komt van binnenuit: zelfstandigheid, groei, erbij horen.",
        },
        {
          id: "coa-t1-q10",
          question: "Je krijgt kritische feedback. Beste reactie?",
          options: [
            "Direct verdedigen dat het niet jouw schuld was",
            "Luisteren, samenvatten, om voorbeelden vragen, bedanken",
            "Zwijgen en later weglopen",
            "De gever terugpakken",
          ],
          answerIndex: 1,
          explanation: "Professioneel ontvangen: luisteren, samenvatten, voorbeelden, dank.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "coa-feyn-sbi", label: "Het SBI-model uitleggen" },
    { key: "coa-feyn-bias", label: "Bevestigingsbias op straat" },
  ],
};
