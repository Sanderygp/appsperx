import type { Subject } from "./types";

// ============================================================
// VAK 3 — BOA PRAKTIJK
// Focus: toezichtronde, aanspreken & de-escaleren, rapporteren
// ============================================================

export const boaPraktijk: Subject = {
  id: "boa-praktijk",
  name: "BOA Praktijk",
  short: "Praktijk",
  tagline: "Op straat telt wat jij doet in de eerste vijf seconden.",
  description:
    "Scenario-based leren: de observatieronde, aanspreektechniek, de-escalatie, correct rapporteren en samenwerken met de meldkamer. Dit is het vak waar theorie straat slimmer wordt.",
  gradient: "from-emerald-600/80 to-green-700/60",
  accent: "text-emerald-300",
  icon: "ShieldCheck",
  lessons: [
    {
      id: "bpr-1",
      title: "De observatieronde: zien, registreren, handelen",
      durationMin: 25,
      intro:
        "Toezicht houden is geen wandeling. Een goede ronde is gepland, gericht en gedocumenteerd: je weet waar je kijkt, waarom je daar kijkt en wat je noteert als iets afwijkt.",
      sections: [
        {
          heading: "De ronde voorbereiden",
          body: "Voor elke ronde check je: welke locaties hebben prioriteit (op basis van meldingen, tijdstip en kwetsbaarheid), wat zijn de geldende voorschriften per locatie (sluitingstijden, vergunningvoorwaarden, drinkverbod), en welke route loopt je efficiënt maar onvoorspelbaar voor overlastgevers. Verander je routes af — wie altijd om 22:00 uur dezelfde hoek slaat, is voorspelbaar en daarmee on effectief.",
          bullets: [
            "Prioriteiten op basis van meldingen en risico",
            "Voorschriften per locatie kennen vooraf",
            "Route efficiënt én onvoorspelbaar",
          ],
        },
        {
          heading: "Wat observeer je concreet?",
          body: "Je observeert met alle zintuigen: persoon (gedrag, staat, leeftijd), situatie (geluid, afval, schade, geur), object (afzettingen, sloten, verlichting) en groep (dynamiek, aanvoerder, spanning). Vier vragen sturen je blik: klopt dit met de voorschriften? Is er gevaar? Is er schade? Is er een patroon? Een kapotte ruit is op zich niets; drie kapotte ruiten in dezelfde straat in één week is een patroon waar je melding van maakt.",
        },
        {
          heading: "Registreren: het notitieboek",
          body: "Noteer direct en feitelijk: tijdstip, plaats, waargenomen feiten, namen en kenmerken van betrokkenen, en wat jij hebt gedaan. Schrijf geen meningen ('het was een verdachte man') maar observaties ('man, ± 30 jaar, donkere jas, controleerde drie geparkeerde auto's, liep weg bij mijn nadering'). Deze notities zijn later de basis van je proces-verbaal of meldrapport. Geheugen vervaalt binnen uren — papier (of je PDA) onthoudt wel.",
        },
        {
          heading: "Beslissen: het handhavingskader",
          body: "Bij elke bevinding loop je hetzelfde kader door: (1) Is er een overtreding of risico? (2) Wat is de zwaarte en urgentie? (3) Welk middel past: aanspreken, waarschuwen, boete, melding bij andere dienst? (4) Documenteer de keuze. 'Niet handhaven' is óók een keuze die je onderbouwt. Consistentie is het sleutelwoord: gelijke gevallen gelijk behandeld, anders is je handhaving aanvechtbaar en onrechtvaardig.",
        },
      ],
      keyPoints: [
        "Ronde = prioriteit + voorschriften + onvoorspelbare route",
        "Observeer persoon, situatie, object, groep",
        "Feiten noteren, nooit meningen",
        "Handhavingskader: constateren → afwegen → middel → documenteren",
      ],
    },
    {
      id: "bpr-2",
      title: "Aanspreken en de-escaleren",
      durationMin: 30,
      intro:
        "Negen van de tien situaties win je met woorden. De kunst is niet om macht te tonen, maar om de ander te laten meewerken zonder dat het gezicht van niemand wordt verlies.",
      sections: [
        {
          heading: "De eerste 10 seconden",
          body: "Benader rustig en zichtbaar, van voren, op armlengte-plus-afstand (minimaal 1,5 meter). Identificeer jezelf: 'Goedendag, ik ben [naam], buitengewoon opsporingsambtenaar van de gemeente [X].' Gebruik een neutrale, kalme stem — je spreektempo bepaalt deels het tempo van het gesprek. Benoem concrete gedrag, geen etiketten: niet 'je bent aan het vechten' maar 'ik zag dat jullie elkaar duwden'.",
          bullets: [
            "Benadering van voren, rustig, zichtbaar",
            "1,5+ meter afstand, handen vrij en zichtbaar",
            "Identificatie + functie noemen",
            "Gedrag benoemen, persoon niet labelen",
          ],
        },
        {
          heading: "De-escalatietechnieken",
          body: "De kern: laat de ander keuze en waardigheid. Technieken: ACTIEF LUISTEREN (laat de persoon uitpraten, knik, vat samen: 'Dus je zegt dat...'), EMPATHIE (ik zie dat je boos bent, zonder instemmen), OPTIES GEVEN (je kunt hier nu doorgaan en een boete krijgen, of de fles weggooien en we lossen het zo op), HERHALEN VAN DE BOODSCHAP (roken rustig terug op het punt: de regel geldt hier, ongeacht het gesprek). Vermijd: bedreigingen die je niet wilt uitvoeren, publieke vernedering, en het woord 'moeten' als 'kunt u' ook werkt.",
        },
        {
          heading: "De escalatietrap herkennen",
          body: "Mensen escaleren in fasen: ongerustheid → frustratie → agressie (verbaal) → dreiging → fysiek geweld. Elke fase vraagt een ander middel. In de fase frustratie werkt doorvragen en opties geven; bij verbale agressie verlaag je je eigen volume en creëer je ruimte; bij dreiging maak je afstand en waarschuw je collega's/meldkamer. Weten wanneer je NIET verder praat maar afstand neemt is een teken van professionaliteit, niet van zwakte.",
        },
        {
          heading: "Scenario: dronken bezoeker in het park",
          body: "Situatie: man van ±40, duidelijk aangeschoten, drinkt bier op een plek met drinkverbod. Aanpak: (1) Benader rustig, identificeer je. (2) Benoem het gedrag: 'Ik zie dat u hier alcohol drinkt; hier geldt een drinkverbod.' (3) Vraag en optie: 'Gooit u de fles weg, dan hoeft er meer niet te gebeuren.' (4) Bij medewerking: bedank, documenteer kort. (5) Bij weigeren + vervolg overtreding: bestuurlijke boete of in beslagname van de drank, melding bij politie bij agressie. Alles noteer je: tijd, plaats, gedrag, jouw stappen.",
        },
      ],
      keyPoints: [
        "Eerste 10 seconden bepalen het gesprek",
        "Gedrag benoemen, niet het persoon labelen",
        "Opties geven = medewerking verhogen",
        "Escalatiefase bepaalt jouw middel",
      ],
    },
    {
      id: "bpr-3",
      title: "Rapporteren en het proces-verbaal",
      durationMin: 25,
      intro:
        "Je rapport is je gerechtelijk bewijs en je eer. Een zwak rapport verliest een zaak; een sterk rapport houdt stand tegen bezwaar en rechter.",
      sections: [
        {
          heading: "De vijf W's",
          body: "Elk rapport bevat: WIE (betrokkenen met kenmerken), WAT (wat is er precies gebeurd, in volgorde), WAAR (exacte locatie), WANNEER (datum en tijd), en WAAROM/HOE (omstandigheden, getuigen, bewijs). Daarnaast: wat heb JIJ gedaan en gezegd, en wat is de uitkomst. Alles objectief, chronologisch en in de derde persoon. Meningen, insinuaties en aannames horen thuis in het hoofd, niet in het rapport.",
        },
        {
          heading: "Feit versus mening",
          body: "Feit: 'De man liep op 14 december om 21:45 uur door het plantsoen en gooide een blikje op de grond na aanspreking.' Mening: 'De man was brutaal en onbeschoft.' De rechter of boetebeslisser wil kunnen reconstrueren wat er gebeurde. Formuleringen als 'naar het zich liet aanzien' en 'mogelijk' zijn toegestaan als je onzekerheid benoemt — dat is eerlijk, niet zwak. Noem ook het NIET-geziene: 'ik heb de fles niet zien gooien, ik zag het resultaat'.",
        },
        {
          heading: "Proces-verbaal: opbouw en taal",
          body: "Een PV bevat: je identiteitsgegevens en functie, datum/tijd/locatie van bevinding, feiten in chronologische volgorde, verklaringen van verdachte en getuigen, bewijsmiddelen (foto's, in beslag genomen items), en jouw handelingen. Schrijf korte zinnen, gebruik actieve vorm ('ik zag', 'ik sprak aan'), geen jargon of straattaal, en controleer spelling — een rapport vol fouten ondersmijnt je geloofwaardigheid. Onderteken, en geef een kopie of inzagerecht volgens de regels.",
        },
      ],
      keyPoints: [
        "Vijf W's + eigen handelingen = volledig rapport",
        "Feiten, chronologisch, derde persoon",
        "Onzekerheid benoemen = professionaliteit",
        "Korte zinnen, actieve vorm, correcte spelling",
      ],
    },
    {
      id: "bpr-4",
      title: "Meldkamer, radio en samenwerking",
      durationMin: 20,
      intro:
        "Je werkt nooit alleen. De meldkamer, politie, brandweer en je collega's zijn je systeem — en systeemwerk hangt aan heldere communicatie.",
      sections: [
        {
          heading: "Radiogebruik: kort, helder, volledig",
          body: "Een correcte radio-melding bevat: wie jij bent, waar je bent, wat er speelt en welke hulp je nodig hebt. Bijvoorbeeld: 'Meldkamer, dit is BOA Jansen, plantsoen De Akkers, man bewusteloos, ik start reanimatie, stuur ambulance.' Volgorde: belangrijkste eerst. Spreken rustig en in zinnen; radio is geen telefoongesprek. Bevestig inkomende berichten door herhalen van de kern ('begrepen, ambulance onderweg').",
          bullets: [
            "Structuur: wie–waar–wat–hulpvraag",
            "Belangrijkste informatie eerst",
            "Inkomen bericht bevestigen",
            "Rustig spreken, ook onder druk",
          ],
        },
        {
          heading: "Samenwerken met politie en hulpdiensten",
          body: "Buiten je taakveld of bij ernst: neem afstand tot het feitenonderzoek en maak het werk van de politie mogelijk — afzetten, getuigen vasthouden (vriendelijk, met uitleg), je observaties doorgeven. Bij brandweer: veiligheid van omgeving en informatie over het pand. Jouw rol daarbij: ogen en oren, verkeersregelaar waar bevoegd, en rapporteur. Overdracht is een kunst: geef feiten, geef jouw handelingen, geef open punten.",
        },
        {
          heading: "Interne overdracht aan collega's",
          body: "Aan het eind van je dienst of ronde draag je over: lopende zaken, signalen uit het gebied, afspraken met personen of ondernemers, en materiaalstatus (PDA, bodycam, sleutels). Een goede overdracht voorkomt dubbel werk en gevaarlijke hiaten — de volgende wachter moet kunnen voortbouwen op jouw notities. Discipline in overdracht is discipline in het team.",
        },
      ],
      keyPoints: [
        "Radiomelding: wie–waar–wat–hulpvraag, belangrijkste eerst",
        "Bevestig inkomende berichten",
        "Buiten je taakveld: faciliteren, niet onderzoeken",
        "Overdracht: lopende zaken, signalen, afspraken, materiaal",
      ],
    },
  ],
  flashcards: [
    { id: "bpr-f1", front: "Vijf W's van elk rapport?", back: "Wie, Wat, Waar, Wanneer, Waarom/Hoe — plus jouw eigen handelingen" },
    { id: "bpr-f2", front: "Minimale benaderingsafstand bij aanspreken?", back: "±1,5 meter, van voren, handen vrij en zichtbaar" },
    { id: "bpr-f3", front: "Benoem gedrag of label het persoon?", back: "Gedrag: 'ik zag dat je duwde', niet 'jij bent aan het vechten'" },
    { id: "bpr-f4", front: "Drie de-escalatietechnieken?", back: "Actief luisteren, empathie tonen, opties geven" },
    { id: "bpr-f5", front: "Fasen van de escalatietrap?", back: "Ongerustheid → frustratie → verbale agressie → dreiging → fysiek geweld" },
    { id: "bpr-f6", front: "Feit of mening: 'de man was brutaal'?", back: "Mening — nota los van observatie, hoort niet in een PV" },
    { id: "bpr-f7", front: "Structuur van een radio-melding?", back: "Wie jij bent – waar – wat er speelt – welke hulp je nodig hebt" },
    { id: "bpr-f8", front: "Wat doe je bij een incident buiten je taakveld?", back: "Vaststellen, beveiligen, doorgeven aan politie — niet zelf opsporen" },
    { id: "bpr-f9", front: "Waarom routes afwisselen tijdens toezicht?", back: "Onvoorspelbaarheid verhoogt effectiviteit tegen herhaalde overlast" },
    { id: "bpr-f10", front: "Wat noteer je bij een bevinding?", back: "Tijd, plaats, feitelijke observaties, kenmerken personen, eigen handelingen, uitkomst" },
    { id: "bpr-f11", front: "'Naar het zich liet aanzien' mag in een rapport?", back: "Ja — het benoemt onzekerheid; dat is eerlijk en toegestaan" },
    { id: "bpr-f12", front: "Vier onderdelen van een goede overdracht?", back: "Lopende zaken, signalen uit het gebied, afspraken, materiaalstatus" },
  ],
  tests: [
    {
      id: "bpr-t1",
      title: "Toets 1: Aanspreken & de-escaleren",
      questions: [
        {
          id: "bpr-t1-q1",
          question: "Je spreekt een jongeren die alcohol drinkt op een drinkverbod-gebied. Wat is de beste openingszin?",
          options: [
            "'Zet die fles nee, anders krijg je een boete!'",
            "'Goedendag, ik ben [naam], BOA van de gemeente. Ik zie dat u hier alcohol drinkt; dat mag hier niet.'",
            "'Weet je wel dat dit verboden is, jongen?'",
            "'Geef hier die fles.'",
          ],
          answerIndex: 1,
          explanation: "Identificeren + gedrag feitelijk benoemen = professionele, de-escalerende opening.",
        },
        {
          id: "bpr-t1-q2",
          question: "Wat is de juiste minimale houding bij benadering?",
          options: [
            "Van achteren naderen voor verrassingseffect",
            "Van voren, rustig, ±1,5 meter, handen zichtbaar",
            "Direct dicht op de persoon staan",
            "Met gekruiste armen luisteren",
          ],
          answerIndex: 1,
          explanation: "Van voren en met afstand = veiligheid en respect; handen zichtbaar = vertrouwen.",
        },
        {
          id: "bpr-t1-q3",
          question: "Iemand wordt luid en boos ('ga weg, kop op!'). Welke fase van de escalatietrap is dit meest waarschijnlijk?",
          options: ["Ongerustheid", "Frustratie", "Verbale agressie", "Fysiek geweld"],
          answerIndex: 2,
          explanation: "Luid, beledigend taalgebruik = verbale agressie. Reactie: volume omlaag, ruimte, melding klaarzetten.",
        },
        {
          id: "bpr-t1-q4",
          question: "Welke de-escalatietechniek hoort NIET thuis in de lijst?",
          options: [
            "Actief luisteren en samenvatten",
            "Opties geven voor medewerking",
            "Bedreigen met gevolgen die je niet wilt uitvoeren",
            "Rustig en laag praten",
          ],
          answerIndex: 2,
          explanation: "Lege bedreigingen verstoren je geloofwaardigheid en escaleren de situatie.",
        },
        {
          id: "bpr-t1-q5",
          question: "Wanneer neem je afstand en stop je het gesprek?",
          options: [
            "Zodra iemand het niet met je eens is",
            "Bij tekenen van dreiging of fysieke escalatie, met melding",
            "Nooit — je praat altijd door",
            "Alleen als je collega het zegt",
          ],
          answerIndex: 1,
          explanation: "Bij dreiging = veiligheid eerst: afstand, melding, wachten op steun.",
        },
        {
          id: "bpr-t1-q6",
          question: "De man gooit de fles weg na je aanspreek. Wat noteer je?",
          options: [
            "Niets, er was geen boete",
            "Tijd, plaats, gedrag, jouw stappen en de medewerking van de man",
            "Alleen zijn naam",
            "Alleen dat er een fles is weggegooid",
          ],
          answerIndex: 1,
          explanation: "Ook zonder boete documenteer je bevinding en handeling — patronen ontstaan uit data.",
        },
        {
          id: "bpr-t1-q7",
          question: "Wat is de beste formulering voor je rapport?",
          options: [
            "'De man was duidelijk dronken en brutaal.'",
            "'De man sprak schor, wankelde bij het lopen en negeerde twee keer mijn verzoek.'",
            "'Man was dronken of gebruikte drugs.'",
            "'Man gedroeg zich onschik.'",
          ],
          answerIndex: 1,
          explanation: "Objectieve observaties (spraak, motoriek, gedrag) in plaats van conclusies.",
        },
        {
          id: "bpr-t1-q8",
          question: "Je radio-melding bij een bewusteloze man is correct als je zegt:",
          options: [
            "'Hier ligt een man, kom snel.'",
            "'Meldkamer, BOA Jansen, plantsoen De Akkers, man bewusteloos, ik start reanimatie, stuur ambulance.'",
            "'Meldkamer, we hebben hulp nodig in het park, over en uit.'",
            "'Iemand belt 112.'",
          ],
          answerIndex: 1,
          explanation: "Wie–waar–wat–hulpvraag, belangrijkste eerst, eigen actie benoemen.",
        },
        {
          id: "bpr-t1-q9",
          question: "Een groep schreeuwt en duwt elkaar. Wat doe je EERST?",
          options: [
            "Direct fysiek tussen beide partijen springen",
            "Afstand houden, situatie observeren, melding doen, dan benaderen",
            "Iedereen staande houden",
            "Wachten tot de politie komt zonder iets te doen",
          ],
          answerIndex: 1,
          explanation: "Eerst observatie + melding + eigen veiligheid; dan pas benaderen met plan.",
        },
        {
          id: "bpr-t1-q10",
          question: "Waarom is het benoemen van onzekerheid ('ik heb de flessen niet zien gooien') in een rapport goed?",
          options: [
            "Omdat het rapport dan korter is",
            "Omdat een rechter eerlijkheid boven schijnzekerheid stelt",
            "Omdat het de verdachte aardiger maakt",
            "Dat is niet goed, je moet altijd zeker klinken",
          ],
          answerIndex: 1,
          explanation: "Objectiviteit en eerlijkheid maken je rapport sterk; schijnzekerheid wordt doorbroken in verhoor.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "bpr-feyn-deescalatie", label: "Waarom opties geven de-escaleren werkt" },
    { key: "bpr-feyn-pv", label: "Feit versus mening in een proces-verbaal" },
    { key: "bpr-feyn-escalatietrap", label: "De escalatietrap uitleggen" },
  ],
};
