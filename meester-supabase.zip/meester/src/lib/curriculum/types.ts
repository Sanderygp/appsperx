// ============================================================
// MEESTER — Curriculum types (MBO Niveau 3, KW1C)
// Handhaving, Toezicht en Veiligheid — jaargang 1
// ============================================================

export interface LessonSection {
  heading: string;
  body: string;
  bullets?: string[];
}

export interface Lesson {
  id: string;
  title: string;
  durationMin: number;
  intro: string;
  sections: LessonSection[];
  keyPoints: string[];
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
}

export interface TestQuestion {
  id: string;
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface PracticeTest {
  id: string;
  title: string;
  questions: TestQuestion[];
}

export interface Subject {
  id: string;
  name: string;
  short: string;
  tagline: string;
  description: string;
  gradient: string; // tailwind gradient for the subject card
  accent: string; // text color class
  icon: string; // lucide icon name
  lessons: Lesson[];
  flashcards: Flashcard[];
  tests: PracticeTest[];
  feynmanConcepts: { key: string; label: string }[];
}
