import type { Subject } from "./types";

// ============================================================
// VAK 1 — REKENEN (MBO 3)
// Focus: percentages, verhoudingen, meten, geld & bonnen
// ============================================================

export const rekenen: Subject = {
  id: "rekenen",
  name: "Rekenen",
  short: "Rekenen",
  tagline: "Reken als een wachter: snel, nauwkeurig, zonder rekenmachine-angst.",
  description:
    "Percentages voor boetes, verhoudingen voor plattegronden, eenheden omrekenen en geld correct verwerken. Het rekenexamen MBO 3F/3D haal je met ijzeren discipline.",
  gradient: "from-amber-500/80 to-yellow-600/60",
  accent: "text-amber-300",
  icon: "Calculator",
  lessons: [
    {
      id: "rek-1",
      title: "Percentages: het broodmerk van de handhaver",
      durationMin: 25,
      intro:
        "Als BOA reken je dagelijks met percentages: administratiekosten over een boete, btw over een rekening, korting bij een verkoopactie die je controleert. Wie percentages beheerst, rekent sneller dan de rekenmachine in zijn zak.",
      sections: [
        {
          heading: "Wat is een percentage eigenlijk?",
          body: "Het woord percentage komt van 'per centum': per honderd. 25% betekent letterlijk 25 per 100, oftewel 25/100 = 0,25. Dat is de kerntruc: vermenigvuldigen met een percentage doe je door eerst te delen door 100. 15% van €80 reken je dus als 80 × 0,15 = €12. Onthoud deze omzetting en je kunt nooit meer verkeerd tekenen.",
          bullets: [
            "1% = 1/100 = 0,01",
            "50% van een getal = het getal × 0,5 (helft)",
            "25% van een getal = getal ÷ 4",
            "10% van een getal = komma één plaats naar links (80 → 8)",
          ],
        },
        {
          heading: "Administratiekosten en toeslagen over een boete",
          body: "Bij een bestuurlijke boete komen vaak administratiekosten of incassokosten bovenop het boetebedrag. Stel: een boete van €95 krijgt 9% administratiekosten. Dan is de toeslag 95 × 0,09 = €8,55 en het totaal €103,55. Werk altijd in deze volgorde: eerst de toeslag berekenen, daarna optellen bij het basisbedrag. Rond op geldbedragen altijd correct af op twee decimalen, want op je proces-verbaal moet elke cent kloppen.",
        },
        {
          heading: "Btw berekenen: vooruit en achteruit",
          body: "In Nederland is de algemene btw-tarief 21% en het verlaagde tarief 9%. De vraag 'is de btw inbegrepen?' verandert de hele berekening. Over €100 EXCLUSIEF btw betaal je 100 × 1,21 = €121 inclusief. Maar is €121 INCLUSIEF btw, dan reken je terug: 121 ÷ 1,21 = €100 exclusief, en de btw is €21. De klassieke fout is 21% van €121 aftrekken; dat is fout, want de 21% rekent over het bedrag exclusief.",
          bullets: [
            "Inclusief → exclusief: bedrag ÷ 1,21",
            "Exclusief → inclusief: bedrag × 1,21",
            "Verlaagd tarief: zelfde truc met 1,09",
          ],
        },
        {
          heading: "Toename en afname",
          body: "Een verhoging met 20% betekent vermenigvuldigen met 1,20. Een korting van 20% betekent vermenigvuldigen met 0,80. Pas op met na elkaar rekenen: eerst 20% korting en daarna 20% verhoging brengt je NIET terug op het startbedrag, want je rekent de tweede keer over een ander bedrag. 100 × 0,80 = 80, en 80 × 1,20 = 96. Dit soort valkuilen staat garantiëd op het examen.",
        },
      ],
      keyPoints: [
        "Percentage = deel door 100: 15% = 0,15",
        "Btw inbegrepen? Altijd delen door (1 + tarief)",
        "Korting ×0,80, verhoging ×1,20 — opeenvolgende procenten vermenigvuldig je",
        "Geldbedragen: altijd twee decimalen",
      ],
    },
    {
      id: "rek-2",
      title: "Verhoudingen, schalen en snelheid",
      durationMin: 25,
      intro:
        "Patrouilleer je door een gebied, lees je een plattegrond of plan je een route? Dan werk je met verhoudingen. De drie-weg-truc (regel van drie) lost 80% van deze examensommen op.",
      sections: [
        {
          heading: "De regel van drie (drie-weg-truc)",
          body: "Bij een verhoudingstabel schrijf je eerst eenheden onder elkaar en vermenigvuldig je schuin. Voorbeeld: 4 uniformen kosten €180. Wat kosten 7? Eén uniform kost 180 ÷ 4 = €45, dus 7 uniformen kosten 7 × 45 = €315. Altijd eerst naar één eenheid rekenen, dan vermenigvuldigen. Deze twee stappen lossen vrijwel elke verhoudingssom op.",
        },
        {
          heading: "Schalen op een plattegrond",
          body: "Schaal 1:100 betekent: 1 cm op tekening = 100 cm in werkelijkheid. Meet je op de plattegrond van een evenemententerrein een looppad van 7 cm, dan is dat in werkelijkheid 7 × 100 = 700 cm = 7 meter. Bij schaal 1:50 is 1 cm dus 0,5 meter. Let op: schaal 1:x met een GROOT x betekent een KLEINE tekening van een groot terrein.",
        },
        {
          heading: "Snelheid, afstand en tijd",
          body: "De formule is afstand = snelheid × tijd, of in driehoekvorm: s = v × t. Fiets je als BOA 15 km/uur door een park en moet je 2,5 km ver komen? Dan is je tijd 2,5 ÷ 15 = 1/6 uur = 10 minuten. Omrekenen tussen uren, minuten en seconden is halve werk: 0,25 uur = 15 minuten, 90 minuten = 1,5 uur. Oefen dit tot het automatisme is.",
          bullets: [
            "afstand = snelheid × tijd",
            "snelheid = afstand ÷ tijd",
            "tijd = afstand ÷ snelheid",
            "1 uur = 60 minuten | 0,5 uur = 30 minuten",
          ],
        },
      ],
      keyPoints: [
        "Eerst naar één eenheid (per 1), dan vermenigvuldigen",
        "Schaal 1:100 → 1 cm tekening = 1 meter echt",
        "s = v × t en de twee omkeringen",
        "Tijden: 0,25 u = 15 min | 0,75 u = 45 min",
      ],
    },
    {
      id: "rek-3",
      title: "Meten, eenheden en omrekenen",
      durationMin: 20,
      intro:
        "Een meter, liter of gram verkeerd omgerekend maakt je rapport onbetrouwbaar. Handhaving leeft van meetbare feiten: afstanden, volumes, gewichten en tijden.",
      sections: [
        {
          heading: "Lengte: van millimeter naar kilometer",
          body: "Elke stap in de trap is een factor 10: km – hm – dam – m – dm – cm – mm. Een trap omlaag = vermenigvuldigen met 10 (komma één plaats naar rechts), een trap omhoog = delen door 10. 3,4 meter is 340 cm en 0,034 km. Schrijf bij meetgegevens in je rapport altijd de eenheid erbij; 'een afstand van 5' zegt niets, '5 meter' is een feit.",
        },
        {
          heading: "Gewicht en volume",
          body: "Gewicht: 1 kilogram = 1000 gram, 1 ton = 1000 kilogram. Volume: 1 liter = 10 dl = 100 cl = 1000 ml. Handig voor controles: 1 liter water weegt precies 1 kilogram. Een krat met 12 flessen van 0,5 liter bevat dus 6 liter en alleen al het water weegt 6 kilo — tel het gewicht van flessen en krat erbij op en je begrijpt waarom je tillen met gebogen knieën doet.",
        },
        {
          heading: "Oppervlakte en terrein",
          body: "Oppervlakte van een rechthoek is lengte × breedte, in vierkante meters (m²). Een plein van 40 m bij 25 m is 1000 m². Een hectare (ha) is 10.000 m² — dat is een veld van 100 m × 100 m. Voor scherpe terreinen zoals driehoeken geldt: oppervlakte = ½ × basis × hoogte. Bij evenementenplanning reken je hiermee de oppervlakte uit voor 1 bezoekers per m².",
        },
        {
          heading: "Promillage en temperatuur",
          body: "Promillage is duizendste: 1‰ = 0,1%. Bloedalcoholgehalte wordt in promillage gemeten; de wettelijke norm voor bestuurders is 0,5‰ (beginners 0,2‰). Temperatuur noteer je in graden Celsius. In je rapportage is de scheiding tussen feiten en schatting cruciaal: 'ongeveer 3 meter' is een schatting, '3,2 meter (gemeten)' is een feit.",
        },
      ],
      keyPoints: [
        "Lengte-trap: elke stap factor 10",
        "1 liter = 1000 ml = 1 kg water",
        "1 hectare = 10.000 m²",
        "Noteer ALTIJD de eenheid in rapportage",
      ],
    },
    {
      id: "rek-4",
      title: "Geld, boetes en administratie",
      durationMin: 20,
      intro:
        "Je werkt met contant geld, boetebedragen en betalingsregelingen. Rekenfouten in administratie ondermijnen direct je geloofwaardigheid en kunnen een boete juridisch aanvechtbaar maken.",
      sections: [
        {
          heading: "Geld tellen en controleren",
          body: "Tel contant geld altijd twee keer, bij voorkeur met de tweede keer in andere volgorde (eerst per coupure gesorteerd). Schrijf het totaalbedrag direct op. Controleer biljetten van €50 en hoger op echtheid via voel-, kijk- en kanteltechniek. Bij ontvangst op locatie geef je altijd een ontvangstbewijs; het bedrag + datum + naam van ontvanger staan erop.",
        },
        {
          heading: "Boetecategorieën en totale kosten",
          body: "Bestuurlijke boetes kennen vaste bedragen per overtreding. Stel: parkeerovertreding €65, plus wettelijke kosten €9, plus 9% administratiekosten over het geheel. Totaal exclusief: 65 + 9 = €74. Toeslag: 74 × 0,09 = €6,66. Totaal: €80,66. Zo'n meerstaps som is typisch examenmateriaal: lees rustig, scheid de stappen, controleer je eindantwoord op betekenisvolheid.",
        },
        {
          heading: "Betalingsregeling en verhoudingen",
          body: "Mag een boete van €420 in termijnen worden betaald over 6 maanden? Dan is elke termijn 420 ÷ 6 = €70 per maand. Wordt er 2% rente per maand geheven over het openstaande bedrag, dan reken je maandelijkse rente als openstaand bedrag × 0,02. Begrijp je deze logica, dan kun je elke betalingsregeling volgen én uitleggen aan de burger — dat is professionaliteit.",
        },
      ],
      keyPoints: [
        "Tel geld twee keer, schrijf direct op",
        "Meerstaps sommen: scheid elke stap",
        "Termijnbedrag = totaal ÷ aantal termijnen",
        "Controleer je antwoord op realisme",
      ],
    },
  ],
  flashcards: [
    { id: "rek-f1", front: "15% van €80 = ?", back: "80 × 0,15 = €12" },
    { id: "rek-f2", front: "Hoe reken je 21% btw terug uit een bedrag inclusief?", back: "Bedrag ÷ 1,21 = exclusief bedrag" },
    { id: "rek-f3", front: "9% administratiekosten over €95 = ?", back: "95 × 0,09 = €8,55" },
    { id: "rek-f4", front: "Schaal 1:100: 7 cm op de tekening = ? in werkelijkheid", back: "7 × 100 = 700 cm = 7 meter" },
    { id: "rek-f5", front: "Fietsen 15 km/u, afstand 2,5 km. Reistijd?", back: "2,5 ÷ 15 = 1/6 uur = 10 minuten" },
    { id: "rek-f6", front: "3,4 meter = ? centimeter", back: "340 cm (trap omlaag: ×10 per stap)" },
    { id: "rek-f7", front: "1 hectare = ? m²", back: "10.000 m² (veld 100 m × 100 m)" },
    { id: "rek-f8", front: "1 liter water weegt...?", back: "Precies 1 kilogram" },
    { id: "rek-f9", front: "Korting 20% reken je met factor...", back: "0,80 (verhoging 20% is ×1,20)" },
    { id: "rek-f10", front: "Eerst 20% korting, dan 20% verhoging op €100. Eindbedrag?", back: "100 × 0,80 = 80; 80 × 1,20 = €96. Niet terug op €100!" },
    { id: "rek-f11", front: "€420 boete in 6 termijnen = ? per termijn", back: "420 ÷ 6 = €70 per maand" },
    { id: "rek-f12", front: "Wettelijke alcoholnorm bestuurders (ervaren)?", back: "0,5 promille (beginners: 0,2‰)" },
    { id: "rek-f13", front: "Regel van drie in 2 stappen?", back: "1) Delen naar één eenheid. 2) Vermenigvuldigen met gevraagde hoeveelheid." },
    { id: "rek-f14", front: "Oppervlakte driehoek = ?", back: "½ × basis × hoogte" },
  ],
  tests: [
    {
      id: "rek-t1",
      title: "Toets 1: Percentages & geld",
      questions: [
        {
          id: "rek-t1-q1",
          question: "Een boete van €120 krijgt 9% administratiekosten. Wat is het TOTAAL te betalen bedrag?",
          options: ["€130,80", "€128,90", "€131,00", "€127,20"],
          answerIndex: 0,
          explanation: "120 × 0,09 = €10,80 toeslag. Totaal: 120 + 10,80 = €130,80.",
        },
        {
          id: "rek-t1-q2",
          question: "Een bedrag is €242 inclusief 21% btw. Wat is het bedrag exclusief btw?",
          options: ["€191,18", "€200,00", "€221,00", "€202,00"],
          answerIndex: 1,
          explanation: "242 ÷ 1,21 = €200 exclusief. De btw is €42 (21% van 200).",
        },
        {
          id: "rek-t1-q3",
          question: "Wat is 12,5% van €96?",
          options: ["€10,20", "€12,00", "€11,50", "€12,50"],
          answerIndex: 1,
          explanation: "12,5% = 1/8. 96 ÷ 8 = €12,00.",
        },
        {
          id: "rek-t1-q4",
          question: "Een jas van €85 heeft 20% korting. Wat betaal je?",
          options: ["€68,00", "€65,00", "€70,00", "€64,00"],
          answerIndex: 0,
          explanation: "85 × 0,80 = €68,00.",
        },
        {
          id: "rek-t1-q5",
          question: "Parkeerovertreding €65 + vaste kosten €9, daarna 9% administratiekosten over het geheel. Totaal?",
          options: ["€80,66", "€79,95", "€81,29", "€80,00"],
          answerIndex: 0,
          explanation: "65 + 9 = €74. 74 × 0,09 = €6,66. Totaal €80,66.",
        },
        {
          id: "rek-t1-q6",
          question: "Een verkoopactie: 'korting verhoogd van 10% naar 25%'. Over een product van €200 daalt de prijs met hoeveel euro EXTRA?",
          options: ["€50,00", "€30,00", "€25,00", "€20,00"],
          answerIndex: 1,
          explanation: "Bij 10%: korting €20. Bij 25%: korting €50. Extra korting = €30.",
        },
        {
          id: "rek-t1-q7",
          question: "Je ontvangt 3 biljetten van €50, 8 van €10 en 14 munten van €2. Totale bedrag?",
          options: ["€258,00", "€248,00", "€268,00", "€228,00"],
          answerIndex: 0,
          explanation: "150 + 80 + 28 = €258,00.",
        },
        {
          id: "rek-t1-q8",
          question: "Een boete van €360 wordt in 8 termijnen betaald. Termijnbedrag?",
          options: ["€48,00", "€45,00", "€40,00", "€52,00"],
          answerIndex: 1,
          explanation: "360 ÷ 8 = €45 per termijn.",
        },
        {
          id: "rek-t1-q9",
          question: "Je verhoogt een bedrag eerst met 10% en verlaagt het resultaat daarna met 10%. Wat klopt?",
          options: [
            "Je komt terug op het startbedrag",
            "Je eindigt lager dan het startbedrag",
            "Je eindigt hoger dan het startbedrag",
            "Dat hangt af van de eenheid",
          ],
          answerIndex: 1,
          explanation: "100 × 1,10 = 110; 110 × 0,90 = €99. Je eindigt 1% lager.",
        },
        {
          id: "rek-t1-q10",
          question: "Wat is 250% van €40?",
          options: ["€100,00", "€62,50", "€125,00", "€90,00"],
          answerIndex: 0,
          explanation: "250% = 2,5. 40 × 2,5 = €100.",
        },
      ],
    },
    {
      id: "rek-t2",
      title: "Toets 2: Verhoudingen, meten & snelheid",
      questions: [
        {
          id: "rek-t2-q1",
          question: "Schaal 1:50. Een gang is op de plattegrond 12 cm. Hoe lang is de gang echt?",
          options: ["6 meter", "12 meter", "60 meter", "0,6 meter"],
          answerIndex: 0,
          explanation: "12 × 50 = 600 cm = 6 meter.",
        },
        {
          id: "rek-t2-q2",
          question: "6 uniformen kosten €234. Wat kosten 9 uniformen?",
          options: ["€351,00", "€312,00", "€393,00", "€338,00"],
          answerIndex: 0,
          explanation: "1 uniform = 234 ÷ 6 = €39. 9 × 39 = €351.",
        },
        {
          id: "rek-t2-q3",
          question: "Je loopt 5 km/uur. Hoeveel minuten doe je over 1200 meter?",
          options: ["24 minuten", "12 minuten", "14,4 minuten", "20 minuten"],
          answerIndex: 2,
          explanation: "1200 m = 1,2 km. Tijd = 1,2 ÷ 5 = 0,24 uur. 0,24 × 60 = 14,4 minuten.",
        },
        {
          id: "rek-t2-q4",
          question: "0,75 uur is gelijk aan...",
          options: ["75 minuten", "7 uur 5 min", "45 minuten", "54 minuten"],
          answerIndex: 2,
          explanation: "0,75 × 60 = 45 minuten.",
        },
        {
          id: "rek-t2-q5",
          question: "Een plein meet 30 m × 20 m. Oppervlakte?",
          options: ["600 m²", "100 m²", "50 m²", "6000 m²"],
          answerIndex: 0,
          explanation: "30 × 20 = 600 m².",
        },
        {
          id: "rek-t2-q6",
          question: "Hoeveel milliliter is 0,4 liter?",
          options: ["40 ml", "400 ml", "4 ml", "4000 ml"],
          answerIndex: 1,
          explanation: "1 liter = 1000 ml, dus 0,4 × 1000 = 400 ml.",
        },
        {
          id: "rek-t2-q7",
          question: "Een driehoekig stuk terrein: basis 24 m, hoogte 10 m. Oppervlakte?",
          options: ["240 m²", "120 m²", "48 m²", "60 m²"],
          answerIndex: 1,
          explanation: "½ × 24 × 10 = 120 m².",
        },
        {
          id: "rek-t2-q8",
          question: "3,7 km is gelijk aan...",
          options: ["370 m", "3700 m", "37000 m", "0,37 m"],
          answerIndex: 1,
          explanation: "1 km = 1000 m, dus 3,7 × 1000 = 3700 m.",
        },
        {
          id: "rek-t2-q9",
          question: "Een afstand van 2,4 km fiets je met 18 km/u. Reistijd?",
          options: ["8 minuten", "10 minuten", "12 minuten", "13,3 minuten"],
          answerIndex: 0,
          explanation: "2,4 ÷ 18 = 0,1333 uur = 8 minuten.",
        },
        {
          id: "rek-t2-q10",
          question: "16,5 gram is gelijk aan...",
          options: ["0,165 kg", "1,65 kg", "165 kg", "1650 kg"],
          answerIndex: 0,
          explanation: "1 kg = 1000 g, dus 16,5 ÷ 1000 = 0,165 kg.",
        },
      ],
    },
  ],
  feynmanConcepts: [
    { key: "rek-feyn-btw", label: "Btw vooruit en achteruit rekenen" },
    { key: "rek-feyn-drieweg", label: "De regel van drie uitleggen" },
    { key: "rek-feyn-schaal", label: "Waarom schaal 1:100 werkt" },
  ],
};
