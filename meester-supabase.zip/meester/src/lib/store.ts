"use client";

// ============================================================
// MEESTER — Zustand store with real-time cloud sync engine
// ------------------------------------------------------------
// Sync model ("instant write, atomic read"):
//  1. Every user action calls an API endpoint FIRST (or optimistically
//     updates local state, then reconciles).
//  2. Every endpoint responds with the FULL progress payload — the
//     client replaces its whole state. Phone ⇄ laptop can never drift.
//  3. The session lives in an httpOnly cookie → opening the app on
//     another device restores everything via GET /api/progress.
// ============================================================

import { create } from "zustand";
import type { ProgressPayload } from "@/lib/progress";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
}

export type TestResult = { score: number; total: number; passed: boolean };

export interface MeesterProgress {
  streak: { current: number; longest: number; lastActiveDay: string; xp: number; reviews: number };
  lessons: Record<string, string>; // lessonId -> completedAt
  tests: Record<string, { score: number; total: number; passed: boolean }>;
  srs: Record<
    string,
    { easeFactor: number; intervalDays: number; repetitions: number; lapses: number; dueDate: string; lastReviewed: string | null }
  >;
  puzzles: Record<string, { bestScore: number; bestLevel: number; plays: number; solved: boolean }>;
  feynman: Record<string, { steps: string[]; stepsDone: number; completed: boolean }>;
  activity: string[];
}

const EMPTY_PROGRESS: MeesterProgress = {
  streak: { current: 0, longest: 0, lastActiveDay: "", xp: 0, reviews: 0 },
  lessons: {},
  tests: {},
  srs: {},
  puzzles: {},
  feynman: {},
  activity: [],
};

export type View =
  | { name: "dashboard" }
  | { name: "subjects" }
  | { name: "subject"; subjectId: string }
  | { name: "lesson"; subjectId: string; lessonId: string }
  | { name: "flashcards"; subjectId?: string }
  | { name: "test"; subjectId: string; testId: string }
  | { name: "gym" }
  | { name: "nback" }
  | { name: "logic" }
  | { name: "feynman" }
  | { name: "profile" };

function payloadToMeester(p: ProgressPayload): MeesterProgress {
  return {
    streak: p.streak,
    lessons: Object.fromEntries(p.lessons.map((l) => [l.lessonId, l.completedAt])),
    tests: Object.fromEntries(p.tests.map((t) => [t.testId, { score: t.score, total: t.total, passed: t.passed }])),
    srs: Object.fromEntries(
      p.srs.map((c) => [
        c.cardId,
        {
          easeFactor: c.easeFactor,
          intervalDays: c.intervalDays,
          repetitions: c.repetitions,
          lapses: c.lapses,
          dueDate: c.dueDate,
          lastReviewed: c.lastReviewed,
        },
      ])
    ),
    puzzles: Object.fromEntries(
      p.puzzles.map((x) => [x.puzzleKey, { bestScore: x.bestScore, bestLevel: x.bestLevel, plays: x.plays, solved: x.solved }])
    ),
    feynman: Object.fromEntries(
      p.feynman.map((f) => [f.conceptKey, { steps: f.steps, stepsDone: f.stepsDone, completed: f.completed }])
    ),
    activity: p.activity,
  };
}

interface MeesterStore {
  user: SessionUser | null;
  status: "loading" | "guest" | "ready";
  progress: MeesterProgress;
  view: View;
  celebration: { open: boolean; perfect: boolean };
  syncing: boolean;

  boot: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;

  setView: (v: View) => void;
  setCelebration: (open: boolean, perfect?: boolean) => void;

  heartbeat: () => Promise<void>;
  completeLesson: (subjectId: string, lessonId: string, completed: boolean) => Promise<void>;
  submitTest: (subjectId: string, testId: string, score: number, total: number) => Promise<{ passed: boolean; perfect: boolean }>;
  reviewCard: (cardId: string, subjectId: string, grade: "again" | "hard" | "good" | "easy") => Promise<void>;
  submitPuzzle: (puzzleKey: string, puzzleType: string, score: number, level: number, solved: boolean) => Promise<void>;
  saveFeynman: (conceptKey: string, concept: string, steps: string[], stepsDone: number, completed: boolean) => Promise<void>;
}

async function post(url: string, body?: unknown) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Synchronisatie mislukt");
  return data;
}

export const useMeester = create<MeesterStore>((set, get) => ({
  user: null,
  status: "loading",
  progress: EMPTY_PROGRESS,
  view: { name: "dashboard" },
  celebration: { open: false, perfect: false },
  syncing: false,

  async boot() {
    try {
      const res = await fetch("/api/auth/me");
      if (!res.ok) {
        set({ status: "guest", user: null });
        return;
      }
      const { user } = await res.json();
      const data = await post("/api/progress/activity");
      set({ user, progress: payloadToMeester(data.progress), status: "ready" });
    } catch {
      set({ status: "guest", user: null });
    }
  },

  async login(email, password) {
    const data = await post("/api/auth/login", { email, password });
    set({ user: data.user, progress: payloadToMeester(data.progress), status: "ready", view: { name: "dashboard" } });
  },

  async register(name, email, password) {
    const data = await post("/api/auth/register", { name, email, password });
    set({ user: data.user, progress: payloadToMeester(data.progress), status: "ready", view: { name: "dashboard" } });
  },

  async logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    set({ user: null, status: "guest", progress: EMPTY_PROGRESS, view: { name: "dashboard" } });
  },

  setView(view) {
    set({ view });
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  },

  setCelebration(open, perfect = false) {
    set({ celebration: { open, perfect } });
  },

  async heartbeat() {
    if (get().syncing) return;
    set({ syncing: true });
    try {
      const data = await post("/api/progress/activity");
      set({ progress: payloadToMeester(data.progress) });
    } finally {
      set({ syncing: false });
    }
  },

  async completeLesson(subjectId, lessonId, completed) {
    const data = await post("/api/progress/lesson", { subjectId, lessonId, completed });
    set({ progress: payloadToMeester(data.progress) });
  },

  async submitTest(subjectId, testId, score, total) {
    const data = await post("/api/progress/test", { subjectId, testId, score, total });
    set({ progress: payloadToMeester(data.progress) });
    return { passed: data.passed, perfect: data.perfect };
  },

  async reviewCard(cardId, subjectId, grade) {
    const data = await post("/api/progress/srs", { cardId, subjectId, grade });
    set({ progress: payloadToMeester(data.progress) });
  },

  async submitPuzzle(puzzleKey, puzzleType, score, level, solved) {
    const data = await post("/api/progress/puzzle", { puzzleKey, puzzleType, score, level, solved });
    set({ progress: payloadToMeester(data.progress) });
  },

  async saveFeynman(conceptKey, concept, steps, stepsDone, completed) {
    const data = await post("/api/progress/feynman", { conceptKey, concept, steps, stepsDone, completed });
    set({ progress: payloadToMeester(data.progress) });
  },
}));
