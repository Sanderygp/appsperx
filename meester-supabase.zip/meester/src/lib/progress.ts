// ============================================================
// MEESTER — Progress sync helper (server-side)
// Every POST endpoint ends here: the FULL progress payload is
// rebuilt and returned to the client. The client replaces its
// whole state with this object → phone and laptop can never
// drift apart. Simple, atomic, reliable.
// ============================================================

import { db } from "@/lib/db";

export interface ProgressPayload {
  streak: {
    current: number;
    longest: number;
    lastActiveDay: string;
    xp: number;
    reviews: number;
  };
  lessons: { lessonId: string; subjectId: string; completedAt: string }[];
  tests: {
    testId: string;
    subjectId: string;
    score: number;
    total: number;
    passed: boolean;
    updatedAt: string;
  }[];
  srs: {
    cardId: string;
    subjectId: string;
    easeFactor: number;
    intervalDays: number;
    repetitions: number;
    lapses: number;
    dueDate: string;
    lastReviewed: string | null;
  }[];
  puzzles: {
    puzzleKey: string;
    puzzleType: string;
    bestScore: number;
    bestLevel: number;
    plays: number;
    solved: boolean;
  }[];
  feynman: {
    conceptKey: string;
    concept: string;
    steps: string[];
    stepsDone: number;
    completed: boolean;
  }[];
  activity: string[]; // active days (yyyy-mm-dd), last 35 days
}

/** Today's date in the user's timezone (Europe/Amsterdam). */
export function amsterdamDay(d: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Amsterdam",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

/** Award XP + register today's activity + maintain the streak. */
export async function touchStreak(userId: string, xpGain: number) {
  const today = amsterdamDay();
  const yesterday = amsterdamDay(new Date(Date.now() - 24 * 60 * 60 * 1000));

  await db.dailyActivity.upsert({
    where: { userId_day: { userId, day: today } },
    update: {},
    create: { userId, day: today },
  });

  const existing = await db.streak.findUnique({ where: { userId } });
  if (!existing) {
    await db.streak.create({
      data: {
        userId,
        current: 1,
        longest: 1,
        lastActiveDay: today,
        xp: xpGain,
      },
    });
    return;
  }

  let current = existing.current;
  if (existing.lastActiveDay !== today) {
    // Streak logic: consecutive Amsterdam-days keep the fire burning
    current = existing.lastActiveDay === yesterday ? existing.current + 1 : 1;
  }

  await db.streak.update({
    where: { userId },
    data: {
      current,
      longest: Math.max(existing.longest, current),
      lastActiveDay: today,
      xp: existing.xp + xpGain,
    },
  });
}

/** Build the complete progress payload for a user. */
export async function buildProgressPayload(userId: string): Promise<ProgressPayload> {
  const [streak, lessons, tests, srs, puzzles, feynman, activities] = await Promise.all([
    db.streak.findUnique({ where: { userId } }),
    db.lessonProgress.findMany({ where: { userId } }),
    db.testAttempt.findMany({ where: { userId } }),
    db.srsCard.findMany({ where: { userId } }),
    db.puzzleScore.findMany({ where: { userId } }),
    db.feynmanEntry.findMany({ where: { userId } }),
    db.dailyActivity.findMany({
      where: { userId },
      orderBy: { day: "desc" },
      take: 35,
    }),
  ]);

  return {
    streak: {
      current: streak?.current ?? 0,
      longest: streak?.longest ?? 0,
      lastActiveDay: streak?.lastActiveDay ?? "",
      xp: streak?.xp ?? 0,
      reviews: streak?.reviews ?? 0,
    },
    lessons: lessons.map((l) => ({
      lessonId: l.lessonId,
      subjectId: l.subjectId,
      completedAt: l.completedAt.toISOString(),
    })),
    tests: tests.map((t) => ({
      testId: t.testId,
      subjectId: t.subjectId,
      score: t.score,
      total: t.total,
      passed: t.passed,
      updatedAt: t.updatedAt.toISOString(),
    })),
    srs: srs.map((c) => ({
      cardId: c.cardId,
      subjectId: c.subjectId,
      easeFactor: c.easeFactor,
      intervalDays: c.intervalDays,
      repetitions: c.repetitions,
      lapses: c.lapses,
      dueDate: c.dueDate.toISOString(),
      lastReviewed: c.lastReviewed?.toISOString() ?? null,
    })),
    puzzles: puzzles.map((p) => ({
      puzzleKey: p.puzzleKey,
      puzzleType: p.puzzleType,
      bestScore: p.bestScore,
      bestLevel: p.bestLevel,
      plays: p.plays,
      solved: p.solved,
    })),
    feynman: feynman.map((f) => ({
      conceptKey: f.conceptKey,
      concept: f.concept,
      steps: JSON.parse(f.steps || "[]") as string[],
      stepsDone: f.stepsDone,
      completed: f.completed,
    })),
    activity: activities.map((a) => a.day),
  };
}
