// ============================================================
// MEESTER — "De IJzeren Vuist" Spaced Repetition engine
// ------------------------------------------------------------
// IMPLEMENTATION OF THE SPACED REPETITION LOGIC (SM-2)
//
// The Ebbinghaus forgetting curve says memory decays roughly
// exponentially: R = e^(-t/S) where S = memory strength.
// Each successful recall INCREASES S, so the next review can be
// scheduled exponentially further away. We use the classic
// SuperMemo-2 (SM-2) algorithm to approximate that:
//
//   EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
//   interval(n) = 1 day          (first correct recall)
//                 6 days         (second correct recall)
//                 interval(n-1) * EF   (n >= 3)
//
// Where q is the recall quality 0..5:
//   0-2 = "Weer vergeten"  → repetitions reset to 0, due in 10 min
//   3   = "Moeilijk"       → interval stays short, EF drops
//   4   = "Goed"           → standard Ebbinghaus expansion
//   5   = "Makkelijk"      → interval *= 1.3 easy-bonus
//
// The app then tells the student EXACTLY which cards to review
// today: every card whose dueDate <= now() is due. That is the
// "Iron Fist": the schedule is non-negotiable.
// ============================================================

export type SrsGrade = "again" | "hard" | "good" | "easy";

export interface SrsState {
  easeFactor: number;
  intervalDays: number;
  repetitions: number;
  lapses: number;
  dueDate: string; // ISO
  lastReviewed?: string; // ISO
}

export const STARTING_EASE = 2.5;
const MIN_EASE = 1.3;
const EASY_BONUS = 1.3;

/** Run one SM-2 review step. Returns the new SRS state. */
export function review(state: Partial<SrsState>, grade: SrsGrade): SrsState {
  const ease = state.easeFactor ?? STARTING_EASE;
  const repetitions = state.repetitions ?? 0;
  const lapses = state.lapses ?? 0;
  const now = new Date();

  // Map the 4 buttons to SM-2 quality 0..5
  const q = grade === "again" ? 0 : grade === "hard" ? 3 : grade === "good" ? 4 : 5;

  // 1) Update the ease factor (how fast intervals grow)
  let newEase = ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
  newEase = Math.max(MIN_EASE, Math.round(newEase * 100) / 100);

  // 2) Compute the next interval
  let intervalDays: number;
  let newRepetitions: number;
  let newLapses = lapses;

  if (grade === "again") {
    // Forgotten → relearn: Ebbinghaus resets the curve for this card
    newRepetitions = 0;
    newLapses = lapses + 1;
    intervalDays = 0; // due again in 10 minutes (same session)
  } else if (repetitions === 0) {
    newRepetitions = 1;
    intervalDays = grade === "hard" ? 0.5 : 1; // 1st recall: 1 day
  } else if (repetitions === 1) {
    newRepetitions = 2;
    intervalDays = grade === "hard" ? 3 : 6; // 2nd recall: 6 days
  } else {
    newRepetitions = repetitions + 1;
    intervalDays = Math.round(
      (state.intervalDays ?? 1) * newEase * (grade === "easy" ? EASY_BONUS : 1)
    );
    intervalDays = Math.min(intervalDays, 365); // cap at one year
  }

  const dueDate =
    intervalDays === 0
      ? new Date(now.getTime() + 10 * 60 * 1000) // 10 minutes
      : new Date(now.getTime() + intervalDays * 24 * 60 * 60 * 1000);

  return {
    easeFactor: newEase,
    intervalDays,
    repetitions: newRepetitions,
    lapses: newLapses,
    dueDate: dueDate.toISOString(),
    lastReviewed: now.toISOString(),
  };
}

/** Preview what the interval would be for each button (UI hint). */
export function previewIntervals(state: Partial<SrsState>): Record<SrsGrade, string> {
  const out = {} as Record<SrsGrade, string>;
  (["again", "hard", "good", "easy"] as SrsGrade[]).forEach((g) => {
    const next = review(state, g);
    out[g] = formatInterval(next.intervalDays);
  });
  return out;
}

export function formatInterval(days: number): string {
  if (days <= 0) return "10 min";
  if (days < 1) return `${Math.round(days * 24)} uur`;
  if (days === 1) return "1 dag";
  if (days < 30) return `${days} dagen`;
  const months = Math.round(days / 30);
  return months === 1 ? "1 maand" : `${months} maanden`;
}

export function isDue(card: SrsState, at: Date = new Date()): boolean {
  return new Date(card.dueDate).getTime() <= at.getTime();
}
