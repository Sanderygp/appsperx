// ============================================================
// MEESTER — Rank ladder ("Discipline overwint")
// XP is written server-side on every meaningful action:
//   lesson +50 | test pass +100 | perfect 10/10 bonus +50
//   SRS review +2 | new puzzle best +30 | Feynman +80
// ============================================================

export interface Rank {
  name: string;
  minXp: number;
  icon: string; // lucide icon name
  description: string;
}

export const RANKS: Rank[] = [
  { name: "Recluut", minXp: 0, icon: "Shield", description: "Elke meester begint nergens. Sta op." },
  { name: "Leerling-Wachter", minXp: 300, icon: "Eye", description: "De basis staat. Blijf herhalen." },
  { name: "Wachter", minXp: 750, icon: "Binoculars", description: "Je ziet wat anderen missen." },
  { name: "Agent", minXp: 1500, icon: "BadgeCheck", description: "Volwaardig op pad. Discipline werkt." },
  { name: "Hoofdagent", minXp: 3000, icon: "Medal", description: "Jongeren kijken tegen je op." },
  { name: "Inspecteur", minXp: 6000, icon: "Award", description: "Analytisch, scherp, onvermoeibaar." },
  { name: "Hoofdinspecteur", minXp: 10000, icon: "Star", description: "Je leidt de straat." },
  { name: "Commissaris", minXp: 16000, icon: "Crown", description: "Bevel over de eenheid." },
  { name: "Meester", minXp: 25000, icon: "Flame", description: "Discipline overwint alles. Je bent er." },
];

export function rankForXp(xp: number) {
  let current = RANKS[0];
  let next: Rank | null = null;
  for (let i = 0; i < RANKS.length; i++) {
    if (xp >= RANKS[i].minXp) {
      current = RANKS[i];
      next = RANKS[i + 1] ?? null;
    }
  }
  const span = next ? next.minXp - current.minXp : 1;
  const into = xp - current.minXp;
  return {
    current,
    next,
    progress: next ? Math.min(1, into / span) : 1,
    xpToNext: next ? next.minXp - xp : 0,
  };
}
