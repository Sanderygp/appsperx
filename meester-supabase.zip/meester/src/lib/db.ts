import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Prod-note (Vercel): query-logging alléén in development.
// In productie loggen we niets — dat voorkomt dat gevoelige data
// (bijv. wachtwoord-hashes) in de Vercel-functielogs terechtkomt
// en houdt de serverless-logs schoon en snel.
export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["query"] : [],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db