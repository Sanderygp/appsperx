// ============================================================
// LOGIC GRID PUZZLES — fluid intelligence trainer
// Each puzzle: N persons, each with exactly one value per
// category. Clues are sufficient to deduce a unique solution.
// ============================================================

export interface LogicPuzzle {
  id: string;
  title: string;
  difficulty: 1 | 2 | 3;
  intro: string;
  entities: string[];
  categories: { key: string; label: string; values: string[] }[];
  solution: Record<string, Record<string, string>>; // entity -> categoryKey -> value
  clues: string[];
}

export const LOGIC_PUZZLES: LogicPuzzle[] = [
  {
    id: "logic-1",
    title: "Dienstronde van zaterdag",
    difficulty: 1,
    intro:
      "Drie BOA's — Jansen, De Vries en Bakker — werkten zaterdag elk in een ander gebied (Centrum, Haven, Winkelcentrum) op een ander moment (Ochtend, Middag, Avond). Wie werkte waar en wanneer?",
    entities: ["Jansen", "De Vries", "Bakker"],
    categories: [
      { key: "gebied", label: "Gebied", values: ["Centrum", "Haven", "Winkelcentrum"] },
      { key: "dienst", label: "Dienst", values: ["Ochtend", "Middag", "Avond"] },
    ],
    solution: {
      Jansen: { gebied: "Centrum", dienst: "Ochtend" },
      "De Vries": { gebied: "Haven", dienst: "Middag" },
      Bakker: { gebied: "Winkelcentrum", dienst: "Avond" },
    },
    clues: [
      "De BOA in het Centrum had de ochtenddienst.",
      "De Vries had de middagdienst.",
      "Bakker patrouilleerde in het Winkelcentrum.",
      "Jansen patrouilleerde niet in de Haven.",
    ],
  },
  {
    id: "logic-2",
    title: "Wie rapporteert de overlast?",
    difficulty: 2,
    intro:
      "Drie aspirant-BOA's — Amara, Bram en Chen — rapporteren elk een ander type overlast (geluidsoverlast, drankoverlast, parkeeroverlast) in een andere wijk (Noord, Oost, Zuid). Wie rapporteert wat en waar?",
    entities: ["Amara", "Bram", "Chen"],
    categories: [
      { key: "overlast", label: "Overlast", values: ["Geluidsoverlast", "Drankoverlast", "Parkeeroverlast"] },
      { key: "wijk", label: "Wijk", values: ["Noord", "Oost", "Zuid"] },
    ],
    solution: {
      Amara: { overlast: "Drankoverlast", wijk: "Zuid" },
      Bram: { overlast: "Geluidsoverlast", wijk: "Noord" },
      Chen: { overlast: "Parkeeroverlast", wijk: "Oost" },
    },
    clues: [
      "Bram rapporteerde de geluidsoverlast.",
      "De BOA in Oost rapporteerde parkeeroverlast.",
      "Amara rapporteerde NIET parkeeroverlast.",
      "Chen werkte niet in Noord.",
      "Amara werkte in Zuid.",
    ],
  },
  {
    id: "logic-3",
    title: "Uitrusting per sector",
    difficulty: 3,
    intro:
      "Vier BOA's — Berg, Can, Dam en Eik — werkten elk in een andere sector (Noord, Oost, Zuid, West) en hadden elk een ander apparatuur als kernuitrusting (bodycam, PDA, handradio, flitslamp). Los het op met de zes aanwijzingen.",
    entities: ["Berg", "Can", "Dam", "Eik"],
    categories: [
      { key: "sector", label: "Sector", values: ["Noord", "Oost", "Zuid", "West"] },
      { key: "apparatuur", label: "Apparatuur", values: ["Bodycam", "PDA", "Handradio", "Flitslamp"] },
    ],
    solution: {
      Berg: { sector: "Noord", apparatuur: "Handradio" },
      Can: { sector: "Oost", apparatuur: "Bodycam" },
      Dam: { sector: "Zuid", apparatuur: "PDA" },
      Eik: { sector: "West", apparatuur: "Flitslamp" },
    },
    clues: [
      "Degene met de bodycam werkte in Oost.",
      "Degene met de PDA werkte in Zuid.",
      "Degene met de handradio werkte in Noord.",
      "Can werkte in Oost.",
      "Dam werkte niet in Noord en had niet de flitslamp.",
      "Berg had de flitslamp niet.",
    ],
  },
];
