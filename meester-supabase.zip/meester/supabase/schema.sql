-- ============================================================
-- MEESTER — Supabase-databasetabellen (kopieer dit volledige
-- bestand naar: Supabase Dashboard → SQL Editor → New query → Run)
-- ------------------------------------------------------------
-- Maakt alle 8 tabellen exact zoals Prisma ze verwacht:
--   User, Streak, LessonProgress, TestAttempt, SrsCard,
--   PuzzleScore, FeynmanEntry, DailyActivity
--
-- Het bestand is idempotent (IF NOT EXISTS): je kunt het veilig
-- meerdere keren uitvoeren.
--
-- WAAROM RLS (Row Level Security) AAN STAAT:
--   De app benadert deze tabellen uitsluitend via de Next.js
--   API-routes met Prisma, over een directe verbinding met de
--   postgres-rol. Die rol omzeilt RLS. RLS zónder policies
--   blokkeert álle directe toegang via de publieke Supabase
--   REST/PostgREST-API (anon-key) — precies wat we willen:
--   wachtwoord-hashes en voortgang zijn nooit publiek leesbaar.
-- ============================================================

-- ------------------------------------------------------------
-- 1. User — accounts (e-mail + wachtwoord, scrypt-hash)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "User" (
    "id"           TEXT         NOT NULL PRIMARY KEY,
    "email"        TEXT         NOT NULL,
    "passwordHash" TEXT         NOT NULL,
    "name"         TEXT         NOT NULL,
    "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"    TIMESTAMP(3) NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS "User_email_key"
    ON "User"("email");

-- ------------------------------------------------------------
-- 2. Streak — "Daily Discipline": server-berekende streak + XP
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "Streak" (
    "id"            TEXT         NOT NULL PRIMARY KEY,
    "userId"        TEXT         NOT NULL,
    "current"       INTEGER      NOT NULL DEFAULT 0,
    "longest"       INTEGER      NOT NULL DEFAULT 0,
    "lastActiveDay" TEXT         NOT NULL DEFAULT '',
    "xp"            INTEGER      NOT NULL DEFAULT 0,
    "reviews"       INTEGER      NOT NULL DEFAULT 0,
    "updatedAt"     TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Streak_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "Streak_userId_key"
    ON "Streak"("userId");

-- ------------------------------------------------------------
-- 3. LessonProgress — afgeronde lessen per vak
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "LessonProgress" (
    "id"          TEXT         NOT NULL PRIMARY KEY,
    "userId"      TEXT         NOT NULL,
    "lessonId"    TEXT         NOT NULL,
    "subjectId"   TEXT         NOT NULL,
    "completedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "LessonProgress_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "LessonProgress_userId_lessonId_key"
    ON "LessonProgress"("userId", "lessonId");

-- ------------------------------------------------------------
-- 4. TestAttempt — beste poging per oefentoets (10/10-gate)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "TestAttempt" (
    "id"        TEXT         NOT NULL PRIMARY KEY,
    "userId"    TEXT         NOT NULL,
    "testId"    TEXT         NOT NULL,
    "subjectId" TEXT         NOT NULL,
    "score"     INTEGER      NOT NULL,
    "total"     INTEGER      NOT NULL,
    "passed"    BOOLEAN      NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "TestAttempt_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "TestAttempt_userId_testId_key"
    ON "TestAttempt"("userId", "testId");

-- ------------------------------------------------------------
-- 5. SrsCard — Spaced Repetition-state per flashcard (SM-2)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "SrsCard" (
    "id"           TEXT         NOT NULL PRIMARY KEY,
    "userId"       TEXT         NOT NULL,
    "cardId"       TEXT         NOT NULL,
    "subjectId"    TEXT         NOT NULL,
    "easeFactor"   DOUBLE PRECISION NOT NULL DEFAULT 2.5,
    "intervalDays" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "repetitions"  INTEGER      NOT NULL DEFAULT 0,
    "lapses"       INTEGER      NOT NULL DEFAULT 0,
    "dueDate"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastReviewed" TIMESTAMP(3),
    CONSTRAINT "SrsCard_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "SrsCard_userId_cardId_key"
    ON "SrsCard"("userId", "cardId");

-- ------------------------------------------------------------
-- 6. PuzzleScore — breingym: Dual N-Back + Logic Grid scores
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "PuzzleScore" (
    "id"         TEXT         NOT NULL PRIMARY KEY,
    "userId"     TEXT         NOT NULL,
    "puzzleKey"  TEXT         NOT NULL,
    "puzzleType" TEXT         NOT NULL,
    "bestScore"  INTEGER      NOT NULL DEFAULT 0,
    "bestLevel"  INTEGER      NOT NULL DEFAULT 0,
    "plays"      INTEGER      NOT NULL DEFAULT 0,
    "solved"     BOOLEAN      NOT NULL DEFAULT false,
    "updatedAt"  TIMESTAMP(3) NOT NULL,
    CONSTRAINT "PuzzleScore_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "PuzzleScore_userId_puzzleKey_key"
    ON "PuzzleScore"("userId", "puzzleKey");

-- ------------------------------------------------------------
-- 7. FeynmanEntry — Feynman-techniek: 4 uitlegstappen als JSON
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "FeynmanEntry" (
    "id"         TEXT         NOT NULL PRIMARY KEY,
    "userId"     TEXT         NOT NULL,
    "conceptKey" TEXT         NOT NULL,
    "concept"    TEXT         NOT NULL,
    "steps"      TEXT         NOT NULL DEFAULT '[]',
    "stepsDone"  INTEGER      NOT NULL DEFAULT 0,
    "completed"  BOOLEAN      NOT NULL DEFAULT false,
    "createdAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"  TIMESTAMP(3) NOT NULL,
    CONSTRAINT "FeynmanEntry_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "FeynmanEntry_userId_conceptKey_key"
    ON "FeynmanEntry"("userId", "conceptKey");

-- ------------------------------------------------------------
-- 8. DailyActivity — één rij per actieve dag (weekdiscipline-strip)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "DailyActivity" (
    "id"     TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "day"    TEXT NOT NULL,
    CONSTRAINT "DailyActivity_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id")
        ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "DailyActivity_userId_day_key"
    ON "DailyActivity"("userId", "day");

-- ------------------------------------------------------------
-- Beveiliging: RLS aan op élke tabel (zie uitleg bovenaan).
-- Geen policies = nul toegang via de publieke API;
-- Prisma (postgres-rol) blijft volledige toegang houden.
-- ------------------------------------------------------------
ALTER TABLE "User"          ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Streak"        ENABLE ROW LEVEL SECURITY;
ALTER TABLE "LessonProgress" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "TestAttempt"   ENABLE ROW LEVEL SECURITY;
ALTER TABLE "SrsCard"       ENABLE ROW LEVEL SECURITY;
ALTER TABLE "PuzzleScore"   ENABLE ROW LEVEL SECURITY;
ALTER TABLE "FeynmanEntry"  ENABLE ROW LEVEL SECURITY;
ALTER TABLE "DailyActivity" ENABLE ROW LEVEL SECURITY;
